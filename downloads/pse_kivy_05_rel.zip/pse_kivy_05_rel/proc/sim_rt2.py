# -*- coding: utf-8 -*-
from multiprocessing import Pipe
from threading import Thread
from multiprocessing import Process, Event
from collections import OrderedDict
from kivy.clock import Clock

from src.common import *
from src.component import *
from src.diagram import *
from src.net import *
from src.terminal import *
from src.debug import *


class SimRK2():
    # Simulator RK2 pre standardnu neinteraktivnu simulaciu.
    # Stavy grafickych elementov su obnovene na konci simulacie

    def __init__(self, diagram, compDict, netDict, wireDict):
        self.diagram = diagram
        self.compDict = compDict
        self.netDict = netDict
        self.wireDict = wireDict

        self.procVisual = None
        self.procSystem = None

    def run(self):
        # vytvorenie simulacnych procesov

        #self.diagram.mode = mode.SIMUL                    # aktivacia grafickych komponentov

        MOSI_parent, MOSI_child = Pipe()                  # komunikacne rozhrania
        MISO_parent, MISO_child = Pipe()

        self.procVisual = VisProcess(self.diagram, MOSI_parent, MISO_parent)
        self.procVisual.parent = self
        self.procVisual.start()                           # proces zberu dat z grafickeho prostredia

        self.procSystem = SysProcess(MISO_child, MOSI_child)
        self.procSystem.compDict = self.compDict
        self.procSystem.netDict = self.netDict
        self.procSystem.wireDict = self.wireDict
        self.procSystem.start()

    def stop(self):
        # ukoncenie simulacnych procesov
        if self.procSystem is not None:    # ukoncenie systemoveho simulacneho procesu
            self.procSystem.shutdown()
            self.procSystem.terminate()    # pre kazdy vytvoreny proces je treba vyslat signal TERM

        if self.procVisual is not None:    # ukonce
            self.procVisual.shutdown()


class VisProcess(Thread):
    '''!
    Proces pre obsluhu grafickych elementov na ploche editora.

    Thread je vytvoreny v priestore procesu Kivy, pretoze potrebuje pristup k datam objektov (nemoze byt typu Process).
    - prechadza vizualne komponenty VISUAL_SOURCE v hlavnom diagrame, v pripade ich zmeny zapise do komunikacnej
      pipe cid komponentu a hodnotu. Data su nacitane v systemovom procese a aktualizovane hodnoty objektov, ktore
      su v procese SystemProces a v oddelenom pametovom priestore
    '''
    def __init__(self, diagram, pipeSend, pipeRecv):
        Thread.__init__(self, target=self.run)

        self.exit = Event()
        self.diagram = diagram
        self.pipeSend = pipeSend                              # komunikacna pipe pre odosielanie
        self.pipeRecv = pipeRecv                              # a pre prijem dat
        self.parent = None

    def run(self):
        #t = 0
        Logger.info('VisProcess: Starting the process')
        visualSource = {}                                     # vytriedenie vizualnych komponentov
        visualSinks = {}
        for cid, c in self.diagram.compDict.items():

            if c.type == compType.SOURCE_VISUAL:              # graficke zdroje dat (Slider ...)
                visualSource[cid] = c
                c.eval(sysState.INIT, 0)

            if c.type == compType.SINKS_VISUAL:               # graficke spotrebice dat (Display, grafy ...)
                visualSinks[cid] = c
                c.eval(sysState.INIT, 0)

            if c.type == compType.CONTROL:                    # specialny pripad, riadiaci komponent
                visualSinks[cid] = c                          # moze prijimat data od shadow procesu

        while True:
            #t = t + 1
            Clock.usleep(1000)                                # neblokujuca systemova pauza
                                                              # @ToDo parametrizovat na frame rate, urcuje rychlost odozvy

            for cid, c in visualSource.items():               # odoslanie stavu graf. komponentu
                state, value = c.getValue()                   # len pri zmene stavu vyst. portu
                if state == compState.CHANGED:
                    self.pipeSend.send((cid, value))

            if self.pipeRecv.poll() is True:                  # prijem hodnoty pre zobrazenie
                (cid, value) = self.pipeRecv.recv()           # hodnoty grafickym komponentom
                visualSinks[cid].setValue(value)              # a riadiacemu komponentu

                #if t > 20000:
                #self.parent.stop()
                #break

            if self.exit.is_set():
                break

        Logger.info('VisProcess: The process is terminated')

    def shutdown(self):
        Logger.info('VisProcess: Initialization of the shutdown process')
        self.exit.set()


class SysProcess(Process):
    def __init__(self, pipeSend, pipeRecv):
        Process.__init__(self, target=self.run)

        self.exit = Event()
        self.pipeSend = pipeSend                              # komunikacna pipe pre odosielanie
        self.pipeRecv = pipeRecv                              # a pre prijem dat

        self.compDict = None           # @ToDo do konstruktora !
        self.netDict = None
        self.wireDict = None

    def run(self):
        Logger.info('SysProcess: Starting the process')

        #-----------------------------------------------------
        # 1. Triedenie komponentov v shadow procese
        #-----------------------------------------------------
        visualSource = {}
        visualSinks = {}                                      # vytriedenie vizualnych komponentov
        controlComp = None
        for cid, c in self.compDict.items():                  # komponenty, od ktorych budeme prijimat data
            if c.type == compType.SOURCE_VISUAL:
                visualSource[cid] = c

            elif c.type == compType.SINKS_VISUAL:             # komponenty, ktorym budeme posielat data
                visualSinks[cid] = c

            elif c.type == compType.CONTROL:
                controlComp = c

            c.eval(sysState.INIT, 0)                          # inicializacia eval funkcii z parametrov komponentu
                                                              # pre vsetky komponenty

        #-----------------------------------------------------
        # 2. Previazanie zdielanych objektov s hodnotou
        #    vystupneho terminalu
        #-----------------------------------------------------
        for out, inpList in self.wireDict.items():
            for inp in inpList:
                inp.shared = out.shared

        # preusporiadanie komponetov typu CONTINUOUS do slovnika podla poradia hlby vnorenia
        # hlbka -> [zoznam komponentov]
        # usporiadanie zoznamu podla velkosti hlbky vnorenia
        contTypeDict = OrderedDict()
        for cid, c in self.compDict.items():
            if (c.type & compType.CONTINUOUS) == compType.CONTINUOUS:    # @ToDo  -zahrnut do cyklu vyssie
                if (c.seqCounter in contTypeDict) is True:
                    contTypeDict[c.seqCounter].append(c)
                else:
                    contTypeDict[c.seqCounter] = [c]

        # zotriedenie podla poradia evaluacie
        contTypeDict = OrderedDict(sorted(contTypeDict.items(), key=lambda t: t[0]))

        #-----------------------------------------------------
        # 3. Inicializacia parametrov simulacie
        #    z parametrov riadiaceho komponentu
        #-----------------------------------------------------
        if controlComp is not None:
            step = controlComp.getParValue('Step')
            stop = controlComp.getParValue('Stop')
        else:
            # ERROR - diagram neobsahuje riadiaci komponent
            pass

        time = 0.0

        #-----------------------------------------------------
        # 4. Cyklus simulacie
        #-----------------------------------------------------
        while(True):
            #time.sleep(0.01)

            # 4.1 Prijem dat z GUI
            #     Presun dat do vystupnych terminalov
            #-------------------------------------------------
            if self.pipeRecv.poll() is True:
                (cid, value) = self.pipeRecv.recv()           # nacitanie dat z vizualnych komponentov
                self.compDict[cid].setValue(value)            # nastavenie vystupnych terminalov

            # 4.2 Evaluacia blokov
            #    Poradie:
            #    - SOURCE, zdroje hodnot
            #    - COUNTINOUS, v poradi vyhodnocovania podla hlbky
            #    - SINKS, spotrebice v shadow procese
            #    - SINKS_VISUAL, priprava dat na odoslanie
            # ------------------------------------------------
            for cid, c in self.compDict.items():               # zdroje
                if c.type == compType.SOURCE:
                    c.eval(sysState.STEP, time)

            for _, cList in contTypeDict.items():               # spojite komponenty
                for c in cList:
                    c.eval(sysState.STEP, time)

            for cid, c in self.compDict.items():               # spotrebice
                if (c.type == compType.SINKS) or (c.type == compType.SINKS_VISUAL):
                    c.eval(sysState.STEP, time)

            # 4.3 Odoslanie dat do GUI
            # ------------------------------------------------

            for cid, c in visualSinks.items():                # odoslanie stavu terminalu
                (state, value) = c.getValue()                 # nastavenie vizualnych komponentov
                if state == compState.CHANGED:
                    self.pipeSend.send((cid, value))

            # 4.4 Kontrola casu a ukoncenia procesu
            #     - proces musi cez pipe vyslat signal o ukonceni
            #       z jeho adresneho priestoru nema dosah na hlavny thread
            # ------------------------------------------------
            time = time + step
            if time >= stop:
                self.pipeSend.send((controlComp.cid, sysState.STOP))

            if self.exit.is_set():
                break

            #if sim_time > 5.0:  !!!! cez pipe ....
            #    self.parent.stop()
            #    break

        Logger.info('SysProcess: The process is terminated')

    def shutdown(self):
        Logger.info('SysProcess: Initialization of the shutdown process')
        self.exit.set()
