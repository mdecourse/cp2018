# -*- coding: utf-8 -*-
import time as tm

from multiprocessing import Pipe
from threading import Thread
from multiprocessing import Process, Event
from collections import OrderedDict

import kivy.clock as kivyClock

from src.common import *
from src.component import *
from src.diagram import *
from src.net import *
from src.terminal import *
from src.debug import *

#-----------------------------------------------------
# Solver RK2T so simulacnym proceson v samostatnom threade
#-----------------------------------------------------


class SimRK2T():
    # Simulator RK2 pre standardnu neinteraktivnu simulaciu.
    # Stavy grafickych elementov su obnovene na konci simulacie

    def __init__(self, diagram, compDict, netDict, wireDict):
        self.diagram = diagram
        self.compDict = compDict
        self.netDict = netDict
        self.wireDict = wireDict

        self.procVisual = None
        self.procSystem = None

    def run(self):
        # zrusenie starych procesov, ak existuju
        if self.procVisual is not None:
            self.procVisual.shutdown()

        if self.procSystem is not None:
            self.procSystem.shutdown()
            self.procSystem.terminate()

        # vytvorenie simulacnych procesov
        #self.procVisual = None
        #self.procSystem = None

        #self.diagram.mode = mode.SIMUL                    # aktivacia grafickych komponentov

        MOSI_parent, MOSI_child = Pipe()                  # komunikacne rozhrania
        MISO_parent, MISO_child = Pipe()

        self.procVisual = VisProcess(self.diagram, MOSI_parent, MISO_parent)
        self.procVisual.parent = self
        self.procVisual.start()                           # proces zberu dat z grafickeho prostredia

        self.procSystem = SysProcess(MISO_child, MOSI_child)
        self.procSystem.compDict = self.compDict
        self.procSystem.netDict = self.netDict
        self.procSystem.wireDict = self.wireDict
        self.procSystem.start()
        tm.sleep(0.1)

    def stop(self):
        # ukoncenie simulacnych procesov
        if self.procSystem is not None:    # ukoncenie systemoveho simulacneho procesu
            self.procSystem.shutdown()
            tm.sleep(0.1)
            #self.procSystem.terminate()    # pre kazdy vytvoreny proces je treba vyslat signal TERM

        if self.procVisual is not None:    # ukonce
            self.procVisual.shutdown()


class VisProcess(Thread):
    '''!
    Proces pre obsluhu grafickych elementov na ploche editora.

    Thread je vytvoreny v priestore procesu Kivy, pretoze potrebuje pristup k datam objektov (nemoze byt typu Process).
    - prechadza vizualne komponenty VISUAL_SOURCE v hlavnom diagrame, v pripade ich zmeny zapise do komunikacnej
      pipe cid komponentu a hodnotu. Data su nacitane v systemovom procese a aktualizovane hodnoty objektov, ktore
      su v procese SystemProces a v oddelenom pametovom priestore
    '''
    def __init__(self, diagram, pipeSend, pipeRecv):
        Thread.__init__(self, target=self.run)

        self.exit = Event()
        self.diagram = diagram
        self.pipeSend = pipeSend                              # komunikacna pipe pre odosielanie
        self.pipeRecv = pipeRecv                              # a pre prijem dat
        self.parent = None

    def run(self):
        Logger.info('VisProcess: Starting the process')

        visualSource = {}                                     # vytriedenie vizualnych komponentov
        visualSinks = {}
        for cid, c in self.diagram.compDict.items():

            if c.type == compType.SOURCE_VISUAL:              # graficke zdroje dat (Slider ...)
                visualSource[cid] = c
                c.state = compState.CHANGED                   # zmena stavu pre nacitanie stavov komponentov na
                c.eval(sysState.INIT)  # , 0)                     # zaciatku simulacie

            if c.type == compType.SINKS_VISUAL:               # graficke spotrebice dat (Display, grafy ...)
                visualSinks[cid] = c
                c.eval(sysState.INIT)  # , 0)

            if c.type == compType.CONTROL:                    # specialny pripad, riadiaci komponent
                visualSinks[cid] = c                          # moze prijimat data od shadow procesu

            #c.eval(sysState.INIT)    # inicializacia prepojovacich komponentov, zobrazenie zbernice
            #c.update()

        while True:
            kivyClock.Clock.usleep(100)                       # neblokujuca systemova pauza
                                                              # @ToDo parametrizovat na frame rate, urcuje rychlost odozvy

            for cid, c in visualSource.items():               # odoslanie stavu graf. komponentu
                state, value = c.getValue()                   # len pri zmene stavu vyst. portu
                if state == compState.CHANGED:
                    self.pipeSend.send((cid, value))

            if self.pipeRecv.poll() is True:                  # prijem hodnoty pre zobrazenie
                (cid, value) = self.pipeRecv.recv()           # hodnoty grafickym komponentom
                visualSinks[cid].setValue(value)              # a riadiacemu komponentu

            if self.exit.is_set():
                break

        Logger.info('VisProcess: The process is terminated')

    def shutdown(self):
        Logger.info('VisProcess: Initialization of the shutdown process')
        self.exit.set()


#class SysProcess(Process):
class SysProcess(Thread):
    def __init__(self, pipeSend, pipeRecv):
        #Process.__init__(self, target=self.run)
        Thread.__init__(self, target=self.run)
        self.exit = Event()
        self.pipeSend = pipeSend                              # komunikacna pipe pre odosielanie
        self.pipeRecv = pipeRecv                              # a pre prijem dat

        self.compDict = None                                  # @ToDo do konstruktora !
        self.netDict = None
        self.wireDict = None

    def integSubset(self, termOut, evalDict):
        # pomocna funkcia pre vyhladanie spojitych komponentov zapojenych za integratorom
        # naplni slovnik komponentov pre aktualizaciu ich stavov
        # v jednotlivych krokoch integracnej metody
        tlist = self.wireDict[termOut]                        # startovaci terminal
        for t in tlist:
            if (t.comp.type & compType.CONTINUOUS) == compType.CONTINUOUS:
                if (t.comp.seqCounter in evalDict) is True:     # ulozenie komponentov do slovnika
                    evalDict[t.comp.seqCounter].append(t.comp)  # podla priority ich vycislenia
                else:
                    evalDict[t.comp.seqCounter] = [t.comp]

                for _, tt in t.comp.termDict.items():         # rekurzivne prehladanie nasledujuceho komponentu
                    if tt.type == termType.OUTPUT:            # pre kazdy jeho vystupny terminal
                        self.integSubset(tt, evalDict)

    def run(self):
        Logger.info('SysProcess: Starting the process')

        t1 = tm.clock()                                       # cas startu simulacie
        #-----------------------------------------------------
        # 1. Previazanie zdielanych objektov s hodnotou
        #    vystupneho terminalu
        #-----------------------------------------------------
        for out, inpList in self.wireDict.items():
            for inp in inpList:
                inp.shared = out.shared

        #-----------------------------------------------------
        # 2. Triedenie a inicializacia komponentov v shadow procese
        #-----------------------------------------------------
        sourcesVisual = []
        sources = []
        sinksVisual = []
        sinks = []
        discrete = []
        control = []                                          # riadenie - moze byt aj viacej komponentov
        integral = []                                         # integratory
        contDict = OrderedDict()

        for cid, c in self.compDict.items():                  # iteracia zoznamu komponentov
                                                              # a icn inicializacia
            c.diagram = self                                  # zmena vlastnika komponentu, potrebna
                                                              # pre zastavenie simulacie v pripade chyby
                                                              # formatu dat, komponentu a pod.
            if c.type == compType.SOURCE_VISUAL:              # vytriedenie vizualnych komponentov
                sourcesVisual.append(c)
                c.eval(sysState.INIT)

            elif c.type == compType.SOURCE:
                sources.append(c)
                c.eval(sysState.INIT)

            elif (c.type == compType.SINKS):
                sinks.append(c)
                c.eval(sysState.INIT)

            elif c.type == compType.SINKS_VISUAL:             # komponenty, ktorym budeme posielat data
                sinksVisual.append(c)
                c.eval(sysState.INIT)

            elif c.type == compType.CONTROL:
                control.append(c)

            elif c.type == compType.DISCRETE:
                discrete.append(c)
                c.eval(sysState.INIT)

            elif c.type == compType.INTEGRAL:                 # doplnenie parametrov integratora, nie su
                                                              # univerzalne, doplnaju sa podla metody
                c.contState = [0.0, 0.0, 0.0]                 # parametre vektora stavovych premennych, RK2
                integral.append(c)                            # [0] - yk, yk+1
                c.contState[0] = c.eval(sysState.INIT)        # [1] - k1,  [2] - k2

                #c.evalDict = OrderedDict()                    # slovnik spojitych komponentov za integratorom
                #self.integSubset(c.out, c.evalDict)           # rekurzivne naplnenie slovnika
                #c.evalDict = OrderedDict(sorted(c.evalDict.items(), key=lambda t: t[0]))

            elif (c.type & compType.CONTINUOUS) == compType.CONTINUOUS:
                if (c.seqCounter in contDict) is True:        # inicializacia slovnika spojitych komponentov
                    contDict[c.seqCounter].append(c)          # podla poradia vyhodnocovania
                else:
                    contDict[c.seqCounter] = [c]

        # zotriedenie komponentov CONTINUOUS podla poradia vyhodnocovania
        # inicializacia komponentov zbernice
        # identifikacia spojov ako zbernice
        contDict = OrderedDict(sorted(contDict.items(), key=lambda t: t[0]))

        for _, cList in contDict.items():
            for c in cList:                                   # inicializacia spojitych komponentov v spravnom
                c.eval(sysState.INIT)                         # poradi, bus compressor (!)
                if (c.type & compType.BUS) == compType.BUS:   # rekurzivne oznacenie zbernic
                    c.setBus(c)

        busList = []                                          # vyber nid zbernic
        for nid, n in self.netDict.items():                   # presun oznacenych spojov do vizualneho prostredia
            if n.isBus is True:                               # pomocou riadiaceho komponentu
                busList.append(nid)
        self.pipeSend.send((control[0].cid, (sysState.UPDATE, busList)))

        #-----------------------------------------------------
        # 3. Inicializacia parametrov simulacie
        #    z parametrov riadiaceho komponentu
        #-----------------------------------------------------
        for c in control:
            if c.solver == 'RK2T':
                step = c.getParValue('Step')
                stop = c.getParValue('Stop')
                break
            else:
                step = 0.1
                stop = 0.0

        #-----------------------------------------------------
        # 4. Cyklus simulacie
        #-----------------------------------------------------
        # 4.1 Prijem dat z GUI a presun dat do vystupnych terminalov (shadow objektov)
        #     Simulacia RK2 nereaguje na zmeny vstupnych podmienok pocas simulacie

        if self.pipeRecv.poll() is True:
            (cid, value) = self.pipeRecv.recv()               # nacitanie dat z vizualnych komponentov
            self.compDict[cid].setValue(value)                # nastavenie vystupnych terminalov

        sysTime = 0.0

        t2 = tm.clock()                                       # cas ukoncenia pripravy simulacie
        while(True):
            # 4.2 Inicializacia hodnot pre novy krok - sync a clock pre krok
            for c in sources:                                 # nacitanie hodnot zdrojov dat
                c.eval(sysState.STEP, sysTime)

            #if len(integral) > 0:                             # RK2 integracia
            # 4.3. nacitanie hodnoty siete k1=f(yk, tk),
            for comp in integral:
                comp.contState[1] = comp.inp.shared.value[0]

            # 3.1 nastavenie hodnoty (yk+k1/2*step)
            for comp in integral:
                comp.out.shared.value[0] = comp.contState[0] + comp.contState[1] / 2.0 * step * comp.gain

            #for comp in integral:                         # prepocet stavu v integracnom kroku
            #    for _, cList in comp.evalDict.items():    # pre vsetky spojite komponenty za integratorom
            #        for c in cList:
            #            c.eval(sysState.STEP)
            for _, cList in contDict.items():                 # spojite komponenty usporiadane
                for c in cList:                               # podla poradia vyhodnocovania
                    c.eval(sysState.STEP)

            # 4.4. vypocet vyslednej hodnoty yk+1=yk+k2
            for comp in integral:
                comp.contState[2] = comp.inp.shared.value[0]                # derivacia
                comp.contState[0] = comp.contState[0] + comp.contState[2] * step
                comp.out.shared.value[0] = comp.contState[0] * comp.gain    # nastavenie vystupu

            # 4.5 Prepocet spojitych blokov podla poradia vyhodnotenia
            #for _, cList in contDict.items():                 # spojite komponenty usporiadane
            #    for c in cList:                               # podla poradia vyhodnocovania
            #        c.eval(sysState.STEP)

            for c in discrete:                                # diskretne na konci kroku
                c.eval(sysState.STEP, sysTime)

            for c in (sinks + sinksVisual):                   # spotrebice dat
                c.eval(sysState.STEP, sysTime)

            sysTime = sysTime + step

            #-----------------------------------------------------
            # 5. Kontrola casu a ukoncenia procesu
            #     ukoncenie, signal pre update komponentov na konci simulacie
            #-----------------------------------------------------
            if sysTime > stop:
                t3 = tm.clock()
                for c in (sinksVisual + sinks):               # uzatvorenie suborov, grafiky
                    c.eval(sysState.STOP, sysTime)

                for c in sinksVisual:                         # odoslanie stavu terminalu
                    (state, value) = c.getValue()             # odoslanie vizualnych komponentov
                    if state == compState.CHANGED:
                        self.pipeSend.send((c.cid, value))

                # vyslanie signalu k ukonceniu simulacie
                self.pipeSend.send((control[0].cid, (sysState.STOP, 0)))
                break

            if self.exit.is_set():
                # ukoncenie simulacie z editora
                self.pipeSend.send((control[0].cid, (sysState.STOP, 0)))
                break

        #t3 = tm.clock()
        Logger.info('SysProcess: Preparation of simulation [sec] ' + '{:6.5f}   '.format(t2 - t1))
        Logger.info('SysProcess: Simulation process        [sec] ' + '{:6.5f}   '.format(t3 - t2))
        Logger.info('SysProcess: Step duration            [msec] ' + '{:6.5f}   '.format((t3 - t2) / (sysTime / step) * 1000))
        Logger.info('SysProcess: Number of steps                 ' + '{:6d}   '.format(int(sysTime / step)))
        Logger.info('SysProcess: The process is terminated')

    def shutdown(self):
        Logger.info('SysProcess: Initialization of the shutdown process')
        self.exit.set()

    def stop(self):
        Logger.error('SysProcess: Process stopped due to component or data error')
        self.exit.set()