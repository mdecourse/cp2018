# -*- coding: utf-8 -*-
from collections import OrderedDict

from kivy.logger import Logger
#from kivy.clock import Clock

from src.common import *
from src.component import *
from src.diagram import *
from src.net import *
from src.terminal import *
from src.debug import *


class Preprocessor():
    '''!
    Predprocesor pre spracovanie diagramu.

    Trieda vytvára logické prepojenia medzi komponentami v diagrame medzi vstupnými
    a výstupnými terminálmi. Pre prepojovacie komponenty - CONN_TERM vytvorí virtuálne
    neviditeľné spoje. Expanduje bloky v digrame ako makrá.
    Rekurzívne eliminuje zo spojov prepojovacie komponenty. Mezi výstupmi a vstupmi
    vytvorí objekty zdielaných hodnôt.
    Kontroluje integritu prepojení:
        - pred kontrolou vymaže všetky virtuálne spoje z predchádzajúcej simulácie
        - prepojenie jedného výstupného terminálu na viacero vstupných terminálov
        - kontrola na chybu slučky v prepojení
        - kontrola na chybu výskytu viacerých výstupných terminálov v prepojení

    @todo - kontrola a chybové hlásenie o nepripojených vstupných termináloch
    @todo - kontrola na siet ukoncenu len CONN terminalom
    @todo - doplnit chybovy stav do terminalu a graficke zvyraznenie zle pripojeneho terminalu a spoja
    '''

    def __init__(self):
        '''
        '''
        self.recursiveCount = 0            # aktualna hlbka rekurzia pri kontrole

    def load(self, fileName):
        '''
        Nacitanie diagramu bez inicializacie grafickych casti.
        '''
        self.compDict = OrderedDict()                         # inicializacia vnutornych struktur
        self.netDict = OrderedDict()

        if fileName is None:
            return compDict, netDict                          # @ToDo kontrola

        with open(fileName, 'r') as input_file:
            s = input_file.readlines()

        #-----------------------------------------------------
        # 1. nacitanie struktury diagramu
        #-----------------------------------------------------
        #readData = json.loads(s[0], object_hook=self.diagram.__jsonImport__)
        readData = json.loads(s[0], object_hook=self.__jsonImport__)
        cList = readData[1]                                   # zoznam komponentov
        nList = readData[2]                                   # zoznam prepojeni
        #-----------------------------------------------------
        # 2. spracovanie zoznamu komponentov
        #-----------------------------------------------------
        for num, c in cList.items():                          # parser zoznamu komponentov
            [cid, name, pos, paramList, p1, p2] = c           # nacitanie zaznamu pre komponent
            comp = globals()[str(name)]()                     # vytvorenie noveho komponentu
            comp.cid = cid                                    # nastavenie parametrov podla zaznamu
            comp.diagram = None

            for k, q in paramList.items():                    # vytvorenie slovnika Parametrov
                try:
                    [name, pos, typ, value, listValue, desc, [isLocked, isVisible, isNameVisible]] = q
                    p = comp.paramDict[name]                  # update parametrov komponentu
                    p.value = value
                except:
                    pass                                      # doslo k zmene parametov, default hodnoty

            self.compDict[comp.cid] = comp                    # zaradenie komponentu do slovnika bloku
            comp.build()                                      # vytvorenie terminalov pre bus, sum ... komponenty
                                                              # v shadow procese maju komponenty vytvorenu
                                                              # graficku strukturu, ale nie su zaradene do graf. stacku

        #-----------------------------------------------------
        # 3. spracovanie zoznamu spojov
        #-----------------------------------------------------
        for n in nList.items():                               # parser zoznamu spojov
            [nid, paramList, vertexList, startTerm, endTerm, [isLocked, isVisible]] = n[1]

            net = Net()
            net.nid = nid
            net.vertexList = []                               # prazdny zoznam vertexov, addNet vytvara nulty vertex

            [stCompId, stTermNum] = startTerm                 # prepojenie net-u, komponent id a cislo terminalu
            cst = self.compDict[stCompId]                          # referencia na komponent - zo slovnika
            stt = cst.getTerminal(stTermNum)                  # referencia na terminal
            stt.netDict[net.nid] = net                        # pridanie net-u do zoznamu prepojeni terminalu
            net.startTerm = stt                               # priradenie pociatocneho terminalu net-u

            [edCompId, edTermNum] = endTerm                   # prepojenie net-u, koncovy terminal
            ced = self.compDict[edCompId]
            edt = ced.getTerminal(edTermNum)
            edt.netDict[net.nid] = net
            net.endTerm = edt

            for k, q in paramList.items():                    # vytvorenie slovnika Parametrov
                [name, pos, typ, value, listValue, desc, [isLocked, isVisible, isNameVisible]] = q
                p = net.paramDict[name]
                p.type = typ
                p.value = value

            self.netDict[net.nid] = net                       # zaradenie prepojenia do lokalneho zoznamu

        c_tmp = []                                            # load blokov
        n_tmp = []
        for cid, c in self.compDict.items():                  # vyhladanie blokov, iteracia slovnika
            if c.type == compType.BLOCK:
                cd, nd = c.loadBlock(cid * 100)               # nacitanie bloku a posunutie ID komponentov a prepojeni
                c_tmp.append(cd)                              # blok je expandovany ako makro
                n_tmp.append(nd)

        for cdict in c_tmp:                                   # zaradenie komponentov a spojov do globalneho slovnika
            self.compDict.update(cdict)

        for ndict in n_tmp:
            self.netDict.update(ndict)

        return self.compDict, self.netDict

    def check(self):
        '''!
        Kontrola spojov v diagrame.

        Vrati stav kontroly a zoznam prepojeni medzi vystupnymi a vstupnymi terminalmi
        @ToDo doplnit kody chyb
        '''
        if len(self.compDict.items()) == 0:                   # diagram neobsahuje nijake komponenty
            return False, {}

        # A3. Doplnenie prepojenia cez komponenty Port
        #     Vytvorenie virtualnych komponentov pre prepojenie sieti, maju rovnaku funkciu ako
        #     objekty Connection, ale bez vykreslenia, spajaju sa vsetky objektu s rovnakym menom siete.
        #     Postup:
        #     1. vytvorenie slovnika vsetkych prepojeni podla mena prepojovacich terminalov
        #        format slovnika meno_portu:zoznam vsetkych prepojeni priradenych k danemu menu
        #     2. vytvorenie prepojovacieho komponentu VirtualJoint a vytvorenie prepojeni podla slovnika,
        #        ktore prepajaju komponenty Port s VirtualJoint

        # A3.1 Vyhladanie vsetkych portov - prepojovacich komponentov siete s rovnakym menom
        #      a vytvorenie slovnika prepojeni, k menu portu su priradene vsetky rovnake Porty
        dictPort = OrderedDict()
        for cid, comp in self.compDict.items():               # iteracia po vsetkych komponentoch
            if comp.type == compType.PORT:                    # vyhladanie portov
                name = comp.getParValue('Port')               # meno terminalu - parameter v triede Port
                if (name in dictPort) is True:                # zaradenie terminalu siete do slovnika spolocnych prepojeni
                    dictPort[name].append(comp)               # ak kluc existuje, pridanie k existujucemu zoznamu
                else:
                    dictPort[name] = [comp]                   # inak vytvorenie noveho kluca v slovniku

        # @ToDo - kontrola - chyba
        #         kazda polozka [meno] musi obsahovat minimalne 2 porty
        #         ERROR - neuplne prepojenie, spoj len s jednym Port-om

        # @ToDo - kontrola - varovanie
        #         bezprizorne komponenty s terminalmi bez pripojenych spojov

        # A3.2 Vytvorenie pomocnych virtualnych spojov podla slovnika prepojeni v dictConn
        self.virtCounter = -1
        for portName, port in dictPort.items():
            virtConn = VirtualConn()                          # vytvorenie virtualneho prepojovacieho bodu

            virtConn.cid = self.virtCounter                   # pre kazdu skupinu portov s rovnakym menom
            self.compDict[self.virtCounter] = virtConn        # zaradenie prepojovacieho komponentu do zluceneho zoznamu

                                                              # meno virtualnej spojky - pre debug
            virtConn.getParam('Name').value = 'V' + str(self.virtCounter)

            self.virtCounter = self.virtCounter - 1
                                                              # vytvorenie prepojeni medzi virtualnym bodom a terminalmi siete
            for p in dictPort[portName]:                      # iteracia po zozname komponentov patriacich do rovnakeho prepojenia
                vnet = VirtualNet()
                vnet.nid = self.virtCounter
                self.virtCounter = self.virtCounter - 1

                vnet.startTerm = p.termDict[1]                # poradove cislo pociatocneho terminalu Portu
                p.termDict[1].netDict[vnet.nid] = vnet        # pripojeie virt. spoja k Portu

                vnet.endTerm = virtConn.termDict[-1]          # poradove cislo koncoveho terminalu VirtualConn
                virtConn.termDict[-1].netDict[vnet.nid] = vnet      # pripojeny koncovy objekt

                self.netDict[vnet.nid] = vnet                 # zaradenie do zoznamu spojov

        # @ToDo - kontrola - chyba
        #         vsetky komponenty Connection - musia mat k terminalu
        #         pripojene min. 2 spoje (realne, virtualne)

        # A4. Kontrola a vytvorenie zoznamu prepojeni wiresDict medzi  vystup -> [vstupy ...]
        #
        #     Kontrola pravidiel:
        #     - na jednej sieti moze byt len jeden vystupny terminal a aspon jeden vstupny terminal
        #     - siet nesmie obsahovat slucku

        self.wireDict = OrderedDict()                         # slovnik prepojeni terminalov
        checkState = True
        for nid, n in self.netDict.items():
            self.recursiveCount = 0                           # kontrola hlbky rekurzie

            # prehladavame len tie spoje, na ktorych je vystupny terminal
            if (n.startTerm.type == termType.OUTPUT) or (n.endTerm.type == termType.OUTPUT):
                self.outTerm = None
                self.inpTerm = []                                 # pole vstupnych terminalov naplnenych v metode parseNet
                if n.startTerm.type == termType.OUTPUT:           # prehladanie typu Out -> net -> In
                    self.outTerm = n.startTerm
                    checkState = self.parseNet(n, n.endTerm)      # prehladanie od konc. terminalu

                elif n.endTerm.type == termType.OUTPUT:           # prehladanie typu In <- net <- Out
                    self.outTerm = n.endTerm
                    checkState = self.parseNet(n, n.startTerm)    # prehladanie od zac. terminalu

                if checkState is False:
                    # vsetky chyby ...
                    return False, {}                              # prehladavanie sa zastavi na prvej chybe
                else:
                    if (self.outTerm in self.wireDict) is True:
                        # viacej prepojeni je pripojenych k jednemu vystupnemu terminalu
                        self.wireDict[self.outTerm] = self.wireDict[self.outTerm] + self.inpTerm
                    else:
                        self.wireDict[self.outTerm] = self.inpTerm

        # Pre vystupne terminaly, ku ktorym nie su pripojene nijake spoje doplnime do
        # wiresDict prazdny zoznam - z dovodu kompatibility
        for cid, c in self.compDict.items():
            for num, t in c.termDict.items():
                if t.type == termType.OUTPUT:
                    if len(t.netDict.items()) == 0:
                        self.wireDict[t] = []

        # Zoznam prepojeni wiresDict obsahuje len prepojenia medzi vystupnym terminalom komponentu
        # a vstupnymi terminalmi ostatnych komponentov bez zahrnutia prepojovacich komponentov (Port, Connection),
        # virtualne spoje nie su potrebne

        # Kontrola numerickych sluciek v grafe, prehladanie a urcenie poradia vypoctu komponentov
        # typu SOURCE (prve), CONTINUOUS a SINKS (posledne)
        for cid, c in self.compDict.items():                  # v lokalnom zozname
            if (c.type == compType.SOURCE) or (c.type == compType.SOURCE_VISUAL):
                for tnum, t in c.termDict.items():            # pre zdroje vyhladame vystupy
                    if t.type == termType.OUTPUT:             # pre vystupy zoberieme zoznam vstupov
                        inpList = self.wireDict[t]
                        for k in inpList:                     # inicializacia prvych komponentov za zdrojmi
                                                              # a rekurzivne volanie nasledujucich
                            if k.comp.addSeqCount(0, self.wireDict) is False:
                                Logger.error('Check: Numericka slucka v diagrame, output ' + k.comp.getParValue('Ref'))
                                return False, self.wireDict

        # Komponenty maju inicializovane pocitadlo hlbky vnorenia seqCounter
        return checkState, self.wireDict

    def parseNet(self, net, term):
        '''!
        Rekurzivne prehladanie siete.

        @param net     Prehladavana siete
        @param term    Terminal prepojenia, ktory nie je vystupny, korektne hodnoty su vstupny alebo prepojovaci.

        Metoda vygeneruje zoznam vstupnych terminalov, ktore sa nachadzaju na sieti. Zoznam sa odovzdava
        v atribute triedy self.wires.
        Funkcia vrati True, ak siet obsahuje jeden vystupny terminal a n vstupnych terminalov.
        Ak siet obsahuje niekolko vystupy terminal (okrem terminalu, z ktoreho bolo vyvolane prehladanie)
        terminalov, funkcia vrati False a oznaci chybnu siet.
        '''
        self.recursiveCount = self.recursiveCount + 1
                                                              # @ToDo parametrizovat hlbku rekurzie
        if self.recursiveCount > 100:                         # kontrola hlbky rekurzie
            # ERROR - prekrocenie hlbky rekurzie, siet obsahuje slucku spojov
            Logger.error('Check: Slucka v spoji, prekrocenie hlbky rekurzie pre net ' + net.paramDict['Name'].value)
            return False

        if term is None:
            # ERROR - neukoncene editovanie spoja, nepripojeny blok
            Logger.error('Check: Spoj bez definovaneho terminalu, net ' + net.paramDict['Name'].value)
            return False

        if term.type == termType.INPUT:                       # najdeny koncovy terminal typu IN
            self.inpTerm.append(term)
            return True                                       # ukoncenie prehladavania

        elif term.type == termType.OUTPUT:                    # najdeny koncovy terminal typu OUT
            # ERROR - siet obsahuje min. dva vystupne terminaly
            Logger.error('Check: Dalsi vystupny terminal na spoji, net ' + net.paramDict['Name'].value)
            # @ToDo farebne znacenie
            return False                                      # chyba - siet obsahuje dva terminaly OUT

        elif (term.type & termType.CONN) == termType.CONN:     # najdeny terminal CONN, rekurzivne hladanie
                                                               # aj pre vnutorne terminaly blokov dalsich terminalov
            if len(term.netDict.items()) == 1:
                Logger.error('Check: Prepojka len s jednym spojom ' + net.paramDict['Name'].value)
                return False

            returnValue = False
            for nid, n in term.netDict.items():               # prehladanie sieti podla koncovych terminalov sieti pripojenych k CONN
                if n == net:                                  # vylucime z prehladavania net, po ktorej sme prisli k CONN
                    pass
                else:
                    # rekurzivne prehladanie dalsich vetiev pripojenych k CONN
                    if term == n.startTerm:
                        returnValue = self.parseNet(n, n.endTerm)    # Conn -> net -> Term
                    else:
                        returnValue = self.parseNet(n, n.startTerm)  # Conn <- net <- Term

                    if returnValue is False:                  # pri chybe nepokracujeme dalej
                        break

            return returnValue

    def __jsonImport__(self, dct):
        '''!
        '''
        return dct
