# -*- coding: utf-8 -*-
'''!
pse 0.5

Install for python3

1. Install dependencies
sudo apt-get install mercurial python3-dev python3-setuptools python3-numpy
python3-opengl libav-tools libsdl-image1.2-dev libsdl-mixer1.2-dev libsdl-ttf2.0-dev
libsmpeg-dev libsdl1.2-dev libportmidi-dev libswscale-dev libavformat-dev libavcodec-dev libtiff5-dev
libx11-6 libx11-dev fluid-soundfont-gm timgm6mb-soundfont xfonts-base xfonts-100dpi xfonts-75dpi
xfonts-cyrillic fontconfig fonts-freefont-ttf

2. Grab source
hg clone https://bitbucket.org/pygame/pygame

3. Finally build and install
cd pygame
python3 setup.py build
sudo python3 setup.py install

4. Install cython3
sudo apt-get install cython3

5. Download Kivy-1.10.0 source, compile and install
sudo python3 setup.py install

6. Konfiguracia pre desktop / laptop
v ~/.kivy/config.ini

[input]
mouse = mouse, disable_multitouch
# zakomentovat zbytok
#%(name)s = probesysfs
'''
import sys
sys.path.append('../')
sys.path.append('../../')
import os
import kivy
from kivy.core.window import Window
from kivy.logger import Logger

kivy.require('1.10.0')
from src.gui import *

'''
#--------------------------------------------------
# Settings fot tablet
#--------------------------------------------------
import os
os.environ['KIVY_DPI'] = '240'
os.environ['KIVY_METRICS_DENSITY'] = '1'
os.environ['KIVY_METRICS_FONTSCALE'] = '1'
'''

'''
#--------------------------------------------------
# Misc. kivy config
#--------------------------------------------------
from kivy.config import Config
from kivy.clock import Clock

Config.set('postproc', 'jitter_distance', 0.01)
Config.set('kivy', 'exit_on_escape', 0)
Config.set('graphics', 'fbo', 'hardware')
Config.write()
Clock.max_iteration = 240
'''

if not os.path.exists('./tmp'):
    try:
        os.makedirs('./tmp')
    except:
        Logger.error('Main: Can not create a ./tmp directory')
        os.exit(1)

Window.clearcolor = conf.backgroundColor
PSE().run()
