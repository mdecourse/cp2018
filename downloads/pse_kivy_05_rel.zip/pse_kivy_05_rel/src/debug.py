# -*- coding: utf-8 -*-
from src.common import *
from src.component import *
from src.net import *


class Debug():
    '''!
    Formatovana tlac datovych struktur.
    '''
    def printComp(self, c):
        '''!
        Formatovana tlac vlastnosti komponentu.
        '''
        print('class name :', c.__class__.__name__)
        print('        obj:', c)
        print('         id:', c.cid)
        print('        ref:', c.paramDict['Ref'].value)
        print('       type:', c.type)
        print('   seqCount:', c.seqCounter)

        print('   terminal: ')
        for num, t in c.termDict.items():
            print('            num:', num)
            print('            obj:', t)
            print('           name:', t.name)
            print('           type:', t.type)

            print('            net:')
            for nid, n in c.termDict[num].netDict.items():
                if n.type == netType.STANDARD:
                    print('                nid:', nid)
                    print('               type:', n.type)
                    print('                obj:', n)
                    print('               name:', n.paramDict['Name'].value)
                else:
                    print('                nid:', nid)
                    print('               type:', n.type)
                    print('                obj:', n)
                print()
        print('--------------------------------------')

    def printNet(self, n):
        '''!
        '''
        if n.type == netType.STANDARD:
            print('  Net name :', n.paramDict['Name'].value)
        else:
            print('  Net name : VIRTUAL noname')
        print('        obj:', n)
        print('         id:', n.nid)
        print('       type:', n.type)
        if n.startTerm is None:
            print(' start Term: None')
        else:
            print('     start Term:')
            print('               term:', n.startTerm)
            print('               comp:', n.startTerm.comp)
            print('                ref:', n.startTerm.comp.paramDict['Ref'].value)
            tnum = -1
            for num, term in n.startTerm.comp.termDict.items():
                if term == n.startTerm:
                    tnum = num
                    break
            print('                num:', tnum)
            print('               type:', term.type)

        if n.endTerm is None:
            print('   end Term: None')
        else:
            print('       end Term: ')
            print('               term:', n.endTerm)
            print('               comp:', n.endTerm.comp)
            print('                ref:', n.endTerm.comp.paramDict['Ref'].value)
            tnum = -1
            for num, term in n.endTerm.comp.termDict.items():
                if term == n.endTerm:
                    tnum = num
                    break
            print('                num:', tnum)
            print('               type:', term.type)

        print('--------------------------------------')

    def printConn(self, w):
        '''!
        Tlac zoznamu prepojeni terminalov
        '''
        for t, tlist in w.items():
            print(t.comp.paramDict['Ref'].value + '[' + str(t.num) + ']' + ' (' + t.comp.__class__.__name__ + ')')
            if len(tlist) > 0:
                for q in tlist:
                    print(' --> ' + q.comp.paramDict['Ref'].value + '[' + str(q.num) + ']' + ' (' + q.comp.__class__.__name__ + ')')
                print()
            else:
                print(' --> []')
                print()
