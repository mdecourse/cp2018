# -*- coding: utf-8 -*-

import math
import json
from collections import OrderedDict

from kivy.graphics import *
from kivy.uix.widget import *

from src.common import *
from src.settings import CompSettings, NetSettings
from src.component import *
from src.net import *
from src.library import *
from src.debug import *

from cfg.config_pse import *


class Diagram(Widget):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.editor = None                                    # pristup k riadiacim prvkom - inicializuje trieda Editor
        self.width = conf.diagramWidth                        # nastavenie rozmerov z konfiguracie
        self.height = conf.diagramHeight

        self.compCounter = 1                                  # pocitadlo vytvorenych komponentov - pre referencie komponentov
        self.netCounter = 1                                   # pocitadlo vytvorenych sieti - pre referencie sieti
        self.virtCounter = -1                                 # pocitadlo virtualnych komponentov a spojov (zaporne hodnoty)
        self.compDict = OrderedDict()                         # slovnik / zoznam komponentov
        self.netDict = OrderedDict()                          # slovnik / zoznam prepojeni medzi komponentami

                                                              #----------------------------------------
                                                              # selektovane casti diagramu (pre MOVE)
                                                              #----------------------------------------
                                                              # selektovane polozky sa deselktuju po ukonceni presunu (on-touch-up)
        self.selComp = None                                   # vybrany komponent
        self.selNet = None                                    # vybrane prepojenie alebo nove prepojenie
        self.selVertex = None                                 # index vybraneho vertex
        self.selParam = None                                  # referencia na vybrany parameter komponentu
        self.selLabel = None                                  # referencia na vybrene oznacenie siete
        self.newNet = None                                    # aktualne editovany a pridavany net, nezaradeny (zatial) do netList

                                                              #----------------------------------------
                                                              # casti diagramu s aktivnym on-screen-menu
                                                              #----------------------------------------
                                                              # polozky s aktivovanum menu sa rusia az po vybere z menu
        self.menuComp = None                                  # komponent s aktivnym on-screen menu, format - comp
        self.menuVertex = None                                # vertex s aktivnym on-screen menu, format - vertex
        self.menuEdge = None                                  # net s aktivnym on-screen menu, format - vertex hrany

        self.mode = mode.NONE                                 # mod editora - nastavuje sa v menu aplikacie, zmenu modu
                                                              # nastavuju tlacitka v definicii GUI

        self.grid = 10                                        # zakladna velkost mriezky
        self.snapOnGrid = True                                # mod lepenia sa na mriezku
        self.fileName = ''

    def __findComp__(self, pos):
        '''!
        Vyhladanie koponentu k zadanej pozicii.

        Vrati prvy komponent, ktory zodpoveda kriteriu hladania, t.j. jeho obrys leží
        pod aktuálnou polohou myši. Pri prekryvajucich sa komponentoch vyberie prvy zo zoznamu.
        '''
        # @ToDo optimalizácia -> usporiadat komponenty do stromu podla kriteria  (x < pos < x+w), (y < pos < y+w)
        #                        pre rychlejsie prehladanie zoznamu
        for key, c in list(self.compDict.items())[::-1]:
            # prehladanie v opacnom poradi, najnovsi komponent je posledny
            if c.pos[0] + c.border[0] <= (pos[0]) <= c.pos[0] + c.border[2] / 2:
                if c.pos[1] + c.border[1] <= (pos[1]) <= c.pos[1] + c.border[3] / 2:
                    return c

    def __findTerm__(self, pos):
        '''
        Vyhladanie najbližšieho terminálu k zadanej pozícii.

        Vráti referenciu na nájdený terminál komponentu. Polomer hladania je definovany v conf.distTerm
        @todo - algoritmus, upravit len pre vyhladavanie v obryse terminalu (a<b<c)
        '''
        nearest = None
        minDistance = float('infinity')
        for key, c in self.compDict.items():
            for num, t in c.termDict.items():
                dist = math.hypot(t.pos[0] + c.pos[0] - pos[0], t.pos[1] + c.pos[1] - pos[1])

                if dist < minDistance:
                    nearest = t
                    minDistance = dist

        if minDistance < conf.distTerm:
            return nearest
        else:
            return None

    def __findVertex__(self, pos):
        '''!
        Vyhladanie najblišieho vertexu k zadanej poxícii.

        Vráti index vertexu a referenciu netu, ak je vzdialenosť
        k najbližšiemu vertexu > ako limit, vráti None.
        '''
        nearestVertex = None
        minDistance = float('infinity')

        for nid, net in self.netDict.items():
            for v in net.vertexList[1:-1]:                    # zoznam vertexov bez terminalov
                dist = math.hypot(v.pos[0] - pos[0], v.pos[1] - pos[1])
                if dist < minDistance:
                    minDistance = dist
                    nearestVertex = v

        if minDistance < conf.distVertex:
            return nearestVertex
        else:
            return None

    def __findParam__(self, pos):
        '''!
        Vyhladanie najblizsieho parametra.
        '''
        for key, c in self.compDict.items():                  # prehladanie zoznamu komponentov - todo optimalizacia podla polohy
            for name, p in c.paramDict.items():               # prehladanie zoznamu parametrov
                                                              # vyhladavame len viditelne a nezamknute parametre
                if p.isVisible is True and p.isLocked is False:
                    if (p.pos[0] + c.pos[0] - p.text_size[0] / 2) <= pos[0] <= (p.pos[0] + c.pos[0] + p.text_size[0] / 2):
                        if (p.pos[1] + c.pos[1] - p.text_size[1] / 2) <= pos[1] <= (p.pos[1] + c.pos[1] + p.text_size[1] / 2):
                            p.isSelected = True
                            return p                          # vrati prvy parameter, ktory nasiel pod mysou
        return None

    def __findEdgeVertex__(self, pos):
        '''!
        Vyhladanie najblizsej hrany (useku medzi dvoma vertexami).

        Metóda určí veľkosť vzdialenosti od polohy pos po normále k hrane net-u a vyhladá najbližšiu
        hranu.Pre nájdenú hranu vrati prvy vertex hrany.

        @ToDo algoritmus BRUTE FORCE, optimalizovat len na prehladavanie
              najblizsich prepojeni - podla poloh vertexov, ulozit do usporiadanej mnoziny podla polohy.
        '''
        distance = float('infinity')
        foundNet = None
        vertIndex = None
        x = pos[0]
        y = pos[1]

        # prehladanie zoznamu prepojeni standardnych prepojeni, virtualne
        # prepojenia su z prehladavania vylucene
        for nid, c in self.netDict.items():
            index = 0
            x1 = c.vertexList[0].pos[0]
            y1 = c.vertexList[0].pos[1]

            for q in c.vertexList[1:]:
                x2 = q.pos[0]
                y2 = q.pos[1]
                px = x2 - x1
                py = y2 - y1

                if (x2 == x1) and (y2 == y1):                 # dva nasledujuce vertexy na sebe
                    pass
                else:                                         # kliknutie mimo vertexu
                    tm = px * px + py * py
                    u = ((x - x1) * px + (y - y1) * py) / float(tm)
                    if u > 1:
                        u = 1
                    elif u < 0:
                        u = 0

                    xn = x1 + u * px
                    yn = y1 + u * py
                    dx = xn - x
                    dy = yn - y
                    d = math.sqrt(dx * dx + dy * dy)

                if d < distance:
                    distance = d
                    foundNet = c
                    vertIndex = index
                index = index + 1
                (x1, y1) = (x2, y2)

        if distance < conf.distEdge:
            return foundNet.vertexList[vertIndex + 1]
        else:
            return None

    def __findLabel__(self, pos):
        '''!
        Vyhladanie najblizsieho oznacenia siete.

        @param pos    Poloha myši (kurzoru), pre selektovanie musi byt v oblasti textu
        '''
        for nid, n in self.netDict.items():                   # prehladanie zoznamu sieti - todo optimalizacia podla polohy
            if len(n.vertexList) > 2:                         # len siete s vnutornym vertexom
                for v in n.vertexList[1:-1]:                  # bez koncovych terminalov
                    if v.label.isVisible is True:             # s viditelnym zobrazenim
                        if (v.label.pos[0] + v.pos[0] - v.label.textSize[0] / 2) <= pos[0] <= (v.label.pos[0] + v.pos[0] + v.label.textSize[0] / 2):
                            if (v.label.pos[1] + v.pos[1] - v.label.textSize[1] / 2) <= pos[1] <= (v.label.pos[1] + v.pos[1] + v.label.textSize[1] / 2):
                                return v.label
        return None

    def start(self):
        '''!
        Spustenie aktivity diagramu.

        Polymorfna metoda definovana v zdedenej triede alebo v triede emulujucej diagram.
        '''
        pass

    def stop(self):
        '''!
        Ukoncenie aktivity diagramu.

        Polymorfna metoda definovana v zdedenej triede alebo v triede emulujucej diagram (napr. proces simualacie)
        '''
        pass

    def clear(self):
        '''
        Vymazanie vsetkuch komponentov a prepojeni diagramu.

        @ToDo meno suboru
        '''
        for cid, comp in self.compDict.items():
            self.remove_widget(comp)

        for nid, net in self.netDict.items():
            self.remove_widget(net)

        self.compDict = OrderedDict()
        self.netDict = OrderedDict()

        self.compCounter = 1                                  # inicializacia pocitadiel
        self.netCounter = 1
        self.virtCounter = -1

    def addComp(self, c, pos):
        '''!
        Pridanie nového komponentu.

        Zaradí novy komponent do vnútornych zoznamov a zobrazí ho na pozicii pos.
        @ToDo - zmena poradia, ordered dictionary - novy komponent by mal byt skor v poradi
        '''
        self.compCounter = self.compCounter + 1               # vytvorenie ID a inicializacia parametrov komponentu
        c.cid = self.compCounter
        c.diagram = self                                      # priradenie diagramu
        c.pos = pos                                           # priradenie aktualnej polohy
        if c.type == compType.BLOCK:
            c.setParValue('Ref', 'B' + str(c.cid))            # vytvorenie referencie - podla typu bloku

        elif c.type == compType.PORT:
            c.setParValue('Ref', 'P' + str(c.cid))

        elif c.type == compType.CONTROL:
            c.setParValue('Ref', 'C' + str(c.cid))

        else:
            c.setParValue('Ref', 'A' + str(c.cid))

        c.build()
        c.update()

        self.selComp = c                                      # pridany komponent je oznaceny ako selektovany - pre posun
        self.add_widget(c)                                    # zaradenie komponentu do graf. systemu
        self.compDict[c.cid] = c
        return c

    def copyComp(self, comp):
        '''!
        Kopia komponentu s parametrami
        '''
        c = globals()[comp.__class__.__name__]()              # vytvorenie noveho objektu podla mena
        for key, p in comp.paramDict.items():                 # kopia parametrov a ich atributov
            c.getParam(key).pos = comp.getParam(key).pos
            c.getParam(key).value = comp.getParam(key).value
            c.getParam(key).isVisible = comp.getParam(key).isVisible
                                                          # ulozenie kopie komponentu s offsetom
        self.addComp(c, (comp.pos[0] + 20, comp.pos[1] - 20))

    def delComp(self, comp):
        '''!
        Zmazanie komponentu

        Terminaly, ku ktorym su pripojene siete, su nahradene Connection.
        '''
        for [num, t] in comp.termDict.items():                # nahrada terminalov prepojovacimi objektami
                                                              # iteracia po terminaloch
            if len(t.netDict.items()) > 0:                    # kontrola pripojeneho terminalu
                conn = Connection()                           # vytvorenie prepojenia
                self.addComp(conn, (comp.pos[0] + t.pos[0], comp.pos[1] + t.pos[1]))

                conn.termDict[1].netDict = t.netDict          # priradenie zoznamu spojov
                for nid, n in t.netDict.items():              # uprava koncovych bodov  pripojenych sieti
                    if n.startTerm == t:
                        n.startTerm = conn.termDict[1]
                    else:
                        n.endTerm = conn.termDict[1]

        del self.compDict[comp.cid]                           # vyradenie komponentu zo slovnika
        comp.clear_widgets()                                  # zmazanie vnutornej struktury
        self.remove_widget(comp)                              # vyradenie komponentu z graf. zasobnika

    def addNet(self):
        '''!
        Vytvorenie noveho prepojenia.

        Prepojenie nie je zaradene do slovnika spojov, kym nie je ukoncene na koncovom terminali.
        '''
        self.netCounter = self.netCounter + 1
        net = Net()
        net.diagram = self
        net.nid = self.netCounter
        net.paramDict['Name'].value = 'N' + str(net.nid)
        return net

    def delNet(self, net):
        '''!
        Zmazanie prepojenia.
        '''
        del net.startTerm.netDict[net.nid]                    # vyradenie netu zo zoznamu prepojeni terminalov
        del net.endTerm.netDict[net.nid]
        del self.netDict[net.nid]                             # vyradenie netu zo zoznamu diagramu

        if net.type is not netType.VIRTUAL:                   # zmazanie standardnych spojov
            net.startTerm.rebuild()                           # prekreslenie terminalov komponentov
            net.endTerm.rebuild()                             # ak bol zmazany posledny net, tak prefarbenie terminalov
            net.clear_widgets()                               # vyradenie dcerskych widgetov - zostavali v pameti
            self.remove_widget(net)                           # vyradenie zmazaneho prepojenia z grafickeho systemu

    def addConn(self, vertex, pos):
        '''!
        Pridanie bodu prepojenia.

        Rozdelí existujúci net na dva samostatné a prida prepojovaci komponent na danú pozíciu,
        v ktorom ich spojí.
        '''
        net = vertex.net                                      # siet, na ktorej ma byt umiestnene prepojenie

        # uprava suradnic pre umiestnenie na mriezke - ak je aktivovany snapOnGrid
        if self.snapOnGrid is True:
            gr = self.grid
            pos = (gr * ((pos[0] + gr / 2) // gr), gr * ((pos[1] + gr / 2) // gr))

        # vytvorenie noveho objektu komponentu prepojenia a zaradenie do diagramu
        conn = Connection()
        self.addComp(conn, pos)

        #----------------------------------------------------------
        # 1. odlozenie povodnych udajov
        #----------------------------------------------------------
        idx = net.vertexList.index(vertex)                    # poradove cislo vertexu
        list_old = net.vertexList[0:idx]                      # vertexy do ...
        list_new = net.vertexList[idx:]                       # vertexy od ...
        endTerm = net.endTerm
        net.clear_widgets()

        #----------------------------------------------------------
        # 2. skratenie povodneho net-u
        #----------------------------------------------------------
        net.vertexList = list_old                             # priradenie skrateneho zoznamu
        net.vertexList.append(Vertex(net, conn.pos))          # doplnenie koncoveho bodu
        del net.endTerm.netDict[net.nid]                      # odstranenie net-u zo zoznamu koncoveho terminalu
        net.endTerm = conn.termDict[1]                        # novy koncovy terminal netu - na komponente conn, c.1
        conn.termDict[1].netDict[net.nid] = net               # priradenie prepojenie terminalu c. 1

        #----------------------------------------------------------
        # 3. vytvorenie noveho net-u
        #----------------------------------------------------------
        newNet = self.addNet()                                # vytvorenie noveho siete
        for vert in list_new:                                 # zmena/uprava 'vlastnika' vertexov, ktore zostali po skrateni net-u
            vert.net = newNet                                 # rychlejsi ekvivalent kopirovania zoznamu a vyrabania novych vertexov
                                                              # novy pociatocny vertex
        newNet.vertexList = [Vertex(newNet, conn.pos)] + list_new

        newNet.startTerm = conn.termDict[1]                   # priradenie noveho poc. terminalu, komp. conn, term. c.1
        conn.termDict[1].netDict[newNet.nid] = newNet         # priradenie novej siete terminalu

        newNet.endTerm = endTerm                              # priradenie koncoveho terminalu
        newNet.endTerm.netDict[newNet.nid] = newNet           # priradenie siete koncovemu terminalu

        self.netDict[newNet.nid] = newNet                     # zaradenie novej siete do diagramu
        newNet.build()                                        # vytvorenie reprezentacie novej siete
        self.add_widget(newNet)                               # zaradenie novej siete do grafickeho stacku
        conn.update()                                         # prekreslenie aktualnych poloh vsetkych pripojenych sieti

    def connToVertex(self, conn):
        '''!
        Konverzia connection na vertex

        Konverzia je mozna pre connection, ku ktoremu su pripojene prave dva spoje.
        '''
        # 1. kontrola prepojenia, ci su k nemu pripojene prave dva spoje
        if conn.type != compType.CONN:                        # kontrola typu
            return

        if len(conn.termDict[1].netDict.items()) != 2:        # kontrola poctu spojov
            return

        # 1. vytvorenie zoznamu vertexov z oboch spojov
        nets = list(conn.termDict[1].netDict.items())
        nid, n1 = nets[0]
        nid, n2 = nets[1]

        self.delNet(n1)                                       # zmazanie povodnych spojov
        self.delNet(n2)                                       # a prepojenia pred vytvorenim noveho,
        self.delConn(conn)                                    # vznikol by problem s vlastnictvom vertexov

        # 1.1 spojenie zoznamu vertexov podla toho, na ktorom konci sa vyskytuje prepojenie Connection
        if n1.vertexList[-1].pos == n2.vertexList[0].pos:        # n1=[x,c] n2=[c,x]
            newVertList = n1.vertexList[0:-1] + n2.vertexList[:]
            st = n1.startTerm
            et = n2.endTerm

        elif n1.vertexList[-1].pos == n2.vertexList[-1].pos:     # n1=[x,c] n2=[x,c]
            newVertList = n1.vertexList[0:-1] + n2.vertexList[::-1]
            st = n1.startTerm
            et = n2.startTerm

        elif n1.vertexList[0].pos == n2.vertexList[-1].pos:      # n1=[c,x] n2=[x,c]
            newVertList = n2.vertexList[0:-1] + n1.vertexList[:]
            st = n2.startTerm
            et = n1.endTerm

        elif n1.vertexList[0].pos == n2.vertexList[0].pos:       # n1=[c,x] n2=[c,x]
            newVertList = (n1.vertexList[::-1])[0:-1] + n2.vertexList[:]
            st = n1.endTerm
            et = n2.endTerm
        else:
            print('chyba ... k tomuto nemoze dojst')

        # 2. vytvorenie noveho prepojenia
        newNet = self.addNet()
        for vtx in newVertList:                               # zmena/uprava 'vlastnika' vertexov,
            vtx.net = newNet                                  # noveho net-u

        newNet.vertexList = newVertList                       # priradenie zoznamu vertexov

        newNet.startTerm = st                                 # priradenie terminalu komponentu startovacieho terminalu
        st.netDict[newNet.nid] = newNet                       # zaradenie prepojenia do slovnika komponentu

        newNet.endTerm = et                                   # to iste pre koncovy terminal
        et.netDict[newNet.nid] = newNet

        self.netDict[newNet.nid] = newNet                     # zaradenie noveho prepojenia zo zoznamu diagramu
        self.add_widget(newNet)                               # a do grafickeho systemu
        st.comp.rebuild()
        et.comp.rebuild()
        newNet.rebuild()

    def vertexToConn(self, vertex):
        '''!
        Konverzia vertexu na connection.

        Na mieste povodneho vertexu vytvori objekt prepojenia a povodny net rozdeli na dva.
        '''
        # 1. vytvorenie noveho objektu komponentu prepojenia na mieste povodneho vertexu
        conn = Connection()
        self.addComp(conn, vertex.pos)
        #print(conn.cid)

        # 2. odlozenie povodnych udajov o zozname vertexov
        idx = vertex.net.vertexList.index(vertex)             # poradove cislo vertexu

        list_old = vertex.net.vertexList[0:idx]               # rozdelenie na dva zoznamy
        list_new = vertex.net.vertexList[idx:]                # bez povodneho vertexu
        endTerminal = vertex.net.endTerm                      # odlozenie koncoveho terminalu
        vertex.net.clear_widgets()                            # zmazanie graf. zobrazenia povodneho prepojenia

        # 3. skratenie povodneho net-u
        vertex.net.vertexList = list_old                      # priradenie skrateneho zoznamu
        vertex.net.vertexList.append(Vertex(vertex.net, conn.pos))  # doplnenie koncoveho bodu
        del vertex.net.endTerm.netDict[vertex.net.nid]        # odstranenie net-u zo zoznamu koncoveho terminalu
        vertex.net.endTerm = conn.termDict[1]                 # novy koncovy terminal - na komponente joint
        conn.termDict[1].netDict[vertex.net.nid] = vertex.net       # priradenie prepojenie terminalu joint-u

        # 4. vytvorenie noveho net-u
        newNet = self.addNet()                                # vytvorenie noveho prepojenia
        for vtx in list_new:                                  # zmena/uprava 'vlastnika' vertexov, ktore zostali po skrateni net-u
            vtx.net = newNet                                  # ekvivalent kopirovania zoznamu a vyrabania novych vertexov

        newNet.vertexList = list_new                          # priradenie zoznamu vertexov

        newNet.startTerm = conn.termDict[1]                   # priradenie terminalu komponentu startovacieho terminalu
        conn.termDict[1].netDict[newNet.nid] = newNet         # zaradenie prepojenia do slovnika komponentu

        newNet.endTerm = endTerminal                          # to iste pre koncovy terminal
        newNet.endTerm.netDict[newNet.nid] = newNet

        self.netDict[newNet.nid] = newNet                     # zaradenie noveho prepojenia zo zoznamu diagramu
        self.add_widget(newNet)                               # a grafickeho systemu

        vertex.net.rebuild()
        newNet.rebuild()

    def delConn(self, conn):
        '''!
        Zmazanie prepojenia

        Pre pocet pripojenych sieti:
        n = 0    zmazat komponent
        n = 1    zmazat komponent aj s pripojenym prepojenim
        n = 2    spojit siete, konvertovat na vertex
        n > 2    neda sa zmazat
        '''
        if conn.type == compType.CONN:                        # kontrola typu
            n = len(conn.termDict[1].netDict.items())         # pocet pripojenich sieti
            if n == 0:                                        # implementacia pravidiel
                self.delComp(conn)
            elif n == 1:
                nid, net = list(conn.termDict[1].netDict.items())[0]
                self.delNet(net)
                self.delComp(conn)
            elif n == 2:
                self.connToVertex(conn)

    def on_touch_down(self, touch):
        '''!
        Implementacia udalosti pri dotyku obrazovky / stlaceni tlacitka mysi.

        Spracovanie udalosti je parametrizovane podla vyberu modu editora v menu.
        '''
        # osetrenie kliknutia na ploche editora, zatvorenie menu a dialogov
        self.editor.updateMode(mode.NONE)

        # forwardovanie eventu pri simulacii
        if self.mode == mode.SIMUL:
            super(Diagram, self).on_touch_down(touch)
            return

        # kontrola na neukonceny net - pocas pridavania net-u bol zmeneny mod editora
        # a net newNet zostal neukonceny - bez koncoveho terminalu
        if (self.newNet is not None) and (self.mode != mode.ADD_VERTEX):
            self.remove_widget(self.newNet)         # zmazanie vytvorenej struktury net-u
            del self.newNet.startTerm.netDict[self.newNet.nid]
            self.newNet.startTerm.rebuild()
            self.newNet = None

        #--------------------------------------------------------------
        # MOVE - presun entity diagramu
        #--------------------------------------------------------------
        pos = (touch.x / self.zoom, touch.y / self.zoom)

        if self.mode == mode.MOVE:
            # upresnenie presun entity grafu podla poradia vyberu
            # priorita posuvanej entity je urcena poradim vyberu typu entity:
            #    - parametre
            #    - oznacenie net-u
            #    - komponent
            #    - vertex
            self.selParam = self.__findParam__(pos)
            if self.selParam is not None:
                self.selParam.isSelected = True
                self.selParam.update()                        # zmena farby parametra
                self.mode = mode.MOVE_PARAM
                return
            else:
                self.selLabel = self.__findLabel__(pos)
                if self.selLabel is not None:
                    self.selLabel.isSelected = True
                    self.selLabel.update()                    # zmena farby labelu
                    self.mode = mode.MOVE_LABEL
                    return
                else:
                    self.selComp = self.__findComp__(pos)
                    if self.selComp is not None:
                        self.mode = mode.MOVE_COMP            # poradie priradenia mode je dolezite
                        self.selComp.isSelected = True        # comp dostane mode uz len typu MOVE_COMP (pre Block a dynam. komponenty)
                        self.selComp.rebuild()                # prekreslenie komponentu - pridanie hranice komponentu
                        return
                    else:
                        self.selVertex = self.__findVertex__(pos)
                        if self.selVertex is not None:
                            self.selVertex.isSelected = True
                            self.selVertex.build()
                            self.selVertex.update()
                            self.mode = mode.MOVE_VERTEX
                            return
        #--------------------------------------------------------------
        # SETUP - on-screen-menu nastavenie parametrov entity diagramu
        #--------------------------------------------------------------
        if self.mode == mode.SETUP:
            # postup v poradi
            # 1. spracovanie menu vybranych entit, ak su aktivne (=menu zobrazene)
            # 2. vyber entity v poradi
            #    - komponent
            #    - vertex
            #    - net

            #----------------------------------------------------------
            # 1. kontrola entit so zobrazenym menu
            # 1.1 spracovanie on-screen menu komponentu
            #----------------------------------------------------------

            if self.menuComp is not None:                     # kontrola vybratia editovaneho komponentu
                self.menuComp.hasMenu = False                 # zrusenie zobrazenia menu
                self.menuComp.build()                         # rebuild zobrazenia komponentu
                self.menuComp.update()                        # spracovanie kliknutia na menu
                value = self.menuComp.menu.value(pos)         # nacitanie hodnoty menu

                if value == mode.SETUP_COMP:                  # otvorenie pop-up okna settings
                    CompSettings(self.menuComp)

                elif value == mode.DEL_COMP:                  # zmazanie komponentu
                    self.delComp(self.menuComp)

                elif value == mode.JNC_2_VTX:                 # konverzia junction -> vertex
                    self.connToVertex(self.menuComp)

                elif value == mode.DEL_JUNCT:                 # zmazanie prepojenia
                    self.delConn(self.menuComp)

                elif value == mode.COPY_COMP:                 # kopia komponentu
                    self.copyComp(self.menuComp)

                elif value == mode.SWP_HORZ:                  # horizontalne preklopenie komponentu
                    self.menuComp.swapHorizontal()
                    self.menuComp.rebuild()

                elif value == mode.SWP_VERT:                  # vertikalne preklopenie komponentu
                    self.menuComp.swapVertical()
                    self.menuComp.rebuild()

                self.menuComp = None
                self.mode = mode.SETUP                        # nastavenie povodneho modu
                return

            #----------------------------------------------------------
            # 1.2 spracovanie on-screen menu vertex-u
            #----------------------------------------------------------
            elif self.menuVertex is not None:
                self.menuVertex.isSelected = False            # zrusenie zobrazenia vertexu
                self.menuVertex.hasMenu = False               # a menu, spracovanie vybranej akcie menu
                self.menuVertex.rebuild()

                value = self.menuVertex.menu.value(pos)       # nacitanie hodnoty menu
                if value == mode.VTX_2_JNC:                   # konverzia vertex -> prepojenie
                    self.vertexToConn(self.menuVertex)

                elif value == mode.DEL_VERTEX:                # zmazanie vertexu
                    self.menuVertex.net.delVertex(self.menuVertex)

                elif value == mode.SHOW_LABEL:                # zobrazenie / zmazanie labelu, prepinac
                    if self.menuVertex.label.isVisible is True:
                        self.menuVertex.label.isVisible = False
                    else:
                        self.menuVertex.label.isVisible = True
                    self.menuVertex.label.rebuild()

                elif value == mode.ANGLE_VERTEX:              # uprava zobrazenia prepojenia
                    self.menuVertex.setAngle()                # do pravych uhlov

                self.menuVertex = None
                self.mode = mode.SETUP                        # nastavenie povodneho modu
                return

            #----------------------------------------------------------
            # 1.3 spracovanie on-screen menu net-u
            #----------------------------------------------------------
            elif self.menuEdge is not None:
                self.menuEdge.net.hasMenu = False
                self.menuEdge.net.rebuild()

                value = self.menuEdge.net.menu.value(pos)     # nacitanie hodnoty menu
                if value == mode.ADD_CONN:                    # pridanie prepojenia
                    self.addConn(self.menuEdge, self.menuEdge.net.menu.pos)

                elif value == mode.SETUP_NET:                 # konfiguracia net-u
                    NetSettings(self.menuEdge.net)

                elif value == mode.DEL_NET:                   # zmazanie siete
                    self.delNet(self.menuEdge.net)

                elif value == mode.INS_VERTEX:
                    self.selVertex = self.menuEdge.net.insVertex(self.menuEdge, self.menuEdge.net.menu.pos)
                    self.selVertex.isSelected = True
                    self.selVertex.net.build()
                    self.selVertex.net.update()
                    #self.mode = mode.MOVE_VERTEX

                self.menuEdge = None
                self.mode = mode.SETUP                        # nastavenie povodneho modu
                return

            #----------------------------------------------------------
            # 2. vyber entity diagramu
            #----------------------------------------------------------
            self.menuComp = self.__findComp__(pos)

            if self.menuComp is not None:                     # vyhladanie komponentu
                #self.menuComp.isSelected = True              # selektovanie komponentu pre ktory je menu zobrazene
                self.menuComp.hasMenu = True                  # zobrazenie on-screen menu
                self.menuComp.rebuild()                       # refresh grafickeho zobrazenia
            else:
                self.menuVertex = self.__findVertex__(pos)    # vyhladanie vertexu a editovanie net-u
                if self.menuVertex is not None:
                    self.menuVertex.isSelected = True
                    self.menuVertex.hasMenu = True
                    self.menuVertex.rebuild()
                else:
                    self.menuEdge = self.__findEdgeVertex__(pos)     # vyhladanie hrany medzi vertexami
                    if self.menuEdge is not None:             # a zobrazenie menu
                        self.menuEdge.net.hasMenu = True
                        self.menuEdge.net.menu.pos = pos
                        self.menuEdge.net.rebuild()

        #--------------------------------------------------------------
        # ADD_NET - vytvorenie prepojenia
        #--------------------------------------------------------------
        if self.mode == mode.ADD_NET:                         # vytvorenie noveho prepojenia
                                                              # prepojenie musi zacinat na terminali komponentu
            t = self.__findTerm__(pos)                        # vyhladanie najblizsieho terminalu
            if t is not None:
                self.newNet = self.addNet()                   # vytvorenie noveho prepojenia a jeho
                self.newNet.setStartTerm(t)                   # pripojenie k startovaciemu terminalu
                self.newNet.addVertex(pos)
                self.newNet.isSelected = True
                self.newNet.build()                           # vytvorenie grafickej reprezentacie prepojenia
                self.add_widget(self.newNet)                  # zaradenie do grafickeho systemu
                self.mode = mode.ADD_VERTEX                   # zmena modu na pridavanie noveho vertexu
            return

        if self.mode == mode.ADD_VERTEX:
            if self.newNet is not None:
                self.newNet.addVertex(pos)
                self.newNet.rebuild()
            return

    def on_touch_move(self, touch):
        '''!
        Implementacia udalosti pri posuvani po obrazovke obrazovky / posuvani pri stlacenom tlacitku mysi.
        '''
        pos = [touch.x / self.zoom, touch.y / self.zoom]
        if self.snapOnGrid is True:            # uprava suradnic pre posun po mriezke - ak je aktivovany snapOnGrid
                gr = self.grid
                pos[0] = gr * ((pos[0] + gr / 2) // gr)
                pos[1] = gr * ((pos[1] + gr / 2) // gr)

        if self.mode == mode.ADD_COMP or self.mode == mode.MOVE_COMP:
            if self.selComp is not None:                      # Presun komponentu po pridani na plochu
                self.selComp.pos = (pos[0], pos[1])
                self.selComp.update()
            return

        elif self.mode == mode.ADD_VERTEX:
            if self.newNet is not None:                       # Pri novom vertexe sa presuva vzdy posledny vertex
                self.newNet.vertexList[-1].pos = (pos[0], pos[1])
                self.newNet.rebuild()

        elif self.mode == mode.MOVE_VERTEX:
            if self.selVertex is not None:
                self.selVertex.pos = (pos[0], pos[1])
                self.selVertex.update()
                self.selVertex.net.update()                   # update polohy

        elif self.mode == mode.MOVE_PARAM:
            if self.selParam is not None:
                self.selParam.pos = (pos[0] - self.selParam.item.pos[0], pos[1] - self.selParam.item.pos[1])
                self.selParam.update()                        # update polohy parametra

        elif self.mode == mode.MOVE_LABEL:
            if self.selLabel is not None:
                self.selLabel.pos = (pos[0] - self.selLabel.vertex.pos[0], pos[1] - self.selLabel.vertex.pos[1])
                self.selLabel.update()

    def on_touch_up(self, touch):
        '''!
        Implementacia udalosti pri opusteni obrazovky / uvolneni tlacitka mysi.
        '''

        pos = (touch.x / self.zoom, touch.y / self.zoom)

        if self.mode == mode.ADD_COMP or self.mode == mode.MOVE_COMP:
            self.selComp.isSelected = False                   # ukoncenie pridavania a presunu komponentov
            self.selComp.rebuild()                            # zrusenie okraja komponentu, aktualizacia polohy
            self.selComp = None
            self.mode = mode.MOVE                             # vseobecny mod editora - presunu
            self.editor.updateMode(self.mode)

        elif self.mode == mode.ADD_VERTEX:
            # pri uvolneni - kontrola aktualnej polohy posledneho vertexu
            # ak je v blizkosti terminal, pripojenie vertexu na terminal
            # @ToDo - kontrola finalneho prepojenie
            #       - duplicitne zadane vertexy
            #       - zhoda startovacieho a koncoveho terminalu
            if self.newNet is not None:
                t = self.__findTerm__(pos)                    # vyhladanie najblizsieho terminalu
                if t is not None and t != self.newNet.startTerm:
                    self.newNet.setEndTerm(t)                 # priradenie koncoveho terminalu
                    self.newNet.isSelected = False            # zrusenie oznacenia pridavanych vertexov
                                                              # inicializacoa mena prepojenia
                    self.newNet.paramDict['Name'].value = 'N' + str(self.newNet.nid)
                    self.newNet.rebuild()                     # standardne zobrazenie prepojenia
                                                              # zaradenie novej siete do zoznamu
                    self.netDict[self.newNet.nid] = self.newNet
                    self.newNet = None
                    self.mode = mode.ADD_NET
                    return

        elif self.mode == mode.MOVE_VERTEX:                   # ukoncenie presuvania vertexu
            self.selVertex.net.isSelected = False             # zrusenie selekcie presuvaneho vertexu
            self.selVertex.net.rebuild()                      # resp. aj dalsich, ak boli selektovane (po ADD_VERTEX)
            self.selVertex = None
            self.mode = mode.MOVE

        elif self.mode == mode.MOVE_LABEL:
            self.selLabel.isSelected = False
            self.selLabel = None
            self.mode = mode.MOVE

        elif self.mode == mode.MOVE_PARAM:
            self.selParam.isSelected = False                  # zrusenie selekcia parametra
            self.selParam.update()                            # zmena farby (odselektovanie) po ukonceni presuvania
            self.selParam = None
            self.mode = mode.MOVE

    def saveFile(self, fileName):
        '''!
        Uloženie diagramu do súboru.
        '''
        # Vytvorenie JSON struktury a ulozenie dat
        q = [                                                 # Zakladna struktura ukladanych dat
               [self.compCounter,                             # pole systemovych konstant
                self.netCounter],                             # s moznostou doplnenia a rozsirenia (@ToDo)
                self.compDict,                                # slovnik komponentov
                self.netDict                                  # slovnik sieti
            ]

        s = json.dumps(q, default=self.__jsonExport__)        # sort_keys=True, indent=4)

        with open(fileName, 'w') as output_file:
            output_file.write(s)
            output_file.write('\n')

    def __jsonExport__(self, obj):
        '''!
        Definicie konverznych operacii pre agregované časti komponentov a sietí.
        '''

        if isinstance(obj, Component):        # format ulozenia komponentu
            d = [obj.cid,
                 obj.__class__.__name__,
                 obj.pos,
                 obj.paramDict,
                 [obj.isLocked, obj.isVisible],
                 [obj.swapHoriz, obj.swapVert, obj.rotAngle]
                 ]
            return d

        if isinstance(obj, Parameter):
            p = [obj.name,
                 obj.pos,
                 obj.type,
                 obj.value,
                 obj.listValue,
                 obj.description,
                 [obj.isLocked, obj.isVisible, obj.isNameVisible]
                ]
            return p

        if isinstance(obj, complex):                          # format ulozenia komplexneho cisla
            return str(obj)

        if isinstance(obj, Vertex):                           # format ulozenia vertexu
            return [obj.pos, obj.label]

        if isinstance(obj, VertexLabel):                      # format ulozenia vertexLabel-u
            return [obj.pos, obj.isVisible]

        if isinstance(obj, Net):
            n = [
                obj.nid,
                obj.paramDict,
                obj.vertexList,
                obj.startTerm,
                obj.endTerm,
                [obj.isLocked, obj.isVisible]
            ]
            return n

        if isinstance(obj, Terminal):
            return [obj.comp.cid, obj.num]

        return obj

    def loadFile(self, fileName):
        '''!
        Načítanie diagramu zo súboru.
        '''
        #self.fileName = fileName
        #self.clear()

        with open(fileName, 'r') as input_file:
            s = input_file.readlines()

        #-----------------------------------------------------
        # 1. nacitanie struktury diagramu
        #-----------------------------------------------------
        readData = json.loads(s[0], object_hook=self.__jsonImport__)

        cList = readData[1]                                   # zoznam komponentov
        nList = readData[2]                                   # zoznam prepojeni

        #-----------------------------------------------------
        # 2. spracovanie zoznamu komponentov
        #-----------------------------------------------------
        for num, c in cList.items():                          # parser zoznamu komponentov
            [cid, name, pos, paramList, p1, p2] = c           # nacitanie zaznamu pre komponent
            [isLocked, isVisible] = p1                        # dekodovanie parametrov
            [swapHoriz, swapVert, rotAngle] = p2

            comp = globals()[str(name)]()                     # vytvorenie noveho komponentu
            comp.cid = cid                                    # nastavenie parametrov podla zaznamu
            comp.pos = pos
            comp.isVisible = isVisible
            comp.isLocked = isLocked
            comp.hasIcon = False

            for n, q in paramList.items():                    # vytvorenie slovnika Parametrov
                [name, pos, typ, value, listValue, desc, [isLocked, isVisible, isNameVisible]] = q
                try:
                    p = comp.paramDict[name]
                    p.value = value
                    p.pos = pos
                    p.isVisible = isVisible
                    p.isLocked = isLocked
                    #p.listValue = listValue
                    p.isNameVisible = isNameVisible
                except:
                    # v aktualnej verzii komponentu sa parameter s danym menom nevyskytuje
                    # pouzije sa parameter z definicie komponentu s default hodnotami
                    pass
                                                              # vytvorenie komponetu (ekvivalent addComp)
                                                              # vytvorenie vnutornej struktury a terminalov
            self.add_widget(comp)                             # zaradenie komponentu do graf. systemu
            self.compDict[comp.cid] = comp                    # zaradenie komponentu do slovnika editora
            self.compCounter = self.compCounter + 1
            comp.diagram = self
            comp.build()                                      # prebudovanie komponentu, zmena poctu terminalov (bus, sum ...)
            self.compCounter = max(self.compCounter, cid)     # posunutie pocitadla na max. moznu hodnotu
                                                              # zabrani vytvoreniu komponentu s nespravnym ID
        #-----------------------------------------------------
        # 3. spracovanie zoznamu spojov
        #-----------------------------------------------------
        for n in nList.items():                               # parser zoznamu spojov
            [nid, paramList, vertexList, startTerm, endTerm, [isLocked, isVisible]] = n[1]

            net = self.addNet()
            net.nid = nid
            net.isLocked = isLocked
            net.isVisible = isVisible
            net.vertexList = []                               # prazdny zoznam vertexov, addNet vytvara nulty vertex
            for [vtxPos, [lblPos, lblVisible]] in vertexList:  # nacitanie zoznamu vertexov
                vtx = Vertex(net, vtxPos)
                vtx.label.pos = lblPos
                vtx.label.isVisible = lblVisible
                net.vertexList.append(vtx)

            [st_cid, st_tnum] = startTerm                     # prepojenie net-u, komponent id a cislo terminalu
            cst = self.compDict[st_cid]                       # referencia na komponent - zo slovnika
            stt = cst.getTerminal(st_tnum)                    # referencia na terminal
            stt.netDict[net.nid] = net                        # pridanie net-u do zoznamu prepojeni terminalu
            net.startTerm = stt                               # priradenie pociatocneho terminalu net-u

            [ed_cid, ed_tnum] = endTerm                       # prepojenie net-u, koncovy terminal
            ced = self.compDict[ed_cid]
            edt = ced.getTerminal(ed_tnum)
            edt.netDict[net.nid] = net
            net.endTerm = edt

            self.add_widget(net)                              # zaradenie net-u do grafickeho systemu
            self.netDict[net.nid] = net                       # zaradenie net-u do diagramu
            self.netCounter = self.netCounter + 1             # inkrementacia pocitadla pre nid
            self.netCounter = max(self.netCounter, nid)       # presunutie na najvyssiu hodnotu

            for n, q in paramList.items():                    # vytvorenie slovnika Parametrov
                try:
                    [name, pos, typ, value, listValue, desc, [isLocked, isVisible, isNameVisible]] = q
                    p = net.paramDict[name]
                    #p.type = typ
                    p.value = value
                    p.isLocked = isLocked                         # @ToDo doplnenie na pripadnu zmenu parametrov
                    #p.listValue = listValue                       # ak bola zmenena kniznica (vymazany parameter)
                except:
                    pass

        # finalne prekreslenie komponentov a spojov
        for cid, c in self.compDict.items():
            c.rebuild()

        for nid, n in self.netDict.items():
            n.rebuild()

    def __jsonImport__(self, dct):
        '''!
        '''
        return dct
