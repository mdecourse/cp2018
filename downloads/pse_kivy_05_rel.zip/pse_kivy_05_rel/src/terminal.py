# -*- coding: utf-8 -*-
#import numpy as np
from collections import OrderedDict

from kivy.graphics import Mesh
from kivy.uix.widget import Widget
from kivy.graphics.vertex_instructions import Line, Ellipse
from kivy.uix.label import Label
from kivy.metrics import dp

from src.common import *
#from net import *

# @ToDo doplnit terminal s palickou, ktora meni smer pri zmene orientacie terminalu
# @ToDo doplnit dalsie druhy terminalov (x,stvorec ...)


class SharedValue():
    '''!
    Zdielaná hodnota pre terminaly.
    '''
    def __init__(self):
        self.value = [0.0]


class Terminal(Widget):
    '''
    Terminál komponentu.
    '''
    def __init__(self, comp, num, name, pos, tType, orient=termDir.EAST, posName=(dp(0), dp(0)), posNum=(dp(0), dp(0))):
        '''!
        Vytvorenie noveho terminálu a zaradenie ho do slovnika terminalov, klúčom je číslo terminálu.
        Vrati referenciu terminalu pre dalsie upravy.

        @param comp        Referencia na komponent, ku ktoremu patri terminal
        @param num         Číslo terminálu, celočíselná hodnota
        @param name        Meno terminálu, textový reťazec
        @param pos         Relatívna poloha vzhľadom ku komponentu, typle (x,y)
        @param termType    Typ terminálu definovaný v TerminalType
        @param orient      Smer terminal (ake je orientovany - sipka)
        @param posName     Poloha mena terminalu - ak je viditelna
        @param posNum      Poloha cisla terminalu - ak je viditelne
        '''
        super(Terminal, self).__init__()

        self.type = tType                   # typ terminalu (flag), zaroven aj smer (dnu/von)
        self.termShape = termShape.NoShape     # tvar terminalu (flag)
        self.termColor = color.red             # farba okraja a vyplne terminalu
        self.pos = (dp(pos[0]), dp(pos[1]))    # relativna poloha terminalu voci stredu komponentu
        self.size = (dp(8), dp(8))             # vonkajsi rozmer terminalu (x,y)
        self.orient = orient                   # orientacia terminalu vzhladom k pos - vyznam pre sipkove typy

        self.netDict = OrderedDict()           # slovnik pripojenych sieti k terminalu
        self.comp = comp                       # komponent, ku ktoremu terminal patri
        self.shared = SharedValue()            # referencia na zdielanu hodnotu terminalov
        #self.shared = None            # referencia na zdielanu hodnotu terminalov

        self.name = name                       # meno terminalu
        self.nameShow = False                  # zobrazenie mena terminalu
        self.namePos = posName                 # relativna poloha textu mena k polohe terminalu
        self.nameAlign = 0                     # zarovnanie textu mena k jeho polohe
        self.nameSize = dp(10)                 # velkost pisma
        self.nameColor = color.red             # farba pisma
                                               # @ToDo format / font pisma

        self.num = num                         # cislo terminalu
        self.numShow = False                   # zobrazenie cisla terminalu
        self.numPos = posNum                   # relativna poloha cisla/textu k polohe terminalu
        self.numAlign = 0                      # zarovnanie cisla/textu vzhladom polohe
        self.numSize = dp(10)                  # velkost pisma
        self.numColor = color.red              # farba pisma
                                               # @ToDo format / font pisma

        self.comp.termDict[self.num] = self    # zaradenie terminalu do zoznamu

        self.nameLabel = Label(text=str(self.name), size=(0, 0), italic=True, font_size=self.nameSize)
        self.numLabel = Label(text=str(self.num), size=(0, 0), italic=True, font_size=self.numSize)

        #if self.type == termType.OUTPUT:
        #    self.shared = SharedValue()

    def getValue(self):
        '''!
        Vrati hodnotu zdielanej premennej terminalu.
        '''
        return self.shared.value

    def setValue(self, value):
        '''!
        Nastavi hodnotu zdielanej premennej terminalu a stav
        '''
        self.shared.value = value

    def build(self):
        '''!
        Vytvorenie a/alebo zmena grafickej reprezentacie terminalu
        '''
        self.canvas.clear()
        self.clear_widgets()

        if self.nameShow is True:
            self.add_widget(self.nameLabel)

        if self.numShow is True:
            self.add_widget(self.numLabel)

    def update(self):
        '''!
        Prekreslenie terminálu.

        Poloha terminálu je relatívna k polohe komponentu.
        '''
        if self.nameShow is True:
            self.nameLabel.color = self.nameColor
            self.nameLabel.font_size = self.nameSize
            self.nameLabel.pos = (self.comp.pos[0] + self.pos[0] + self.namePos[0], self.comp.pos[1] + self.pos[1] + self.namePos[1])

        if self.numShow is True:
            self.numLabel.color = self.numColor
            self.numLabel.font_size = self.numSize
            self.numLabel.pos = (self.comp.pos[0] + self.pos[0] + self.numPos[0], self.comp.pos[1] + self.pos[1] + self.numPos[1])

    def rebuild(self):
        self.build()
        self.update()


class TermTriangle(Terminal):

    def __init__(self, comp, num, name, pos, type=termType.OUTPUT, orient=termDir.EAST):
        super().__init__(comp, num, name, pos, type, orient)

    def build(self):
        super().build()
        self.canvas.add(RGBA_Color(self.termColor))

        if len(self.netDict.items()) > 0:            # teminal s pripojenymi sietami (plny)
            self.shape = Mesh(mode='triangle_fan', vertices=[], indices=(0, 1, 2))
            self.canvas.add(self.shape)
        else:
            self.line = Line(points=[])
            self.canvas.add(self.line)                # terminal bez pripojenych sieti (prazdny)

        for nid, n in self.netDict.items():
            #if n.type != netType.VIRTUAL:
            n.build()

    def update(self):
        '''!
        Prekreslenie terminalu po zmene polohy.

        @ToDo zarovnanie testu mena terminalu podla orientacie terminalu
        '''
        super().update()

        (dx, dy) = self.size
        # rozlisenie podla typu
        if (self.type & termType.OUTPUT) == termType.OUTPUT:
            # rozlisenie podla polohy na komponente (vlavo, vpravo, hore, dole)
            if self.orient == termDir.EAST:
                px = [0, -dx, -dx, 0]
                py = [0, dy / 2, -dy / 2, 0]
            elif self.orient == termDir.SOUTH:
                px = [0, dx / 2, -dx / 2, 0]
                py = [0, dy, dy, 0]
            elif self.orient == termDir.NORTH:
                px = [0, dx / 2, -dx / 2, 0]
                py = [0, -dy, -dy, 0]
            elif self.orient == termDir.WEST:
                px = [0, dx, dx, 0]
                py = [0, dy / 2, -dy / 2, 0]

        elif (self.type & termType.INPUT) == termType.INPUT:
            if self.orient == termDir.WEST:
                px = [-dx, 0, 0, -dx]
                py = [0, -dy / 2, dy / 2, 0]
            elif self.orient == termDir.SOUTH:
                px = [0, dx / 2, -dx / 2, 0]
                py = [dy, 0, 0, dy]
            elif self.orient == termDir.NORTH:
                px = [0, dx / 2, -dx / 2, 0]
                py = [-dy, 0, 0, -dy]
            elif self.orient == termDir.EAST:
                px = [dx, 0, 0, dx]
                py = [0, -dy / 2, dy / 2, 0]

        pos = (self.pos[0] + self.comp.pos[0], self.pos[1] + self.comp.pos[1])

        if len(self.netDict.items()) > 0:
            self.vert = []
            for i in range(4):
                for i in range(4):
                    self.vert.append(px[i] + pos[0])
                    self.vert.append(py[i] + pos[1])
                    self.vert.append(0)
                    self.vert.append(0)
            self.shape.vertices = self.vert
        else:
            self.points = []
            for i in range(4):
                self.points.append(px[i] + pos[0])
                self.points.append(py[i] + pos[1])

            self.line.points = self.points

        for nid, n in self.netDict.items():
            #if n.type != netType.VIRTUAL:
            n.update()


class TermJoint(Terminal):
    '''!
    Prepojovaci terminal pre ne-blokove komponenty.

    Terminal meni svoje zobrazenie podla poctu pripojenych prepojeni.
    '''
    def __init__(self, comp, num, name, pos, termType, orient=termDir.NONE):

        super().__init__(comp, num, name, pos, termType, orient)
        self.border = Line()
        self.shape = Ellipse(size=self.size)
        self.build()

    def build(self):
        super().build()
        self.canvas.add(RGBA_Color(self.termColor))

        if len(self.netDict.items()) == 0:        # nepripojeny net, zobrazeny prazdny terminal
            self.canvas.add(self.border)
        elif len(self.netDict.items()) == 1:      # jeden net, terminal nezobrazeny
            pass
        else:
            cnt = 0                               # pripojenych niekolko net-ov (standard, virtual|
            for nid, net in self.netDict.items():
                if net.type == netType.STANDARD:  # spocitanie viditelnych prepojeni
                    cnt = cnt + 1
            if cnt > 1:                           # >1 viditelnych, zobrazeny plny terminal
                self.canvas.add(RGBA_Color(color.green))
                self.canvas.add(self.shape)

    def update(self):
        super().update()
        self.border.circle = (self.comp.pos[0] + self.pos[0], self.comp.pos[1] + self.pos[1], self.size[0] / 2)
        self.shape.pos = (self.comp.pos[0] + self.pos[0] - self.size[0] / 2, self.comp.pos[1] + self.pos[1] - self.size[1] / 2)

        for nid, net in self.netDict.items():
            if net.type != netType.VIRTUAL:
                net.update()


class VirtualTerm(Terminal):
    '''!
    Neviditelny terminal pre prepojovaci komponent Connection
    '''
    def __init__(self, comp, num, name, pos, termType, orient=termDir.NONE):
        super().__init__(comp, num, name, pos, termType, orient)

    def build(self):
        pass                # zrusenie grafickeho prekreslovania terminalu

    def update(self):
        pass