# -*- coding: utf-8 -*-
'''!
PSE GUI- Kivy Language.

'''
import os

from kivy.uix.widget import Widget
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, FadeTransition, Screen
from kivy.uix.popup import Popup

from src.grid import *
from src.diagram import *
from src.component import *
from src.library import *
from src.common import *
from src.debug import *
from proc.preproc import *
from proc.sim_rk2 import *
from proc.sim_rk2t import *

from cfg.config_pse import *

Builder.load_string('''
#:import cwd os.getcwd
#:import config cfg.config_pse.conf

<Editor>:
    id: screen

    #--------------------------------------------
    # Vertikalne rozdelenie plochy na bar(hore)
    # a pracovnu plochu
    # Povodny ActionBar je nahradeny standardnymi tlacitkami,
    # bol nestabilny pri zmene velkosti pracovnej plochy
    #--------------------------------------------
    BoxLayout:
        orientation: 'vertical'

        #--------------------------------------------
        # Tlacitkovy 'ActionBar'
        #--------------------------------------------
        BoxLayout:                                      # tlacitka riadenia na hornej strane
            orientation: 'horizontal'
            height: '58dp'
            size_hint_y: None
            padding: '5dp'                              # odsadenie a medzery
            spacing: '5dp'

            Image:
                height: '48dp'
                source:  './icons/pse_48.png'
                size_hint:(None, None)

            Button:
                id: btn_file
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/file_3.png'
                background_down: './icons/file_3.png'
                on_press:
                    screen.openFileMenu()

            #--------------------------------------------
            # Delimiter
            #--------------------------------------------
            Label:
                text: ''

            Button:
                id: btn_prev
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/a_left.png'
                background_down: './icons/a_left.png'
                on_press:
                    root.manager.current = root.manager.previous()

            Button:
                id: btn_screen
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/scr_1.png'
                background_down: './icons/scr_1.png'

            Button:
                id: btn_prev
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/a_right.png'
                background_down: './icons/a_right.png'
                on_press:
                    root.manager.current = root.manager.next()

            Label:
                text: ''

            #--------------------------------------------
            # Run Button
            # Spustenie / zastavenie simulacie
            #--------------------------------------------
            Button:                                     # tlacitko run
                id: btn_run                             # parametre tlacitka
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                btnState: False

                background_normal: './icons/sys_run.png'
                background_down: './icons/sys_stop.png'
                changeIcon: lambda background_normal: './icons/sys_run.png' if background_normal == './icons/sys_stop.png' else './icons/sys_stop.png'
                switch: lambda x: False if x == True else True

                on_press:
                    btn_run.background_normal = btn_run.changeIcon(btn_run.background_normal)
                    btn_run.background_down = btn_run.background_normal
                    btn_run.btnState = btn_run.switch(btn_run.btnState)

                    btn_add.background_normal = './icons/puzzle.png'
                    btn_draw.background_normal = './icons/draw_net_2.png'
                    btn_edit.background_normal = './icons/edit_prop.png'
                    btn_move.background_normal = './icons/move_item.png'
                    btn_visual.background_normal = './icons/display.png'
                    screen.run()

            #--------------------------------------------
            # Delimiter
            #--------------------------------------------
            Label:
                text: ''

            #--------------------------------------------
            # Zoom Button +
            # Zvecsenie diagramu
            #--------------------------------------------
            Button:                                     # tlacitko zoom +
                id: btn_zoom_in                         # parametre tlacitka
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)

                gridState: True                         # premenne tlacitka
                background_normal: './icons/zoom_in_2.png'
                background_down: './icons/zoom_in_2_sel.png'
                z: lambda x: 2 if x > 2  else x
                on_press:
                    diagram.zoom = btn_zoom_in.z(diagram.zoom + 0.1)
                    diagram.width = config.diagramWidth * diagram.zoom
                    diagram.height = config.diagramHeight * diagram.zoom


            #--------------------------------------------
            # Zoom Button 1:1
            # Reset diagramu, nastavenie na stred plochy
            #--------------------------------------------
            Button:                                     # tlacitko zoom 1:1
                id: btn_zoom_home                       # parametre tlacitka
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)

                gridState: True                         # premenne tlacitka
                background_normal: './icons/zoom_home_2.png'
                background_down: './icons/zoom_home_2_sel.png'
                on_press:
                    diagram.zoom = 1.0
                    scroll.scroll_x = 0.5
                    scroll.scroll_y = 0.5
                    diagram.width = config.diagramWidth
                    diagram.height = config.diagramHeight

            #--------------------------------------------
            # Zoom Button -
            # Zmensenie diagramu
            #--------------------------------------------
            Button:                                     # tlacitko zoom -
                id: btn_zoom_out                        # parametre tlacitka
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)

                gridState: True                         # premenne tlacitka
                background_normal: './icons/zoom_out_2.png'
                background_down: './icons/zoom_out_2_sel.png'
                z: lambda x: 0.5 if x < 0.5  else x
                on_press:
                    diagram.zoom = btn_zoom_out.z(diagram.zoom - 0.1)
                    diagram.width = config.diagramWidth * diagram.zoom
                    diagram.height = config.diagramHeight * diagram.zoom
                    #scroll.scroll_x = 0.5
                    #scroll.scroll_y = 0.5

            #--------------------------------------------
            # Delimiter
            #--------------------------------------------
            Label:
                text: ''

            #--------------------------------------------
            # Grid Button
            # Tlacitko pre zmenu nastavenia viditelnosti grid-u, spolu s viditelnostou
            # sa meni aj stav lepenia na mriezku
            #--------------------------------------------
            Button:
                id: btn_grid                            # parametre tlacitka
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)

                gridState: True                         # premenne tlacitka
                background_normal: './icons/grid_on.png'
                background_down: './icons/grid_on.png'

                changeIcon: lambda background_normal: './icons/grid_off.png' if background_normal == './icons/grid_on.png' else './icons/grid_on.png'
                switch: lambda x: False if x == True else True

                on_press:
                    btn_grid.background_normal = btn_grid.changeIcon(btn_grid.background_normal)
                    btn_grid.background_down = btn_grid.background_normal
                    btn_grid.gridState = btn_grid.switch(btn_grid.gridState)

                    grid.gridIsVisible = btn_grid.gridState        # zobrazenie / zmazanie mriezky
                    diagram.snapOnGrid = btn_grid.gridState        # lepenie / volne umiestnenie na mriezku
                    grid.build()                                   # prekreslenie mriezky

            #--------------------------------------------
            # Lock Button
            # Tlacitko pre zamknutie obrazovky pri editovani
            #--------------------------------------------
            Button:
                id: btn_lock
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)

                lockState: True                         # premenne tlacitka
                background_normal: './icons/unlock.png'
                background_down: './icons/unlock.png'
                changeIcon: lambda background_normal: './icons/unlock.png' if background_normal == './icons/lock.png' else './icons/lock.png'
                switch: lambda x: False if x == True else True
                on_press:
                    btn_lock.background_normal = btn_lock.changeIcon(btn_lock.background_normal)
                    btn_lock.background_down = btn_lock.background_normal
                    btn_lock.lockState = btn_lock.switch(btn_lock.lockState)
                    scroll.do_scroll_x = btn_lock.lockState
                    scroll.do_scroll_y = btn_lock.lockState

            #--------------------------------------------
            # Settings Button
            # Tlacitko pre spravu suborov a nastavenia
            #--------------------------------------------
            Button:
                id: btn_settings
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/settings.png'
                background_down: './icons/settings_sel.png'
                on_press:
                    screen.openSettings()

        BoxLayout:                                      # horizontalne delenie na tlacitka a prac. plochu
            orientation: 'horizontal'
                                                        # ----------------------------------------------------
            BoxLayout:                                  # tlacitka riadenia na lavej strane
                orientation: 'vertical'                 # nastavenie modov editora
                width: '58dp'                           # ----------------------------------------------------
                size_hint_x: None                       # fixna sirka priestoru pre tlacitka
                padding: '5dp'                          # odsadenie doprava
                spacing: '5dp'                          # medzery medzi tlacitkami

                Label:                                  # vertikalne vyrovnanie do stredu
                    text: ''                            # roztahovaci komponent zhora


                #--------------------------------------------
                # VISUAL Button
                # Tlacitko pre volbu modu editora - prepnutie editora do vizualneho modu
                #--------------------------------------------
                Button:
                    id: btn_visual
                    width: '48dp'
                    height: '48dp'
                    border: (0,0,0,0)
                    size_hint:(None, None)
                    background_normal: './icons/display.png'
                    background_down: './icons/display_sel.png'
                    on_press:
                        btn_add.background_normal    = './icons/puzzle.png'
                        btn_draw.background_normal   = './icons/draw_net_2.png'
                        btn_edit.background_normal   = './icons/edit_prop.png'
                        btn_move.background_normal   = './icons/move_item.png'
                        btn_visual.background_normal = './icons/display_sel.png'
                        diagram.mode = 200                 # mode.SIMUL - zrusenie editovania

                #--------------------------------------------
                # LIBRARY Button
                # Tlacitko pre otvorenie kniznice
                #--------------------------------------------
                Button:                                 # tlacitko pridania komponentu z kniznice
                    id: btn_add
                    width: '48dp'
                    height: '48dp'
                    border: (0,0,0,0)
                    size_hint:(None, None)
                    background_normal: './icons/puzzle.png'
                    background_down: './icons/puzzle_sel.png'
                    on_press:
                        btn_add.background_normal    = './icons/puzzle_sel.png'
                        btn_draw.background_normal   = './icons/draw_net_2.png'
                        btn_edit.background_normal   = './icons/edit_prop.png'
                        btn_move.background_normal   = './icons/move_item.png'
                        btn_visual.background_normal = './icons/display.png'

                        # akcia - otvorenie okna kniznice, po uzatvorenie mod presuvania
                        screen.openLibrary()
                        diagram.mode = 10              # mode MOVE - po uzavreti kniznice


                #--------------------------------------------
                # DRAW Button
                # Tlacitko pre editovanie net-u
                #--------------------------------------------
                Button:                                 # tlacitko pridania spojov
                    id: btn_draw
                    width: '48dp'
                    height: '48dp'
                    border: (0,0,0,0)
                    size_hint:(None, None)
                    background_normal: './icons/draw_net_2.png'
                    background_down: './icons/draw_net_2_sel.png'
                    on_press:
                        btn_add.background_normal    = './icons/puzzle.png'
                        btn_draw.background_normal   = './icons/draw_net_2_sel.png'
                        btn_edit.background_normal   = './icons/edit_prop.png'
                        btn_move.background_normal   = './icons/move_item.png'
                        btn_visual.background_normal = './icons/display.png'
                        diagram.mode = 50                # mode ADD_NET

                #--------------------------------------------
                # EDIT Button
                # Tlacitko pre on-screen-menu komponentu
                #--------------------------------------------
                Button:                                 # tlacitko editovanie vlastnosti komponentu
                    id: btn_edit
                    width: '48dp'
                    height: '48dp'
                    border: (0,0,0,0)
                    size_hint:(None, None)
                    background_normal: './icons/edit_prop.png'
                    background_down: './icons/edit_prop_sel.png'
                    on_press:
                        btn_add.background_normal    = './icons/puzzle.png'
                        btn_draw.background_normal   = './icons/draw_net_2.png'
                        btn_edit.background_normal   = './icons/edit_prop_sel.png'
                        btn_move.background_normal   = './icons/move_item.png'
                        btn_visual.background_normal = './icons/display.png'
                        diagram.mode = 100               # mode SETUP komponent

                #--------------------------------------------
                # MOVE Button
                # Tlacitko pre volbu modu editora - presun komponentu, netu alebo ich casti
                #--------------------------------------------
                Button:
                    id: btn_move
                    width: '48dp'
                    height: '48dp'
                    border: (0,0,0,0)
                    size_hint:(None, None)
                    background_normal: './icons/move_item.png'
                    background_down: './icons/move_item_sel.png'
                    on_press:
                        btn_add.background_normal    = './icons/puzzle.png'
                        btn_draw.background_normal   = './icons/draw_net_2.png'
                        btn_edit.background_normal   = './icons/edit_prop.png'
                        btn_move.background_normal   = './icons/move_item_sel.png'
                        btn_visual.background_normal = './icons/display.png'
                        diagram.mode = 10                 # mode.MOVE

                Label:                  # vyrovnanie do stredu
                    text: ''            # roztahovaci komponent zdola

            #Button:
            #    text: 'Widget Editor pre pracovnu plochu'


            #--------------------------------------------
            # Pracovna plocha diagramu
            # Prepinaine scrollovania diagramu zavisi od stavu tlacitka btn_lock
            #--------------------------------------------
            ScrollView:
                id: scroll
                scroll_x: 0.5
                scroll_y: 0.5
                bar_width: 5
                Diagram:
                    id: diagram
                    width: diagram.width
                    height: diagram.height
                    size_hint:(None, None)

                    zoom: 1
                    mode: 10            # Move-10, Edit-20, Net-30, Simul-100,

                    canvas:
                        Scale:
                            x: diagram.zoom
                            y: diagram.zoom
                    Grid:
                        id: grid

<Library>:
    id: library

    BoxLayout:
        orientation: 'horizontal'
        id: lib_layout

        BoxLayout:                                  # tlacitka riadenia na lavej strane
            id: menu_layout
            orientation: 'vertical'                 # nastavenie vyberu kniznice
            width: '58dp'                           # ----------------------------------------------------
            size_hint_x: None                       # fixna sirka priestoru pre tlacitka
            padding: '5dp'                          # odsadenie doprava
            spacing: '5dp'                          # medzery medzi tlacitkami

            canvas.before:
                Color:
                    rgba: 47. / 255., 47. / 255., 47. / 255, 1.

                Rectangle:
                    # self here refers to the widget i.e FloatLayout
                    pos: self.pos
                    size: self.size

            Label:                                  # vertikalne vyrovnanie do stredu
                text: ''

            Button:
                id: btn_lib_source                  # kniznica Source
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/lib_source_2.png'
                background_down: './icons/lib_source_2_sel.png'
                on_press:
                    library.switchLib(0)
                    btn_lib_source.background_normal = './icons/lib_source_2_sel.png'
                    btn_lib_sinks.background_normal  = './icons/lib_sinks_2.png'
                    btn_lib_signal.background_normal = './icons/signal.png'
                    btn_lib_chart.background_normal  = './icons/lib_chart.png'
                    btn_lib_math.background_normal   = './icons/math.png'
                    btn_lib_digital.background_normal= './icons/electronics.png'
                    btn_lib_analog.background_normal = './icons/electrical_sensor.png'
                    btn_lib_clock.background_normal  = './icons/lib_clock.png'
                    btn_lib_visual.background_normal = './icons/slider.png'

            Button:
                id: btn_lib_sinks                   # kniznica Sinks
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/lib_sinks_2.png'
                background_down: './icons/lib_sinks_2_sel.png'
                on_press:
                    library.switchLib(1)
                    btn_lib_source.background_normal = './icons/lib_source_2.png'
                    btn_lib_sinks.background_normal  = './icons/lib_sinks_2_sel.png'
                    btn_lib_signal.background_normal = './icons/signal.png'
                    btn_lib_chart.background_normal  = './icons/lib_chart.png'
                    btn_lib_math.background_normal   = './icons/math.png'
                    btn_lib_digital.background_normal= './icons/electronics.png'
                    btn_lib_analog.background_normal = './icons/electrical_sensor.png'
                    btn_lib_clock.background_normal  = './icons/lib_clock.png'
                    btn_lib_visual.background_normal = './icons/slider.png'

            Button:
                id: btn_lib_signal
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/signal.png'
                background_down: './icons/signal_sel.png'
                on_press:
                    library.switchLib(2)
                    btn_lib_source.background_normal = './icons/lib_source_2.png'
                    btn_lib_sinks.background_normal  = './icons/lib_sinks_2.png'
                    btn_lib_signal.background_normal = './icons/signal_sel.png'
                    btn_lib_chart.background_normal  = './icons/lib_chart.png'
                    btn_lib_math.background_normal   = './icons/math.png'
                    btn_lib_digital.background_normal= './icons/electronics.png'
                    btn_lib_analog.background_normal = './icons/electrical_sensor.png'
                    btn_lib_clock.background_normal  = './icons/lib_clock.png'
                    btn_lib_visual.background_normal = './icons/slider.png'

            Button:
                id: btn_lib_chart                   # kniznica Graph
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/lib_chart.png'
                background_down: './icons/lib_chart_sel.png'
                on_press:
                    library.switchLib(3)
                    btn_lib_source.background_normal = './icons/lib_source_2.png'
                    btn_lib_sinks.background_normal  = './icons/lib_sinks_2.png'
                    btn_lib_signal.background_normal = './icons/signal.png'
                    btn_lib_chart.background_normal  = './icons/lib_chart_sel.png'
                    btn_lib_math.background_normal   = './icons/math.png'
                    btn_lib_digital.background_normal= './icons/electronics.png'
                    btn_lib_analog.background_normal = './icons/electrical_sensor.png'
                    btn_lib_clock.background_normal  = './icons/lib_clock.png'
                    btn_lib_visual.background_normal = './icons/slider.png'

            Button:                                 # kniznica Math
                id: btn_lib_math
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/math.png'
                background_down: './icons/math_sel.png'
                on_press:
                    library.switchLib(4)
                    btn_lib_source.background_normal = './icons/lib_source_2.png'
                    btn_lib_sinks.background_normal  = './icons/lib_sinks_2.png'
                    btn_lib_signal.background_normal = './icons/signal.png'
                    btn_lib_chart.background_normal  = './icons/lib_chart.png'
                    btn_lib_math.background_normal   = './icons/math_sel.png'
                    btn_lib_digital.background_normal= './icons/electronics.png'
                    btn_lib_analog.background_normal = './icons/electrical_sensor.png'
                    btn_lib_clock.background_normal  = './icons/lib_clock.png'
                    btn_lib_visual.background_normal = './icons/slider.png'

            Button:
                id: btn_lib_digital
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/electronics.png'
                background_down: './icons/electronics_sel.png'
                on_press:
                    library.switchLib(5)
                    btn_lib_source.background_normal = './icons/lib_source_2.png'
                    btn_lib_sinks.background_normal  = './icons/lib_sinks_2.png'
                    btn_lib_signal.background_normal = './icons/signal.png'
                    btn_lib_chart.background_normal  = './icons/lib_chart.png'
                    btn_lib_math.background_normal   = './icons/math.png'
                    btn_lib_digital.background_normal= './icons/electronics_sel.png'
                    btn_lib_analog.background_normal = './icons/electrical_sensor.png'
                    btn_lib_clock.background_normal  = './icons/lib_clock.png'
                    btn_lib_visual.background_normal = './icons/slider.png'

            Button:
                id: btn_lib_analog
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/electrical_sensor.png'
                background_down: './icons/electrical_sensor_sel.png'
                on_press:
                    library.switchLib(6)
                    btn_lib_source.background_normal = './icons/lib_source_2.png'
                    btn_lib_sinks.background_normal  = './icons/lib_sinks_2.png'
                    btn_lib_signal.background_normal = './icons/signal.png'
                    btn_lib_chart.background_normal  = './icons/lib_chart.png'
                    btn_lib_math.background_normal   = './icons/math.png'
                    btn_lib_digital.background_normal= './icons/electronics.png'
                    btn_lib_analog.background_normal = './icons/electrical_sensor_sel.png'
                    btn_lib_clock.background_normal  = './icons/lib_clock.png'
                    btn_lib_visual.background_normal = './icons/slider.png'

            Button:
                id: btn_lib_clock                   # kniznica control
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/lib_clock.png'
                background_down: './icons/lib_clock_sel.png'
                on_press:
                    library.switchLib(7)
                    btn_lib_source.background_normal = './icons/lib_source_2.png'
                    btn_lib_sinks.background_normal  = './icons/lib_sinks_2.png'
                    btn_lib_signal.background_normal = './icons/signal.png'
                    btn_lib_chart.background_normal  = './icons/lib_chart.png'
                    btn_lib_math.background_normal   = './icons/math.png'
                    btn_lib_digital.background_normal= './icons/electronics.png'
                    btn_lib_analog.background_normal = './icons/electrical_sensor.png'
                    btn_lib_clock.background_normal  = './icons/lib_clock_sel.png'
                    btn_lib_visual.background_normal = './icons/slider.png'

            Button:
                id: btn_lib_visual
                width: '48dp'
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                background_normal: './icons/slider.png'
                background_down: './icons/slider_sel.png'
                on_press:
                    library.switchLib(8)
                    btn_lib_source.background_normal = './icons/lib_source_2.png'
                    btn_lib_sinks.background_normal  = './icons/lib_sinks_2.png'
                    btn_lib_signal.background_normal = './icons/signal.png'
                    btn_lib_chart.background_normal  = './icons/lib_chart.png'
                    btn_lib_math.background_normal   = './icons/math.png'
                    btn_lib_digital.background_normal= './icons/electronics.png'
                    btn_lib_analog.background_normal = './icons/electrical_sensor.png'
                    btn_lib_clock.background_normal  = './icons/lib_clock.png'
                    btn_lib_visual.background_normal = './icons/slider_sel.png'

            Label:                                  # vertikalne vyrovnanie do stredu
                text: ''

        RelativeLayout:                             # panel umiestnenia katalogov
            id: kat_panel
            size_hint:(None, None)                  # max. velkost


<FileMenu>:                                         # tlacitkove menu pre vyber aktivity
    id: fileMenu
    FloatLayout:

        BoxLayout:
            id: layout
            padding: 5
            spacing: 5
            orientation: 'vertical'

            Button:
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                text: 'Open'
                on_press:
                    fileMenu.screen.openDialog()

            Button:
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                text: 'Save'
                on_press:
                    fileMenu.screen.saveDialog()

            Button:
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                text: 'Save As'
                on_press:
                    fileMenu.screen.saveAsDialog()

            Button:
                height: '48dp'
                border: (0,0,0,0)
                size_hint:(None, None)
                text: 'New'
                on_press:
                    fileMenu.screen.newDiagram()

<FileOpenChooser>:            # Dialog pre Open file
    id: fileOpenChooser
    BoxLayout:
        orientation: 'vertical'
        padding: 0
        spacing: 10

        FileChooserIconView:
            id: chooser
            path: cwd()
            filters: ['*.pse']

        BoxLayout:
            orientation: 'horizontal'
            padding: 0
            spacing: 10
            size_hint: (1.0, 0.15)

            Button:
                id: button_cancel
                text: 'Cancel'
                on_press:
                    #fileOpenChooser.on_load_cancel(fileOpenChooser)
                    fileOpenChooser.dismiss()

            Button:
                id: button_load
                text: 'Load'
                on_press:
                    fileOpenChooser.on_load_file(fileOpenChooser)
                    fileOpenChooser.dismiss()

<FileSaveChooser>:                # Dialog pre Save, Save As menu
    id: fileSaveChooser
    BoxLayout:
        orientation: 'vertical'
        padding: 0
        spacing: 10

        TextInput:
            id: textInput
            multiline: False
            size_hint: (1, 0.1)
            text: 'filename.pse'

        FileChooserIconView:
            id: chooser
            path: cwd()
            filters: ['*.pse']

        BoxLayout:
            orientation: 'horizontal'
            padding: 0
            spacing: 10
            size_hint: (1.0, 0.15)

            Button:
                id: button_cancel
                text: 'Cancel'
                on_press:
                    fileSaveChooser.dismiss()

            Button:
                id: button_save
                text: 'Save'
                on_press:
                    fileSaveChooser.on_save_file(fileSaveChooser)
                    fileSaveChooser.dismiss()

<About>
    id: about
    GridLayout:
        cols: 2
        orientation: 'vertical'

        #size_hint_x: None
        #size_hint:(1, 1)

        padding: '15dp'                          # odsadenie doprava
        spacing: '15dp'

        row_default_height: 48
        row_force_default: True

        Image:
            height: '48dp'
            source:  './icons/pse2_48x48.png'
            size_hint_x: None
            width: 48

        Label:
            text_size: self.size
            halign: 'left'
            valign: 'middle'
            markup: True
            text: '[b]Logo[/b] \\n    Jana Kollárová    [i]http://www.janakollarova.sk[/i]'

        Image:
            height: '48dp'
            source:  './icons/kivy-logo-black-64.png'
            size_hint_x: None
            width: 48

        Label:
            text_size: self.size
            halign: 'left'
            valign: 'middle'
            markup: True
            text: '[b] Kivy[/b] \\n    Open source Python library    [i]https://kivy.org[/i]'

        Image:
            height: '48dp'
            source:  './icons/icons8-Icons8-48.png'
            size_hint_x: None
            width: 48

        Label:
            text_size: self.size
            halign: 'left'
            valign: 'middle'
            markup: True
            text: '[b] Color & Icon Theme[/b] \\n    Icons8 Team    [i]https://icons8.com[/i]'

        Image:
            height: '48dp'
            source:  './icons/python_48.png'
            size_hint_x: None
            width: 48

        Label:
            text_size: self.size
            halign: 'left'
            valign: 'middle'
            markup: True
            text: '[b] Python[/b] \\n    Python language    [i]https://www.python.org[/i]'

        Image:
            height: '48dp'
            source:  './icons/scipy_med.png'
            size_hint_x: None
            width: 48

        Label:
            text_size: self.size
            halign: 'left'
            valign: 'middle'
            markup: True
            text: '[b] SciPy & NumPy[/b] \\n     Library for scientific computing    [i]https://www.scipy.org/[/i]'

        Label:
            width: 48
            size_hint_x: None
            text: ''

        Label:
            text_size: self.size
            halign: 'left'
            valign: 'middle'
            text: ''
''')


class About(Popup):
    pass


class FileSaveChooser(Popup):
    diagram = None

    def on_save_file(self, obj):
        path = self.ids.chooser.path
        text = self.ids.textInput.text
        self.diagram.fileName = text
        self.diagram.saveFile(path + '/' + text)


class FileOpenChooser(Popup):
    diagram = None

    def on_load_file(self, obj):
        load_files = self.ids.chooser.selection
        if len(load_files) > 0:
            self.diagram.clear()
            self.diagram.loadFile(load_files[0])
            self.diagram.fileName = os.path.basename(load_files[0])


class FileMenu(Widget):
    screen = None


class LibPopup(Popup):
    pass


class Editor(Screen):
    '''!
    GUI editora pre samostatnu obrazovku.

    Aplikacia pse je tvorene niekolkymi samostatnymi obrazovkami, obsah kazdej spravuje samostatna trieda
    Editor. Kazdy Editor je virtualna samostatna aplikacia s moznostou editovania a simulacie
    nezavisle na ostatnych obrazovkách.
    Trieda je vytvorena skriptom v Kivy language, obsahuje vsetky ovladacie komponenty aplikacie.
    Obsahuje metody pre otvore zakladnych pod-okien - kniznice a systemoveho menu (Load/Save ...).
    '''

    def __init__(self, library, icon, **kwargs):
        super().__init__(**kwargs)
        self.library = library
        self.diagram = self.ids.diagram
        self.diagram.editor = self                  # pristup k riadiacim prvkom
        self.scroll = self.ids.scroll
        self.button = self.ids.btn_screen           # tlacitko prepinania obrazovky

        self.button.background_normal = icon        # ikona (identifikacia - porad.cislo) obrazovky
        self.button.background_down = icon

        self.fileMenu = FileMenu()
        self.fileMenu.screen = self

        self.sim = None

    def openLibrary(self):
        '''!
        Otvorenie okna knižnice v editore. Kniznica je sharovany objekt, spolocny pre vsetky
        editory.
        '''
        self.library.diagram = self.diagram                   # inicializacia referencii v objekte Library
        self.library.scroll = self.scroll
        self.library.open()

    def openSettings(self):
        '''!
        Otvorenie systémového dialógu.

        Systémový dialóg obsahuje menu pre nahratie/uloženie diagramu ako aj
        dialógy pre nastavenie vlastnosti editora.
        '''
        self.about = About()                   # dialog pre vyber suboru
        self.about.title = 'pse Credits'
        self.about.size_hint = (0.7, 0.7)
        self.about.open()

    def openFileMenu(self):
        '''
        Otvorenie tlacitkoveho menu pr vyber Load/Save
        '''
        for c in list(self.children):                         # opakovane kliknutie na ikonu zatvori menu
            if isinstance(c, FileMenu):                       # vyhladanie objektu
                self.remove_widget(c)                         # zrusenie widget-u
                return

        menuLayout = self.fileMenu.ids.layout                 # pri otvoreni - odvodenie polohy od ikony a poctu poloziek
        menuLayout.pos = (self.ids.btn_file.pos[0], self.ids.btn_file.pos[1] - 4 * 48 - 4 * 5)
        self.add_widget(self.fileMenu)

    def openDialog(self):
        '''!
        Dialog pre nahratie diagramu zo suboru.
        '''
        self.remove_widget(self.fileMenu)                     # zatvorenie menu s tlacitkami

        self.load_popup = FileOpenChooser()                   # dialog pre vyber suboru
        self.load_popup.title = 'Open'
        self.load_popup.diagram = self.diagram
        self.load_popup.size_hint = (0.7, 0.7)
        self.load_popup.open()

    def saveDialog(self):
        '''!
        Dialog pre ulozenie diagramu do suboru
        '''
        self.remove_widget(self.fileMenu)

        if self.diagram.fileName == '':
            self.diagram.fileName = 'noname.pse'

            self.load_popup = FileSaveChooser()
            self.load_popup.title = 'Save'
            self.load_popup.diagram = self.diagram
            self.load_popup.ids.textInput.text = self.diagram.fileName
            self.load_popup.size_hint = (0.7, 0.7)
            self.load_popup.open()
        else:
            self.diagram.saveFile(self.diagram.fileName)

    def saveAsDialog(self):
        '''!
        Dialog pre ulozenie diagramu do suboru
        '''
        self.remove_widget(self.fileMenu)

        if self.diagram.fileName == '':
            self.diagram.fileName = 'noname.pse'

        self.load_popup = FileSaveChooser()
        self.load_popup.title = 'Save'
        self.load_popup.diagram = self.diagram
        self.load_popup.ids.textInput.text = self.diagram.fileName
        self.load_popup.size_hint = (0.7, 0.7)
        self.load_popup.open()

    def newDiagram(self):
        self.remove_widget(self.fileMenu)
        self.diagram.clear()
        self.diagram.fileName = ''

    def run(self):

        state = self.ids.btn_run.btnState

        if state is True:
            # spustenie systemovych aktivit
            # 1. Ulozenie diagramu do pracovneho suboru
            adr = os.path.dirname(__file__)                   # cesta k aktualnemu suboru (./src/...)
            filename = os.path.join(adr, '../tmp/work.pse')   # meno pracovneho suboru
            self.diagram.saveFile(filename)                   # ulozenie aktualneho stavu

            # 2. Spracovanie diagramu preprocesorom
            ppc = Preprocessor()                              # nahratie diagramu do separatnych struktur
                                                              # vratane vnorenych blokov
            compDict, netDict = ppc.load(filename)            # uprava diagramu (doplnenie virtualnych prepojeni medzi portami)
            checkState, wireDict = ppc.check()                # a kontrola integrity diagramu

           # d = Debug()
            #d.printConn(wireDict)
            #for nid, n in self.diagram.netDict.items():
            #    d.printNet(n)

            controlComp = None                                # kontrola a vyhladanie riadiaceho
            for cid, c in compDict.items():                   # elementu v diagrame
                if c.type == compType.CONTROL:                # v pripade absencie ukoncenie simulacie
                    controlComp = c
                    break

            if controlComp is None:
                Logger.error('Editor: Diagram neobsahuje riadiaci komponent')
                checkState = False

            if checkState is False:
                self.ids.btn_run.btnState = False
                self.ids.btn_run.background_normal = './icons/sys_run.png'
                return

            # 3. Spustenie simulatora a vytvorenie procesov
            self.diagram.mode = mode.SIMUL

            if controlComp.solver == 'RK2':
                self.sim = SimRK2(self.diagram, compDict, netDict, wireDict)

            elif controlComp.solver == 'RK2T':
                self.sim = SimRK2T(self.diagram, compDict, netDict, wireDict)
            else:
                return

            self.sim.run()

        else:
            # Ukoncenie simulacneho procesu uzivatelom - tlacitkom
            self.diagram.mode = mode.MOVE
            self.sim.stop()

    def stop(self):
        # Programove ukoncenie procesu simulacie
        self.ids.btn_run.btnState = False
        self.ids.btn_run.background_normal = './icons/sys_run.png'

        self.diagram.mode = mode.MOVE
        self.updateMode(mode.MOVE)

        if self.sim is not None:
            self.sim.stop()

    def updateMode(self, m):
        # pomocna funkcia pre upravu stavu tlacitiek a menu pri programovej zmene
        # modov editora

        if m == mode.NONE:                                    # kliknutie na ploche editora
            self.remove_widget(self.fileMenu)                 # zatvorenie FileMenu - bez vyberu

        if m == mode.MOVE:
            self.ids.btn_add.background_normal = './icons/puzzle.png'
            self.ids.btn_draw.background_normal = './icons/draw_net_2.png'
            self.ids.btn_edit.background_normal = './icons/edit_prop.png'
            self.ids.btn_move.background_normal = './icons/move_item_sel.png'
            self.ids.btn_visual.background_normal = './icons/display.png'


class PSE(App):
    '''!
    Hlavna trieda aplikacie.

    Sprava virtualnych obrazoviek, obsahujucich samostatne editory diagramov.
    Editory sú vzájomne oddelené a nezdieľajú nijaké dáta.
    '''
    def build(self):
        self.library = Library()
        self.library.switchLib(0)

        self.sm = ScreenManager(transition=FadeTransition())
        self.editorList = []

        for i in range(1, 5):                                 # standardne 4 obrazovky, @ToDo parametrizovat
            e = Editor(self.library, './icons/scr_' + str(i) + '.png', name='Screen_' + str(i))
            self.editorList.append(e)
            self.sm.add_widget(e)

        return self.sm

    def on_stop(self):
        '''!
        Systemove aktivity pri uzatvoreni aplikacie.
        '''
        for ed in self.editorList:                             # zastavenie vsetkych beziacich procesov
            ed.stop()
