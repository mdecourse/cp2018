# -*- coding: utf-8 -*-
import math

from kivy.uix.widget import Widget
from kivy.uix.popup import Popup

from cfg.config_lib import *
from cfg.config_pse import *


class Library(Popup):
    '''!
    Spolocna zdielana kniznica pre vsetky editory.
    '''

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.katalogPanel = self.ids.kat_panel
                                                              # ref. na casti editora, aktualizuju sa pred otvorenim okna
        self.diagram = None                                   # ref. na editor, aktualizuje sa pred otvorenim okna
        self.scroll = None                                    # vypocet aktulanej polohy

        self.katalogList = []                                 # vyvorenie pola kniznic podla konfiguracie
        for (libName, libRef) in libConfig:                   # polozky konfiguracie (meno katalogu, polozky katalogu)
            k = Katalog(self, libName, libRef)
            k.build()
            self.katalogList.append(k)

    def switchLib(self, typ):
        self.katalogPanel.clear_widgets()                     # prepinanie kniznic
        try:
            self.katalogPanel.add_widget(self.katalogList[typ])
            self.title = self.katalogList[typ].libName
        except:
            pass                                              # neinmplementovany katalog, ignorovana kniznica


class Katalog(Widget):

    def __init__(self, library, name, items, **kwargs):
        super().__init__(**kwargs)

        self.libName = name
        self.libItems = items
        self.library = library

    def build(self):
        '''!
        Vytvorenie kniznice komponentov.
        '''
        for (className, pos, desc) in self.libItems:
            comp = globals()[className]()
            comp.pos = pos
            for n, p in comp.paramDict.items():               # zrusenie zobrazenia atributov
                if p.isLocked is False:                       # zrusenie viditelnosti len pre pohyblive parametre
                    p.isVisible = False

            comp.getParam('Name').value = desc                # zobrazenie mena komponentu
            comp.getParam('Name').isVisible = True
            if comp.hasIcon is True:
                comp.getParam('Name').pos = (0, -35)
            else:
                comp.getParam('Name').pos = (0, -comp.border[3] / 2 - 10)
            comp.build()
            comp.update()
            self.add_widget(comp)

    def on_touch_down(self, touch):
        '''!
        Spracovanie kliknutia na komponent v kniznici.

        Vytvori novu instanciu komponentu a zaradi ju do editora.
        '''
        #----------------------------------------------------------
        # 1. konverzia lokalnych suradnic do pozicie na scroll
        #----------------------------------------------------------

        (wx, wy) = self.library.scroll.pos                    # poloha scroll okna
        (px, dx) = self.library.scroll.hbar                   # posun okna velkost okna
        (py, dy) = self.library.scroll.vbar                   # rozsah <0,1>

        px = px * self.library.diagram.width
        py = py * self.library.diagram.height

        tx = (touch.x - wx + px + 58 + 10)                    # poloha kliknutia mysi na obrazovke
        ty = (touch.y - wy + py + 10)                         # vzhladom na absolutnu polohu scroll okna

        #----------------------------------------------------------
        # 2. vyhladanie komponentu v kniznici
        #----------------------------------------------------------
        name = None                                           # urcenie najblizsieho komponentu v paneli
        minDistance = float('infinity')
        qx = touch.x
        qy = touch.y
        for (itemName, itemPos, _) in self.libItems:          # prehladanie zoznamu komponentov kniznice
            dist = math.hypot(dp(itemPos[0]) - qx, dp(itemPos[1]) - qy)
            if dist < minDistance:
                name = itemName                               # meno
                minDistance = dist                            # vzdialenost od kliknutia

        #----------------------------------------------------------
        # 3. vytvorenie komponentu a zaradenie do diagramu
        #----------------------------------------------------------
        if minDistance < 40:                                  # identifikovany komponent
            comp = self.library.diagram.addComp(globals()[name](), (tx, ty))
            comp.getParam('Name').value = name
            comp.hasIcon = False                              # zrusenie zobrazenia ako ikony (velke komponenty)
            comp.isSelected = True
            comp.build()
            comp.update()
            self.library.diagram.mode = mode.MOVE_COMP
            self.library.dismiss()