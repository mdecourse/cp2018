# -*- coding: utf-8 -*-
import numpy
from collections import OrderedDict

from kivy.graphics import *
from kivy.uix.widget import Widget
from kivy.graphics.vertex_instructions import Rectangle, RoundedRectangle
from kivy.metrics import dp
from kivy.logger import Logger

from src.common import *
from src.terminal import *
from cfg.config_pse import *


class Component(Widget):
    '''!
    Supertriedy pre zakladne typy komponentov.

    Typ komponentu       | Popis
    ---------------------|----------------------------------------------------------------
    BoxComponent         | krabicovy komponent, standardne vstupne term. vlavo, vystupme vpravo
    WireComponent        | drotovy komponent poskladany z grafickych elementov (line, arc, circle)
    InteractiveComponent | interaktivny GUI komponent
    Decoration           | doplnkovy / informacny komponent bez terminalov
    Joint                | špeciálny prepojovací komponent

    @todo Implementovat chybajuce typy komponentov
    @todo Lock/Unlock komponent - zakazat zmenu polohy, zakazat zmenu parametrov
    @todo Komponenty s menitelnymi rozmermi
    @todo Zobrazenie parametrov komponentov a ich editovanie na ploche

    Komponent ma dve zakladne graficke metody (jednotne pre cely projekt):
        build()    - vytvorenie alebo zmena reprezentacie komponentu
        update()   - aktualizacia polohy komponentu
        rebuild()  - zjednodusene volanie build a update

    @todo Uprava a doplnenie metod pre dynamicke zobrazenie komponentu
        addTerminal    - standardne pridanie terminalu
        getTerminal    - (IMPLEMENTOVANA) referencia na terminal
        delTerminal - zmazanie terminalu a pripojenych net-ov
    '''

    def __init__(self):

        super(Component, self).__init__()

        self.cid = 0                             # unikatne referencne cislo (prideluje sa v addComponent)
        self.diagram = None                      # referencia na diagram v ktorom je komponent pouzity
        self.type = compType.NONE                # typ komponentu
        self.pos = (0, 0)                        # poloha komponentu

                                                 #----------------------------------------
                                                 # stavove parametre
                                                 #----------------------------------------
        self.isVisible = True                    # viditelnost komponentu
        self.isSelected = False                  # vyber komponentu
        self.isLocked = False                    # uzamknutie komponentu - zabranenie posuvaniu (vratane parametrov)
        self.isScalable = False                  # moznost menit rozmery komponentu na ploche
        self.hasIcon = False                     # v kniznici sa zobrazuje ako ikona (pre velke komponenty)
        self.hasMenu = False                     # viditelnost on-screen-menu komponentu
        self.swapHoriz = False
        self.swapVert = False
        self.rotAngle = 0

                                                 #----------------------------------------
                                                 # graficke parametre
                                                 #----------------------------------------
        self.image = None                        # parametre vyplne komponentu - cesta k *.png obrazku
        self.shapeColor = color.skyBlue          # vnutrajsok komponentu
        self.shapeBorderColor = color.lightBlue  # oramovanie komponentu
        self.border = None                       # vonkajsia hranica komponentu - rozmery
        self.borderColor = color.red             # farba hranice pri selektovanom komponente

        self.termDict = OrderedDict()            # slovnik terminalov
        self.paramDict = OrderedDict()           # slovnik parametrov
        self.menu = self.OnScreenMenu(self)      # referencia na on-screen-menu komponentu

                                                 # referencia komponentu, default parameter
        Parameter(self, 'Ref', 'Component reference', 'A' + str(self.cid))
        Parameter(self, 'Name', 'Component name', 'Name')

        self.seqCounter = 0                                   # pocitadlo poradia evaluacie bloku

    def addSeqCount(self, val, wireDict):
        # inkrementacia sekvencneho pocitadla, pocitadlo ma vzdy vyssiu hodnotu ako predchadzajuci
        # blok, ktory funkciu vyvolal
        # kontrola numerickej slucky v grafe
        # vypocet poradia komponentov pri numerickych vypoctoch pre CONTINUOUS komponenty`
        if self.seqCounter < val:
            self.seqCounter = val
        self.seqCounter = self.seqCounter + 1

        if self.seqCounter > 100:                             # kontrola hlbky rekurzie
            return False                                      # numericka slucka v diagrame

        for tnum, t in self.termDict.items():                 # rekurzivne volanie inkrementacie sekv. pocitadla
            if t.type == termType.OUTPUT:
                tlist = wireDict[t]
                for ts in tlist:
                    if (ts.comp.type & compType.CONTINUOUS) == compType.CONTINUOUS:   # dalsi pripojeny komponent
                        if ts.comp.addSeqCount(self.seqCounter, wireDict) is False:
                            return False

                    #else:
                    #    return True
                    #elif ts.comp.type == compType.DISCRETE:    # ukoncenie na diskretnych komponentoch
                    #    return True
        return True

    def build(self):
        # vytvorenie grafickej reprezentacie komponentu
        # bez umiestnenia na realne suradnice na ploche
        # metoda sa vola pri zmene tvaru / formy komponentu (vytvorenie menu, zmena poctu terminalov)
        self.canvas.clear()         # inicializacia grafickeho stacku
        self.clear_widgets()

        if self.hasMenu is True:    # vytvorenie aktivneho menu
            self.menu.build()

    def update(self):
        # umiestnenie komponentu na suradnice na ploche,
        # metoda sa vola pri zmene polohy komponentu
        if self.hasMenu is True:
            self.menu.update()

    def rebuild(self):
        self.build()
        self.update()

    def swapVertical(self):
        pass

    def swapHorizontal(self):
        pass

    def rotateLeft(self):
        pass

    def rotateRight(self):
        pass

    def addTerminal(self):
        pass

    def delTerminal(self, num):
        del self.termDict[num]

    def getTerminal(self, num):
        return self.termDict[num]

    def delParameter(self, name):
        del self.paramDict[name]

    def getParam(self, name):
        return self.paramDict[name]

    def getParValue(self, name):
        return self.paramDict[name].value

    def setParValue(self, name, value):
        self.paramDict[name].checkValue(value)

    def eval(self, state, time=0):
        '''!
        Inicializacia / vyhodnotenie / vypocet / generovanie aktivity komponentu.
        '''
        pass

    class OnScreenMenu():
        '''!
        Graficke menu komponentu, vnutorna trieda
        '''
        def __init__(self, comp):

            self.comp = comp

            self.itemSize = (dp(30), dp(30))

            self.itemSetup = Rectangle(size=self.itemSize, source='./icons/settings.png')
            self.itemDelete = Rectangle(size=self.itemSize, source='./icons/trash.png')
            self.itemSwapHor = Rectangle(size=self.itemSize, source='./icons/swap_hor.png')
            self.itemSwapVert = Rectangle(size=self.itemSize, source='./icons/swap_vert.png')
            self.itemCopy = Rectangle(size=self.itemSize, source='./icons/copy.png')
            self.itemVertx = Rectangle(size=self.itemSize, source='./icons/conv_vertx.png')
            # @ToDo 039 locked / unlocked komponent

            # polozky on-screen menu - orientacia okolo komponentu
            #     6  7  0
            #     5  8  1
            #     4  3  2
            # pole poloziek - ikony, nepouzite pozicie maju hodnotu None
            # default hodnoty, v dedenej triede je mozne zoznam modifikovat
            self.menuItems = [self.itemSetup,        # 0
                              None,                  # 1
                              self.itemDelete,       # 2
                              self.itemSwapHor,      # 3
                              None,                  # 4
                              self.itemSwapVert,     # 5
                              self.itemCopy,         # 6
                              None,                  # 7
                              None]                  # 8  stred

            # pole navratovych hodnot zodpovedajucich polozkam menu
            self.itemValue = [mode.SETUP_COMP,       # 0
                              0,                     # 1
                              mode.DEL_COMP,         # 2
                              mode.SWP_HORZ,         # 3
                              0,                     # 4
                              mode.SWP_VERT,         # 5
                              mode.COPY_COMP,        # 6
                              0,                     # 7
                              0]

        def build(self):
            # pole offsetov poloziek menu voci (pos[0]+border[0], pos[1]+border[1]) - lavy dolny roh
            self.itemsPos = [(self.comp.border[2], self.comp.border[3]),                                # 0
                            (self.comp.border[2], self.comp.border[3] / 2 - self.itemSize[1] / 2),      # 1
                            (self.comp.border[2], -self.itemSize[1]),                                   # 2
                            (self.comp.border[2] / 2 - self.itemSize[0] / 2, - self.itemSize[1]),       # 3
                            (- self.itemSize[0], - self.itemSize[1]),                                   # 4
                            (- self.itemSize[0], self.comp.border[3] / 2 - self.itemSize[1] / 2),       # 5
                            (- self.itemSize[0], self.comp.border[3]),                                  # 6
                            (0, self.comp.border[3]),                                                   # 7
                            (self.comp.border[2] / 2 - self.itemSize[0] / 2, self.comp.border[3] / 2 - self.itemSize[1] / 2)]

            self.comp.canvas.add(RGBA_Color(color.white))
            for i in range(9):                # zaradenie poloziek do zoznamu
                m = self.menuItems[i]
                if m is not None:
                    self.comp.canvas.add(m)

        def update(self):
            for i in range(9):                 # prepocet polohy poloziek menu
                m = self.menuItems[i]
                (px, py) = self.itemsPos[i]
                if m is not None:
                    m.pos = (self.comp.pos[0] + self.comp.border[0] + px, self.comp.pos[1] + self.comp.border[1] + py)

        def value(self, pos):
            '''!
            Vrati hodnotu modu zodpovedajuci kliknutiu na ikonu menu,None v pripade kliknutia mimo.
            Hodnoty su preddefinovane v poli self.itemValue.
            '''
            for i in range(9):
                (px, py) = self.itemsPos[i]
                x = self.comp.pos[0] + self.comp.border[0] + px
                y = self.comp.pos[1] + self.comp.border[1] + py

                if x <= pos[0] <= x + self.itemSize[0]:
                    if y <= pos[1] <= y + self.itemSize[1]:
                        return self.itemValue[i]
            return None


class Parameter(Widget):
    '''!
    Trieda parametra komponentu.

    Parameter je editovateľná vlastnosť komponentu, ktorá môže parametrizovať jeho chovanie
    alebo jeho vzhľad.

    Parameter <b>value</b> určuje zároveň aj typ vlastnosti a formu, v akej bude editovana
    v nastaveniach komponentu. Typ parametra (self.type) je odvodený z dátového typu <b>value</b>
    a nie je vhodné ho meniť (podľa dátového typu sú vygenerované ďalšie atribúty triedy
    napr. self.min, self.max a pod.)

    Formát                |  Popis
    ----------------------|-------------------------------
    bool                  | logická hodnota
    string                | textová hodnota
    int                   | numerická hodnota
    float                 | numerická hodnota
    (value, min, max)     | tuple, trojica numerických hodnôt s definovaným rozsahom
    [item1, item2 ...]    | pole numerických alebo textových hodnôt pre výber zo zoznamu
    '''

    def __init__(self, item, name, description, value, visible=False, pos=(0, 0), visibleName=False):
        '''!
        Konštruktor parametra.

        @param name        Meno vlastnosti
        @param description Popis vlastnosti
        @param value       Hodnota, formát hodnoty je nižšie v tabuľke
        @param visibility  Viditeľnosť parametru na ploche diagramu
        @param pos         Počiatočná relatívna poloha parametru vzhľadom ku komponentu

        Pridanie novej vlastnosti do zoznamu vlastnosti. V menu nastavenia vlastnosti komponentu
        sa vlastnosti zobrazuju v takom poradi, v akom boli vytvorene.
        '''
        super(Parameter, self).__init__()

                                             # vseobecne atributy
        self.item = item                     # comp alebo net, obsahuje paramDict
        self.name = name
        self.type = parType.NONE
        self.value = None                    # inicializuje sa v checkValue()
        self.listValue = []                  # fixne hodnoty pre vyber zo zoznamu hodnot
        self.description = description       # popis vlastností, druhý riadok v editore

                                             # graficke atributy
        self.isSelected = False              # parameter je selktovany pre posun (alebo editovanie priamo z plochy TODO 058/SYS)
        self.isVisible = visible             # parameter viditelny na pracovnej ploche
        self.isNameVisible = visibleName     # meno parametra viditelne na pracovnej ploche
        self.isLocked = False                # parameter je viazany na polohu komponentu

                                             # vlastnosti textu parametra
        self.pos = (dp(pos[0]), dp(pos[1]))
        self.color = conf.parColor                 # standardna farba parametra
        self.selectedColor = conf.parColorSel      # farba selektovaneho parametra
        self.bold = False                          # parametre pisma
        self.italic = False
        self.fontSize = dp(15)
        self.text_size = (0, 0)              # velkost text (x,y rozmer)- inicializuje sa po renderovanie textu na placovnej ploche
                                             # @ToDo doplnit typ / meno fontu

        self.checkValue(value)
        self.item.paramDict[self.name] = self     # zaradenie do slovnika

    def checkValue(self, value):
        # priradenie hodnoty a typu parametra - odvodene podla typu vstupnej premennej value
        # typ hodnoty urcuje format editora pre jej editovanie / nastavenie

        # jednoduche hodnoty
        if type(value) == bool:
            self.type = parType.BOOL
            self.value = value

        elif type(value) == int:
            self.type = parType.INT
            self.value = value

        elif type(value) == float or type(value) == numpy.float64:
            self.type = parType.FLOAT
            self.value = numpy.float64(value)

        elif type(value) == str:
            self.type = parType.STRING
            self.value = value

        elif type(value) == complex:
            self.type = parType.COMPLEX
            self.value = value

        # pole hodnot
        elif type(value) == list:
            self.type = parType.LIST
            self.listValue = value        # pole nemennych hodnot
            self.value = value[0]         # aktualna hodnota

        # hodnoty s hranicami (val, min, max) alebo (val, min), val moze byt int alebo float
        elif type(value) == tuple:
            if type(value[0]) == int:
                self.type = parType.INT_MIN_MAX
                self.value = value[0]

            elif type(value[0]) == float:
                self.type = parType.FLOAT_MIN_MAX
                self.value = value[0]
            else:
                Logger.error('Parameter: checkValue - nedefinovany typ v tuple ' + str(type(value)))
                self.value = 0
                self.type = parType.NONE

            if len(value) == 2:
                self.min = value[1]
                self.max = 10e6
            elif len(value) == 3:
                self.min = value[1]
                self.max = value[2]
        else:
            Logger.error('Parameter: checkValue - neimplementovany typ hodnoty ' + str(type(value)))

    def build(self):
        self.canvas.clear()
        self.clear_widgets()
        self.label = Label(text='', markup=False, font_size=self.fontSize)
        if self.isVisible is True:
            self.label.italic = True
            self.label.size = (0, 0)
            self.add_widget(self.label)

    def update(self):
        if self.isVisible is True:
            if type(self.value) == str:
                text = self.value   # , "utf-8")
            else:
                text = str(self.value)

            if self.isNameVisible is True:
                self.label.text = self.name + '=' + text
            else:
                self.label.text = text

            self.label.pos = (self.item.pos[0] + self.pos[0], self.item.pos[1] + self.pos[1])

            if self.isSelected is False:
                self.label.color = self.color
            else:
                self.label.color = self.selectedColor

            self.label.texture_update()                   # velkost zobrazeneho textu - podla rozlisenia obrazovky
            self.text_size = self.label.texture_size      # priradenie velkosti textu


class BoxComponent(Component):
    '''!
    Supertrieda pre štandardný krabicovy komponent.
    '''
    def __init__(self):
        '''!
        '''
        super().__init__()
                                                           # zobrazenie komponentu
        self.border = (dp(-25), dp(-25), dp(50), dp(50))   # vonkajsi obrys komponentu vzhladom k originu, [x,y,w,h]
        self.radius = [dp(5), dp(5), dp(5), dp(5)]

        p = self.getParam('Ref')
        p.pos = (dp(0), dp(35))                            # poloha parametra Ref - nad komponentom
        p.isVisible = True

        self.getParam('Name').pos = (0, -35)

    def swapHorizontal(self):
        '''!
        Preklopenie komponentu horizontálne.

        Pri preklopení sa vymenia polohy a smery terminálov.
        '''
        if self.swapHoriz is False:
            self.swapHoriz = True
        else:
            self.swapHoriz = False

        for (num, t) in self.termDict.items():
            t.pos = (-t.pos[0], t.pos[1])
            t.namePos = (-t.namePos[0], t.namePos[1])
            t.numPos = (-t.numPos[0], t.numPos[1])
            if t.orient == termDir.EAST:
                t.orient = termDir.WEST
            elif t.orient == termDir.WEST:
                t.orient = termDir.EAST

    def build(self):
        '''!
        '''
        super().build()

        self.shape = RoundedRectangle(radius=self.radius)    # vnutrajsok komponentu
        self.borderShape = Line()                            # oramovanie komponentu
        self.borderSelected = Line()                         # hranica komponentu (pre selektovanie)|

        self.canvas.add(RGBA_Color(self.shapeColor))
        self.canvas.add(self.shape)

        if self.image is not None:                           # obrazok komponentu - ak je definovany
            self.canvas.add(RGBA_Color(color.white))         # nastavenie farby pre obrazok - priesvitnost
            self.shapeImage = Rectangle(size=(dp(40), dp(40)))
            self.shapeImagePos = (dp(-20), dp(-20))
            self.shapeImage.source = self.image              # cesta k obrazku @ToDo - osetrit pre chybu
            self.canvas.add(self.shapeImage)

        self.canvas.add(RGBA_Color(self.shapeBorderColor))
        self.canvas.add(self.borderShape)

        if self.isSelected is True:
            self.canvas.add(RGBA_Color(self.borderColor))
            self.canvas.add(self.borderSelected)

        for key, t in self.termDict.items():
            self.add_widget(t)
            t.build()

        for key, p in self.paramDict.items():
            self.add_widget(p)
            p.build()

    def update(self):
        '''!
        Pri nezadanej pozicii sa komponent prekresli na aktualnej pozicii.
        '''
        super().update()    # aktualizacia polohy menu komponentu

        (dx, dy, w, h) = self.border

        self.shape.pos = (self.pos[0] + dx, self.pos[1] + dy)
        self.shape.size = (w, h)

        if self.image is not None:
            self.shapeImage.pos = (self.pos[0] + self.shapeImagePos[0], self.pos[1] + self.shapeImagePos[1])

        self.borderShape.rounded_rectangle = [self.pos[0] + dx, self.pos[1] + dy] + [w, h] + self.radius

        if self.isSelected is True:
            self.borderSelected.rectangle = (self.pos[0] + dx - 2, self.pos[1] + dy - 2, w + 4, h + 4)

        for key, t in self.termDict.items():
            t.update()

        for key, p in self.paramDict.items():
            p.update()


class Connection(Component):
    '''!
    Trieda prepojovacieho komponentu.

    Obsahuje jeden neviditelny terminál pre spojenie dvoch alebo viacerých sietí.
    @ToDo Moze byt pouzity pre ukoncenie prepojenia pri zmazani komponentu (riskantne, osetrit)
    '''
    def __init__(self):
        super().__init__()
        self.type = compType.CONN
        self.size = (dp(8.0), dp(8.0))
        self.border = [-self.size[0] / 2 - 2, -self.size[1] / 2 - 2, self.size[0] + 4, self.size[1] + 4]
        self.color = color.green
        self.colorSel = color.red
        self.isOnBus = False

        self.term = VirtualTerm(self, 1, 'InOut', (0, 0), termType.CONN)
        self.getParam('Name').value = 'Connection'

        self.shape = Ellipse(size=self.size)
        self.selBorder = Line()

        # uprava poloziek on-srcreen-menu
        self.menu.menuItems = [None,                  # 0
                               None,                  # 1
                               self.menu.itemDelete,  # 2
                               None,                  # 3
                               self.menu.itemVertx,   # 4
                               None,                  # 5
                               None,                  # 6
                               None,                  # 7
                               None]                  # 8  stred

        self.menu.itemValue = [0,                     # 0
                               0,                     # 1
                               mode.DEL_JUNCT,        # 2
                               0,                     # 3
                               mode.JNC_2_VTX,        # 4
                               0,                     # 5
                               0,                     # 6
                               0,                     # 7
                               0]

    def build(self):
        super().build()

        self.canvas.add(RGBA_Color(self.color))
        self.canvas.add(self.shape)

        if self.isSelected is True:
            self.canvas.add(RGBA_Color(self.colorSel))
            self.canvas.add(self.selBorder)

    def update(self):
        super().update()

        (dx, dy, w, h) = self.border
        self.shape.pos = (self.pos[0] + dx + 2, self.pos[1] + dy + 2)
        if self.isSelected is True:
            self.selBorder.rectangle = (self.pos[0] + dx, self.pos[1] + dy, w, h)

        # prekreslenie vsetkych pripojenych sieti, iteracia po zozname terminalov a k nim pripojenym sietam
        #for num, t in self.termDict.items():
        #    for nid, n in t.netDict.items():
        #        n.update()
        #bus = False
        #for nid, n in self.term.netDict.items():
        #    if (n.startTerm.type != termType.INPUT) and (n.endTerm.type != termType.INPUT):
        #        if n.isBus is True:
        #            bus = True
        #            break
        #
        for nid, n in self.term.netDict.items():
            n.update()
        #   if bus == True:
        #        n.isBus = True
        #    n.update()


class VirtualConn(Component):
    '''!
    Trieda prepojovacieho komponentu.

    Obsahuje jeden terminál pre spojenie dvoch alebo viacerých sietí.
    '''
    def __init__(self):
        '''
        '''
        super().__init__()
        self.type = compType.CONN_VIRTUAL
        VirtualTerm(self, -1, 'Conn', (0, 0), termType.CONN)


class AnalogComp(Component):
    '''!
    Supertrieda pre analogovy komponent (trojuholnik).
    '''
    def __init__(self):
        super().__init__()

        p = self.getParam('Ref')
        p.pos = (dp(5), dp(30))                               # poloha parametra Ref - nad komponentom
        p.isVisible = True

        self.inp = TermJoint(self, 1, 'In', (-40, 0), termType.INPUT)
        self.out = TermJoint(self, 2, 'Out', (40, 0), termType.OUTPUT)

        self.border = (dp(-40), dp(-30), dp(80), dp(60))
        self.shape = Mesh(mode='triangle_fan', indices=(0, 1, 2, 3, 4, 5, 6))

        self.line1 = SmoothLine()
        self.line2 = SmoothLine()
        self.line3 = SmoothLine()
        self.line4 = SmoothLine()

        self.vertex = [-25, -30, -30, -30, -30, 30, -25, 30, 30, 0, -25, -30]
        self.lineVert = [dp(-25), dp(-30), dp(-25), dp(30)]
        self.shapeImagePos = [dp(-22), dp(-19)]

        self.menu.menuItems[5] = None                         # zrusenie polozky vertikalneho preklopenia

    def build(self):
        super().build()

        self.canvas.add(RGBA_Color(self.shapeColor))
        self.canvas.add(self.shape)
        self.canvas.add(RGBA_Color(self.boxColor))
        self.canvas.add(self.line1)
        self.canvas.add(self.line2)
        self.canvas.add(self.line3)
        self.canvas.add(self.line4)

        if self.image is not None:                            # obrazok komponentu - ak je definovany
            self.canvas.add(RGBA_Color(color.yellow))         # nastavenie farby pre obrazok - priesvitnost
            self.shapeImage = Rectangle(size=(dp(15), dp(38)))

            self.shapeImage.source = self.image               # cesta k obrazku @ToDo - osetrit pre chybu
            self.canvas.add(self.shapeImage)

        for key, t in self.termDict.items():
            self.add_widget(t)
            t.build()

        for key, p in self.paramDict.items():
            self.add_widget(p)
            p.build()

    def update(self):
        super().update()

        vertices = []
        for i in range(0, len(self.vertex), 2):
            vertices.append(self.pos[0] + dp(self.vertex[i]))
            vertices.append(self.pos[1] + dp(self.vertex[i + 1]))
            vertices.append(0)
            vertices.append(0)
        self.shape.vertices = vertices

        points = []
        for i in range(0, len(self.vertex), 2):               # obrysova ciara odvodena z tvaru shape
            points.append(self.pos[0] + dp(self.vertex[i]))
            points.append(self.pos[1] + dp(self.vertex[i + 1]))
        self.line1.points = points

        self.line2.points = (self.lineVert[0] + self.pos[0],  # vertikalna ciara pri vstupe
                             self.lineVert[1] + self.pos[1],
                             self.lineVert[2] + self.pos[0],
                             self.lineVert[3] + self.pos[1])

        self.line3.points = (dp(-40) + self.pos[0], 0 + self.pos[1], dp(-30) + self.pos[0], 0 + self.pos[1])    # ciary k terminalom
        self.line4.points = (dp(40) + self.pos[0], 0 + self.pos[1], dp(30) + self.pos[0], 0 + self.pos[1])

        if self.image is not None:
            self.shapeImage.pos = (self.pos[0] + self.shapeImagePos[0], self.pos[1] + self.shapeImagePos[1])

        for key, t in self.termDict.items():
            t.update()

        for key, p in self.paramDict.items():
            p.update()

    def swapHorizontal(self):
        '''!
        Preklopenie analogoveho komponentu horizontálne.

        Pri preklopení sa vymenia polohy a smery terminálov. Prekresli sa obrys a posunie sa ikona.
        '''
        if self.swapHoriz is False:
            self.swapHoriz = True                       # prehodenie terminalov, vymena bola vykonana

            for (num, t) in self.termDict.items():
                t.pos = (-t.pos[0], t.pos[1])
                t.namePos = (-t.namePos[0], t.namePos[1])
                t.numPos = (-t.numPos[0], t.numPos[1])

            for j in range(0, len(self.vertex), 2):          # obrys a shape komponentu
                self.vertex[j] = -self.vertex[j]

            self.lineVert[0] = -self.lineVert[0]              # vertikalna ciara
            self.lineVert[2] = -self.lineVert[2]

            self.shapeImagePos[0] = dp(7)

        else:
            self.swapHoriz = False                            # vratenie nazad, vymena bola vykonana

            for (num, t) in self.termDict.items():
                t.pos = (-t.pos[0], t.pos[1])
                t.namePos = (-t.namePos[0], t.namePos[1])
                t.numPos = (-t.numPos[0], t.numPos[1])

            for j in range(0, len(self.vertex), 2):           # obrys a shape komponentu
                self.vertex[j] = -self.vertex[j]

            self.lineVert[0] = -self.lineVert[0]              # vertikalna ciara
            self.lineVert[2] = -self.lineVert[2]

            self.shapeImagePos[0] = dp(-22)
