# -*- coding: utf-8 -*-
import math
from collections import OrderedDict

from kivy.uix.widget import Widget
from kivy.graphics import Line, Rectangle, SmoothLine
from kivy.uix.label import Label
from kivy.metrics import dp

from src.common import *
from src.component import Parameter


class VertexLabel(Widget):
    '''!
    Zobrazenie mena net-u relativne viazane na polohu vertexu.
    '''
    def __init__(self, vertex):
        super(VertexLabel, self).__init__()
        self.pos = (10, 10)            # pociatocna poloha voci vertexu
        self.vertex = vertex

        self.color = color.yellow
        self.selColor = color.red

        self.textSize = (0, 0)
        self.isSelected = False
        self.isVisible = False

        self.label = Label(text=self.vertex.net.paramDict['Name'].value, markup=True, italic=True, size=(0, 0))

    def build(self):
        self.canvas.clear()
        self.clear_widgets()

        if self.isVisible is True:
            self.label.text = self.vertex.net.paramDict['Name'].value

            if self.isSelected is False:
                self.label.color = self.color
            else:
                self.label.color = self.selColor

            self.add_widget(self.label)
            self.label.texture_update()                    # velkost textu (box)
            self.textSize = self.label.texture_size

    def update(self):
        if self.isVisible is True:
            self.label.pos = (self.pos[0] + self.vertex.pos[0], self.pos[1] + self.vertex.pos[1])

    def rebuild(self):
        self.build()
        self.update()


class Vertex(Widget):
    '''!
    Uzol net-u.

    Uzol ma vlastne kontexove menu.
    '''

    def __init__(self, net, pos):
        super(Vertex, self).__init__()

        self.net = net        # siet, ku ktorej patri vertex
        self.pos = pos        # poloha vertexu

        self.isSelected = False
        self.isVisible = False
        self.hasMenu = False              # flag viditelnosti menu

        # @todo - doplnenie vyberu typu zobrazenia vertexu
        # self.vertexShape = vertexShape.Square
        self.border = (dp(-4), dp(-4), dp(8), dp(8))
        self.shapeColor = color.yellow
        self.borderColor = color.red

        self.rectangle = Rectangle()
        self.line = Line()
        self.label = VertexLabel(self)
        self.menu = self.OnScreenMenu(self)

    class OnScreenMenu():
        '''!
        Graficke menu pre vertex, vnutorna trieda
        '''
        def __init__(self, vert):

            self.vert = vert

            self.itemSize = (dp(30), dp(30))
            self.itemConv = Rectangle(size=self.itemSize, source='./icons/conv_junct.png')
            self.itemDelete = Rectangle(size=self.itemSize, source='./icons/trash.png')
            self.itemLabel = Rectangle(size=self.itemSize, source='./icons/label.png')
            self.itemAngle = Rectangle(size=self.itemSize, source='./icons/angle.png')

            # polozky on-screen menu - orientacia okolo komponentu
            #     6  7  0
            #     5  8  1
            #     4  3  2
            # pole poloziek - ikony, nepouzite pozicie maju hodnotu None
            # default hodnoty, v dedenej triede je mozne zoznam modifikovat
            self.menuItems = [self.itemConv,         # 0
                              None,                  # 1
                              self.itemDelete,       # 2
                              None,                  # 3
                              self.itemAngle,        # 4
                              None,                  # 5
                              self.itemLabel,        # 6
                              None,                  # 7
                              None]                  # 8  stred

            # pole navratovych hodnot zodpovedajucich polozkam menu
            self.itemValue = [mode.VTX_2_JNC,        # 0
                              0,                     # 1
                              mode.DEL_VERTEX,       # 2
                              0,                     # 3
                              mode.ANGLE_VERTEX,     # 4
                              0,                     # 5
                              mode.SHOW_LABEL,       # 6
                              0,                     # 7
                              0]                     # 8

        def build(self):
            # pole offsetov poloziek menu voci (pos[0]+border[0], pos[1]+border[1]) - lavy dolny roh
            # default hodnoty, pole sa aktualizuje podla skutocnych rozmerov komponentu v metode self.create
            self.itemsPos = [(self.vert.border[2], self.vert.border[3]),     # 0
                            (0, 0),                                          # 1
                            (self.vert.border[2], -self.itemSize[1]),        # 2
                            (0, 0),                                          # 3
                            (- self.itemSize[0], - self.itemSize[1]),        # 4
                            (0, 0),                                          # 5
                            (- self.itemSize[0], self.vert.border[3]),       # 6
                            (0, 0),                                          # 7
                            (0, 0)]

            for i in range(9):                         # prepocet polohy poloziek menu
                m = self.menuItems[i]
                (px, py) = self.itemsPos[i]
                if m is not None:
                    m.pos = (self.vert.pos[0] + self.vert.border[0] + px, self.vert.pos[1] + self.vert.border[1] + py)

        def update(self):
            self.vert.canvas.add(RGBA_Color(color.white))    # pozadie pre ikony menu
            for i in range(9):                          # zaradenie ikon menu
                m = self.menuItems[i]
                if m is not None:
                    self.vert.canvas.add(m)

        def rebuild(self):
            self.build()
            self.update()

        def value(self, pos):
            '''!
            Vráti hodnotu zodpovedjúcu kliknutiu na ikonu menu.

            Vrati hodnotu modu zodpovedajuci kliknutiu na ikonu menu,
            None v pripade kliknutia mimo. Hodnoty su preddefinovane
            v poli self.itemValue.
            '''
            for i in range(9):
                if self.menuItems is not None:
                    (px, py) = self.itemsPos[i]
                    x = self.vert.pos[0] + self.vert.border[0] + px
                    y = self.vert.pos[1] + self.vert.border[1] + py

                    if x <= pos[0] <= x + self.itemSize[0]:
                        if y <= pos[1] <= y + self.itemSize[1]:
                            return self.itemValue[i]
            return None

    def build(self):
        '''!
        '''
        self.canvas.clear()
        self.clear_widgets()

        if self.isSelected is True:

            self.canvas.add(RGBA_Color(self.shapeColor))
            self.canvas.add(self.rectangle)
            self.canvas.add(RGBA_Color(self.borderColor))
            self.canvas.add(self.line)

            if self.hasMenu is True:              # aktivne menu vertex-u
                self.menu.build()

        self.label.build()
        self.add_widget(self.label)

    def update(self):
        '''!
        '''
        if self.isSelected is True:
            self.rectangle.pos = (self.pos[0] + self.border[0],
                                  self.pos[1] + self.border[1])
            self.rectangle.size = (self.border[2], self.border[3])

            self.line.rectangle = (self.pos[0] + self.border[0],
                                  self.pos[1] + self.border[1],
                                   self.border[2], self.border[3])

            if self.hasMenu is True:           # poloha ikon menu je odvodena od obrysu komponentu
                self.menu.update()

        self.label.update()

    def rebuild(self):
        self.build()
        self.update()

    def setAngle(self):
        '''!
        Nastavenie zarovnania alebo pravého uhla net-u v polohe vertexu.

        Zmeni polohu vertexu tak, aby net tvoril v bode vertexu pravy uhol.
        Urcene pre pracu na tablete, kde je problem so zadanim exaktnej polohy.
        V prípade zhodnej polohy x alebo y-nových súradnic vertexov (i-1), (i+1)
        zarovná vertex (i) na priamku.
        '''
        i = self.net.vertexList.index(self)
        (x0, y0) = self.pos
        (x1, y1) = self.net.vertexList[i - 1].pos
        (x2, y2) = self.net.vertexList[i + 1].pos

        # vypocet vzdialenosti od spojnice bodov (i-1) a (i+1)
        # vysledok +/- urcuje konkavnu alebo konvexnu konfiguraciu
        p = ((y2 - y1) * x0 - (x2 - x1) * y0 + x2 * y1 - y2 * x1)  \
           / math.sqrt((y2 - y1) * (y2 - y1) + (x2 - x1) * (x2 - x1))

        if y1 == y2:                # horizontalne zarovnanie 1---x---2
            self.pos[0] = (x1 + x2) / 2.0
            self.pos[1] = y1

        elif x1 == x2:              # vertikalne zarovnanie
            self.pos[0] = x1
            self.pos[1] = (y1 + y2) / 2.0

        elif (x1 < x2) and (y1 < y2):
            if p >= 0:               # r       2
                self.pos[0] = x2     # r       |
                self.pos[1] = y1     # r  1 ---x
            else:
                self.pos[0] = x1
                self.pos[1] = y2

        elif (x1 > x2) and (y1 < y2):
            if p >= 0:               # r  2---x
                self.pos[0] = x1     # r      |
                self.pos[1] = y2     # r      1
            else:
                self.pos[0] = x2
                self.pos[1] = y1

        elif (x1 > x2) and (y1 > y2):
            if p >= 0:               # r  x--1
                self.pos[0] = x2     # r  |
                self.pos[1] = y1     # r  2
            else:
                self.pos[0] = x1
                self.pos[1] = y2

        elif (x1 < x2) and (y1 > y2):
            if p >= 0:               # r  1
                self.pos[0] = x1     # r  |
                self.pos[1] = y2     # r  x--2
            else:
                self.pos[0] = x2
                self.pos[1] = y1

        self.net.update()


class VirtualNet():
    '''!
    Virtuálne nezobrazované prepojenie medzi dvoma komponentami.

    Prepojenie point-to-point medzi startovacim a koncovym terminalom. Virtualny spoj neobsahuje nijake vertexy.
    '''
    def __init__(self):
        self.nid = 0
        self.type = netType.VIRTUAL                # typ net-u
        self.startTerm = None
        self.endTerm = None
        self.isBus = False                         # doplneny atribut pre zobrazenie typu prepojenych sieti

    def update(self):
        pass

    def build(self):
        pass

    def rebuild(self):
        pass


class Net(Widget):
    '''
    Zakladna trieda pre prepojenie medzi komponentami.

    @todo Lock/Unlock net, povolenie/zakazanie editovania siete
    @todo Visible/hidden, viditelna/neviditelna siet
    @todo Konverzia na spline - zaoblene rohy
    '''

    def __init__(self):
        super(Net, self).__init__()

        self.nid = 0
        self.diagram = None                        # diagram, ku ktoremu patri net
        self.type = netType.STANDARD               # typ net-u

        self.lineWidth = dp(1)
        self.busWidth = dp(2)
        self.bezier = False

        self.color = color.green
        self.colorBus = color.flatGreen3
        self.colorError = color.flatRed1

        self.isSelected = False
        self.isLocked = False        # uzamknuta siet - bez moznosti posuvania (s výnimkou prveho a pos. vertexu)
        self.isVisible = False       # viditelna / neviditelna siet
        self.isBus = False           # prenasana informacia je vektor
        self.errorState = False      # prenasana informacia je chybna (zla sirka vektora a pod.)
        self.hasMenu = False         # flag viditelnosti menu

        self.paramDict = OrderedDict()
        Parameter(self, 'Name', 'Net name', 'Nx')
        Parameter(self, 'Width', 'Net width', self.lineWidth)
        Parameter(self, 'Color', 'Net color', ['Green', 'Red', 'Yellow', 'Blue', 'White'])
        Parameter(self, 'Dash length', 'Length of a segment', 1)
        Parameter(self, 'Dash offset', 'Offset between the end of a segment and the beginning of the next one', 0)
        Parameter(self, 'Bezier', 'Line as bezier spline', False)

        self.menu = self.OnScreenMenu(self)
        #self.line = SmoothLine()                              # Line -> SmoothLine
        self.line = Line()

        self.startTerm = None                           # referencie na zaciatocny a koncovy terminal
        self.endTerm = None                             # terminaly su definovane v triede Component
        self.vertexList = [Vertex(self, (0, 0))]        # musi byt na konci, potrebuje definovany paramList

    class OnScreenMenu():
        '''!
        Graficke menu pre vertex, vnutorna trieda
        '''
        def __init__(self, net):
            self.net = net

            self.pos = (0, 0)                                 # pozicia menu, parametrizuje sa v build()
            self.border = (dp(-12), dp(-12), dp(24), dp(24))  # obrys editovaneho virtualneho bodu na net-e

            self.itemSize = (dp(30), dp(30))
            self.itemSettings = Rectangle(size=self.itemSize, source='./icons/settings.png')
            self.itemDelete = Rectangle(size=self.itemSize, source='./icons/trash.png')
            self.itemCross = Rectangle(size=self.itemSize, source='./icons/cross_yell.png')
            self.itemJunct = Rectangle(size=self.itemSize, source='./icons/conv_junct.png')
            self.itemVertx = Rectangle(size=self.itemSize, source='./icons/conv_vertx.png')

            # polozky on-screen menu - orientacia okolo virtualneho bodu
            #     6  7  0
            #     5  8  1
            #     4  3  2
            # pole poloziek - ikony, nepouzite pozicie maju hodnotu None
            # default hodnoty, v dedenej triede je mozne zoznam modifikovat
            self.menuItems = [self.itemJunct,        # 0
                              None,                  # 1
                              self.itemDelete,       # 2
                              None,                  # 3
                              self.itemVertx,        # 4
                              None,                  # 5
                              self.itemSettings,     # 6
                              None,                  # 7
                              self.itemCross]        # 8  stred

            # pole navratovych hodnot zodpovedajucich polozkam menu
            self.itemValue = [mode.ADD_CONN,         # 0
                              0,                     # 1
                              mode.DEL_NET,          # 2
                              0,                     # 3
                              mode.INS_VERTEX,       # 4
                              0,                     # 5
                              mode.SETUP_NET,        # 6
                              0,                     # 7
                              0]                     # 8

        def build(self):
            # pole offsetov poloziek menu voci (pos[0]+border[0], pos[1]+border[1]) - lavy dolny roh
            # default hodnoty, pole sa aktualizuje podla skutocnych rozmerov komponentu v metode self.create
            self.itemsPos = [(self.border[2], self.border[3]),               # 0
                            (0, 0),                                          # 1
                            (self.border[2], -self.itemSize[1]),             # 2
                            (0, 0),                                          # 3
                            (- self.itemSize[0], - self.itemSize[1]),        # 4
                            (0, 0),                                          # 5
                            (- self.itemSize[0], self.border[3]),            # 6
                            (0, 0),                                          # 7
                            (0, 0)]

            self.net.canvas.add(RGBA_Color(color.white))    # podkladova farba
            for i in range(9):                              # zaradenie poloziek do zoznamu
                m = self.menuItems[i]
                if m is not None:
                    self.net.canvas.add(m)

        def update(self):
            for i in range(9):                               # prepocet polohy poloziek menu
                m = self.menuItems[i]
                (px, py) = self.itemsPos[i]
                if m is not None:
                    m.pos = (self.pos[0] + self.border[0] + px, self.pos[1] + self.border[1] + py)

        def rebuild(self):
            self.build()
            self.update()

        def value(self, pos):
            '''!
            Vráti hodnotu zodpovedjúcu kliknutiu na ikonu menu.

            Vrati hodnotu modu zodpovedajuci kliknutiu na ikonu menu,
            None v pripade kliknutia mimo. Hodnoty su preddefinovane
            v poli self.itemValue. Kontroluju sa len tie polozky menu, v ktorych
            sa vyskytuju ikony.
            '''
            for i in range(9):
                if self.menuItems is not None:
                    (px, py) = self.itemsPos[i]
                    x = self.pos[0] + self.border[0] + px
                    y = self.pos[1] + self.border[1] + py

                    if x <= pos[0] <= x + self.itemSize[0]:
                        if y <= pos[1] <= y + self.itemSize[1]:
                            return self.itemValue[i]
            return None

    def setStartTerm(self, term):
        '''
        Priradenie pociatocneho terminalu prepojenia.
        '''
        self.startTerm = term
        self.startTerm.netDict[self.nid] = self
        self.startTerm.build()
        self.startTerm.update()

        self.vertexList[0] = Vertex(self, (self.startTerm.pos[0] + self.startTerm.comp.pos[0],
                                           self.startTerm.pos[1] + self.startTerm.comp.pos[1]))

    def setEndTerm(self, term):
        '''
        Priradenie koncoveho terminalu prepojenia.
        '''
        self.endTerm = term
        self.endTerm.netDict[self.nid] = self
        self.endTerm.build()
        self.endTerm.update()

        # @todo - kontrola na dlzku zoznamu, musi byt >=2 (poc. a koncovy vertex)
        self.vertexList[-1] = Vertex(self, (self.endTerm.pos[0] + self.endTerm.comp.pos[0],
                                            self.endTerm.pos[1] + self.endTerm.comp.pos[1]))

    def rebuild(self):
        self.build()
        self.update()

    def build(self):
        '''!
        '''
        self.canvas.clear()
        self.clear_widgets()

        self.line = Line()

        self.line.dash_length = self.paramDict['Dash length'].value
        self.line.dash_offset = self.paramDict['Dash offset'].value
        self.bezier = self.paramDict['Bezier'].value
        self.lineWidth = self.paramDict['Width'].value

        strColor = self.paramDict['Color'].value
        if strColor == 'Green':
            self.color = color.green
            self.colorBus = color.flatGreen3
        elif strColor == 'Blue':
            self.color = color.flatBlue4
            self.colorBus = color.flatBlue7
        elif strColor == 'Yellow':
            self.color = color.flatYellow1
            self.colorBus = color.flatYellow4
        elif strColor == 'White':
            self.color = color.white
            self.colorBus = color.flatGray2
        elif strColor == 'Red':
            self.color = color.red
            self.colorBus = color.red

        if self.errorState is True:             # parametre zobrazovaneho prepojenia
            self.canvas.add(RGBA_Color(self.colorError))
        else:
            if self.isBus is True:
                self.canvas.add(RGBA_Color(self.colorBus))
            else:
                self.canvas.add(RGBA_Color(self.color))
        self.canvas.add(self.line)

        if len(self.vertexList) > 2:             # min. jeden vertex medzi terminalmi
            for v in self.vertexList[1:-1]:      # prvy a posledny vertes sa nezobrazuje (=terminal)
                if self.isSelected is True:      # vertexy sa zobrazuju nad net-om
                    v.isSelected = True          # zobrazenie vertexov pri selektovanom prepojeni
                else:
                    v.isSelected = False
                v.build()                        # vertex moze obsahovat label
                self.add_widget(v)

        if self.hasMenu is True:                 # zobrazenie aktivneho menu na hrane net-u
            self.menu.build()

    def update(self):
        '''!
        Prekreslenie siete podľa jej aktuálnych vlastností.

        Zobrazenie siete podla parametra isSelected, True-selektovana, False-normal
        '''

        if self.isBus is True:                  # zmena sirky v zavislosti od typy prenasanej informacie
            self.line.width = self.busWidth     # atribut isBus nastavuje Joint a Compressor
        else:
            self.line.width = self.lineWidth
                                                # update polohy pociatocneho vertexu
        self.vertexList[0].pos = (self.startTerm.pos[0] + self.startTerm.comp.pos[0],
                                   self.startTerm.pos[1] + self.startTerm.comp.pos[1])

        if self.endTerm is not None:            # vypocet polohy koncoveho vertexu, ak je pripojeny k terminalu
            self.vertexList[-1].pos = (self.endTerm.pos[0] + self.endTerm.comp.pos[0],
                                        self.endTerm.pos[1] + self.endTerm.comp.pos[1])

        points = []
        for v in self.vertexList:                # vytvorenie zoznamu pozicii, prekreslenie vsetkych vertexov
            points = points + list(v.pos)
        if self.bezier is False:
            self.line.points = points
        else:
            self.line.bezier = points

        if len(self.vertexList) > 2:
            for v in self.vertexList[1:-1]:     # pociatocny a koncovy vertex sa nezobrazuje, patria terminalom
                v.update()                      # prekreslenie poloh vertexov

        if self.hasMenu is True:
            self.menu.update()

    def addVertex(self, pos):
        '''!
        Pridanie nového vertexu na koniec zoznamu počas vytvárania nového prepojenia.

        @param pos Poloha nového vertexu

        @todo - kontrolu presunut do editora
        @todo doplnit kontrolu na slucku - vertex != pociatocny terminal
        @todo doplnit kontrolu duplicita - rovnaky vertex na zhodnej suradnici (resp.v blizkom okoli)
        '''
        # uprava suradnic pre umiestnenie na mriezke - ak je aktivovany snapOnGrid
        if self.diagram.snapOnGrid is True:
            gr = self.diagram.grid
            pos = (gr * ((pos[0] + gr / 2) // gr), gr * ((pos[1] + gr / 2) // gr))

        #sv = self.vertexList[0]                              # startovaci vertex
        #if  sv.pos[0] != pos[0] or sv.pos[1] != pos[1]:     # kontrola na zhodu pridavaneho vertexu so startovacim
        self.vertexList.append(Vertex(self, (pos[0], pos[1])))

    def insVertex(self, vertex, pos):
        '''!
        Vlozenie noveho vertexu za vybrany vertex na zvolenu poziciu.
        '''
        idx = self.vertexList.index(vertex)
        self.vertexList.insert(idx, Vertex(self, (pos[0], pos[1])))
        self.isSelected = True                    # oznacenie vsetkych vertexov vratane noveho
        self.rebuild()
        return vertex

    def delVertex(self, vertex):
        '''!
        Zmazanie vertexu.

        @param vertex Vertex, ktorý bude zmazaný. Spolu s vertexom sa odstáni aj jeho label.
        '''
        vertex.label.isVisible = False            # zmazanie labelu vertexu (ak bol zobrazeny)
        vertex.build()                            # refresh vertexu
        vertex.clear_widgets()                    # vyradenia vertexu a labelu z graf. systemu

        index = self.vertexList.index(vertex)     # odstranenie vertexu
        del self.vertexList[index]                # zo zoznamu vertexov komponentu
        self.isSelected = False
        self.rebuild()
