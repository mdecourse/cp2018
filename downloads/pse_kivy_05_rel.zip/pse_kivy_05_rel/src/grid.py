# -*- coding: utf-8 -*-
from kivy.uix.widget import Widget
from kivy.graphics import Point, Line

from src.common import *
from cfg.config_pse import *


class Grid(Widget):
    '''
    Mriezka diagramu
    '''
    def __init__(self, **kwargs):
        super(Grid, self).__init__(**kwargs)

        self.gridIsVisible = True
        self.borderIsVisible = True
        self.build()

    def build(self):
        '''
        '''
        self.canvas.clear()

        if self.gridIsVisible is True:
            if conf.gridType == gridParam.Dots:
                # Dots
                points = Point()
                points.pointsize = conf.gridSize

                # rozlozenie gridu, na poziciu (0 .. x, 0 ... y) sa bodky nepridavaju
                for x in range(conf.gridSpacingX, conf.diagramWidth, conf.gridSpacingX):
                    for y in range(conf.gridSpacingY, conf.diagramHeight, conf.gridSpacingY):
                        points.add_point(x, y)

                # farba a priehladnost bodov gridu
                gridColor = conf.gridColor[:]            # kopia farby
                gridColor[3] = conf.gridTransparency     # priehladnost
                self.canvas.add(RGBA_Color(gridColor))
                self.canvas.add(points)
            elif conf.gridType == gridParam.Lines:
                # Lines
                # @ToDo - doplnit implementaciu
                pass

        if self.borderIsVisible is True:
            self.borderLine = Line(points=(0, 0,
                                           0, conf.diagramHeight,
                                           conf.diagramWidth, conf.diagramHeight,
                                           conf.diagramWidth, 0,
                                           0, 0))
            self.canvas.add(RGBA_Color(conf.borderColor))
            self.canvas.add(self.borderLine)