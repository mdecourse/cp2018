# -*- coding: utf-8 -*-
'''!
Spoločné konštanty, globálne funkcie a preddefinované premenné.
'''

from kivy.graphics import Color

#-------------------------------------
# Vlastnosti mriezky editora
#-------------------------------------


class GridParam():
    NoGrid = 0
    Lines = 1
    Dots = 2

gridParam = GridParam()

#-------------------------------------
# Vlastnosti editora
#-------------------------------------


class DiagramMode():
    '''!
    Definícia módov editora diagramu.
    '''
    NONE = 0               # zrusenie vsetkych aktivit editora

                           # Move ...
    MOVE = 10              # vseobecna volba presunu (z button menu) entity - upresnuje sa vyberom
    MOVE_COMP = 11         # posun komponentu
    MOVE_LABEL = 12        # posun oznacenia siete (viazane na polohu vertexu)
    MOVE_PARAM = 13        # posun parametra komponentu
    MOVE_VERTEX = 14       # posun vertexu net-u

                           # Add.. / Del.. / Ins..
    ADD_COMP = 21          # pridanie komponentu
    ADD_CONN = 40          # pridanie bodu prepojenia medzi sietami
    ADD_NET = 50           # vytvorenie novej siete
    ADD_VERTEX = 51        # pridanie noveho vertexu siete - na koniec zoznamu, pocas vytvarania
    INS_VERTEX = 53        # vlozenie vertexu do existujucej siete

    DEL_COMP = 22          # zmazanie komponentu
    DEL_JUNCT = 41         # zmazanie bodu prepojenia
    DEL_VERTEX = 52        # zmazanie vertexu
    DEL_NET = 55           # zmazanie siete

    SWP_HORZ = 23          # preklopenie komponentu horizontalne
    SWP_VERT = 24          # preklopenie komponentu vertikalne

    COPY = 30
    COPY_COMP = 31         # kopia komponentu (vratane aktualnych hodnot atributov)

    VTX_2_JNC = 56         # konverzia vertexu na prepojenie (Joint)
    JNC_2_VTX = 57         # konverzia prepojenia na vertex

    SHOW_LABEL = 60        # zobrazenie labelu vertexu
    ANGLE_VERTEX = 61      # zarovnanie vertexu do praveho uhla

    SETUP = 100            # vseobecna volba nastavenia (z button menu) entity
    SETUP_COMP = 101       # nastavenie parametrov komponentu (setup menu)
    SETUP_NET = 102        # nastavenie parametrov siete

    SIMUL = 200            # mod simulacie, zamkne editovanie diagramu

mode = DiagramMode()


class CompType():
    '''!
    Typ komponentu.
    '''
    NONE = 0
                           # prepojovacie komponenty
    CONN = 1               # komponent prepojenia medzi sietami (bod)
    CONN_VIRTUAL = 2       # neviditelny komponent prepojenia medzi sietami

    PORT = 4               # komponent prepojenia medzi sietami
    PORT_CONN = 8          # interny komponent prepojenia v ramci bloku, zmena typu pri parsovani bloku

                           # standardne komponenty
    CONTINUOUS = 32        # linearne komponenty
    DISCRETE = 64          # diskretne nespojite komponenty
    CLOCK = 128            # casovace a hodiny
    CONTROL = 256          # algoritmy riadenia
    INTEGRAL = 521         # komponenty s charakteristikou popisanou diff rovnicou
    BLOCK = 1024           # blok, odkazuje sa na diagram v samostatnom subore

    SOURCE = 2048          # zdroje hodnôt (generátor, čítanie zo súborov a sietí ...)
    SOURCE_VISUAL = 4096   # GUI komponenty generujuce data (Slider ..)

    SINKS = 8192
    SINKS_VISUAL = 16384     # GUI komponent spracujuce data (Display, grafy ... )

    BUS = 32768              # pomocny prefix pre komponenty pracujuce so zberniciu (Compressor, Expander)
                           # maju typ v kombinacii (CONTINUOUS | BUS)

                           # doplnkove komponenty
    DECORATION = 1000      # pasivny komponent (popis, obrazky ...)

compType = CompType()


class SystemState():
    INIT = 1                # inicializacia komponentu (otvorenie kom. portov, suborov, vytvorenie poli ..)
    STEP = 2                # priebezny vypocet pocas kroku simulacie
    STOP = 4                # ukoncenie simulacie (zatvorenie suborov, portov ...)

    UPDATE = 8              # nastavenie hodnoty komponentu na konci simulacneho kroku
    REFRESH = 16            # prekreslenie grafickych komponentov v RT simulacii (nemusi byt v kazdom kroku, obsahuje
                            # synchronizaciu na graficky subsystem)

sysState = SystemState()


class CompState():
    UNTOUCH = 1             # vizualny komponent nezmeneny (slider, tlacitko ..)
    CHANGED = 2             # komponent zmeni stav / hodnotu

compState = CompState()


class ParamType():
    '''!
    Typ parametra.

    Používa sa pri výbere lokalneho editora pre úpravu hodnoty parametra v triede CompSettings
    a konverziu hodnot z textoveho retazca po editacii.
    '''
    NONE = 0
    BOOL = 1
    INT = 2
    FLOAT = 4
    INT_MIN_MAX = 8           # int s hranicnymi hodnotami
    FLOAT_MIN_MAX = 16        # float s hranicnymi hodnotami
    STRING = 32
    LIST = 64
    COMPLEX = 128

parType = ParamType()

#-------------------------------------
# Vlastnosti siete
#-------------------------------------


class NetType():            # zobrazenie prepojenia
    STANDARD = 1            # standardne viditelne prepojenie
    VIRTUAL = 2             # neviditelne prepojenie po optimalizacii

netType = NetType()


class VertexShape():
    NoShape = 0
    Circle = 1
    Square = 2
    Triangle = 4
    Cross = 8

vertexShape = VertexShape()

#-------------------------------------
# Vlastnosti terminalu
#-------------------------------------


class TerminalType():       # typ terminalu
    CONN = 1                # prepojovaci terminal pre komponent Connection a Port
    INPUT = 2               # je mozna kombinacia (CONN or INPUT resp. OUTPUT) pre terminal bloku
    OUTPUT = 4              # ktory ma byt zobrazeny TermTriangle

termType = TerminalType()


class TerminalShape():      # tvar terminalu
    NoShape = 0             # nezobrazovany terminal
    Circle = 1
    Square = 2
    Triangle = 3
    Cross = 4
    Joint = 5               # ako circle, bez posuvania vzhladom k Input/output @todo - upravit na InOut
    JointTriangle = 6       # meni tvar podla polohy (North, West ...)

termShape = TerminalShape()


class TerminalDirection():  # orientacia terminalu vzhladom ku komponentu
    NONE = 0                # pre typy terminalov, kde nie je orientacia dolezita (o, x ...)
    NORTH = 1
    WEST = 2
    SOUTH = 3
    EAST = 4

termDir = TerminalDirection()


class SimType():
    '''!
    Typy simulatorov a generatorov
    '''
    SOLVER_RK2 = 1          # jednokrokovy solver Runge Kutt 2
    SOLVER_RK23 = 2         # jednokrokovy solever RungeKutt 23
    SOLVER_RT2 = 3          # solver RK2 synchronizovany na realny cas
    GEN_SPICE = 10
    GEN_MODELICA = 11

simType = SimType()


class ErrorCode():
    '''!
    '''
    ERR_NONE = 0

    ERR_VECTOR_REQ = 100    # komponent pozaduje ako vstupnu hodnotu vektor
    ERR_SCALAR_REQ = 101    # komponent pozaduje ako vstupnu hodnotu skalar
    ERR_VECTOR_SIZE = 102   # nespravna sirka vektora na vstupe komponentu
    ERR_VECTOR_TYPE = 103   # nespravny format vektoru

    ERR_NUM_DIV_ZERO = 200  # delenie nulou

errorCode = ErrorCode()


def convertColor(value):
    '''
    Converts value between 0 and 1 to cold-hot color scale
    '''
    if (0 <= value and value <= 1 / 8):
        R = 0
        G = 0
        B = 4 * value + .5    # .5 - 1 // b = 1/2

    elif (1 / 8 < value and value <= 3 / 8):
        R = 0
        G = 4 * value - .5     # 0 - 1 // b = - 1/2
        B = 1                  # small fix

    elif (3 / 8 < value and value <= 5 / 8):
        R = 4 * value - 1.5    # 0 - 1 // b = - 3/2
        G = 1
        B = -4 * value + 2.5   # 1 - 0 // b = 5/2

    elif (5 / 8 < value and value <= 7 / 8):
        R = 1
        G = -4 * value + 3.5    # 1 - 0 // b = 7/2
        B = 0

    elif (7 / 8 < value and value <= 1):
        R = -4 * value + 4.5   # 1 - .5 // b = 9/2
        G = 0
        B = 0

    else:                    # should never happen - value > 1
        R = .5
        G = 0
        B = 0

    return int(R * 255), int(G * 255), int(B * 255)


class ColorCode():
    darkBlue = [11. / 255., 12. / 255., 52. / 255., 1.]
    aquamarine = [112. / 255., 219. / 255., 147. / 255, 1.]
    black = [0. / 255., 0. / 255., 0. / 255, 1.]
    blue = [0. / 255., 0. / 255., 255. / 255, 1.]
    blueViolet = [159. / 255., 95. / 255., 159. / 255, 1.]
    brown = [165. / 255., 42. / 255., 42. / 255, 1.]
    cadetBlue = [95. / 255., 159. / 255., 159. / 255, 1.]
    coral = [255. / 255., 127. / 255., 0. / 255, 1.]
    cornflowerBlue = [66. / 255., 66. / 255., 111. / 255, 1.]
    cyan = [0. / 255., 255. / 255., 255. / 255, 1.]
    darkGrey = [47. / 255., 47. / 255., 47. / 255, 1.]
    darkGreen = [47. / 255., 79. / 255., 47. / 255, 1.]
    darkOliveGreen = [79. / 255., 79. / 255., 47. / 255, 1.]
    darkOrchid = [153. / 255., 50. / 255., 204. / 255, 1.]
    darkSlateBlue = [107. / 255., 35. / 255., 142. / 255, 1.]
    darkSlateGrey = [47. / 255., 79. / 255., 79. / 255, 1.]
    darkTurquoise = [112. / 255., 147. / 255., 219. / 255, 1.]
    dimGrey = [84. / 255., 84. / 255., 84. / 255, 1.]
    firebrick = [142. / 255., 35. / 255., 35. / 255, 1.]
    forestGreen = [35. / 255., 142. / 255., 35. / 255, 1.]
    gold = [204. / 255., 127. / 255., 50. / 255, 1.]
    goldenrod = [219. / 255., 219. / 255., 112. / 255, 1.]
    grey = [128. / 255., 128. / 255., 128. / 255, 1.]
    green = [0. / 255., 255. / 255., 0. / 255, 1.]
    greenYellow = [147. / 255., 219. / 255., 112. / 255, 1.]
    indianRed = [79. / 255., 47. / 255., 47. / 255, 1.]
    khaki = [159. / 255., 159. / 255., 95. / 255, 1.]
    lightBlue = [191. / 255., 216. / 255., 216. / 255, 1.]
    lightGrey = [192. / 255., 192. / 255., 192. / 255, 1.]
    lightSteelBlue = [143. / 255., 143. / 255., 188. / 255, 1.]
    limeGreen = [50. / 255., 204. / 255., 50. / 255, 1.]
    lightMagenta = [255. / 255., 0. / 255., 255. / 255, 1.]
    magenta = [255. / 255., 0. / 255., 255. / 255, 1.]
    maroon = [142. / 255., 35. / 255., 107. / 255, 1.]
    mediumAquamarine = [50. / 255., 204. / 255., 153. / 255, 1.]
    mediumGrey = [100. / 255., 100. / 255., 100. / 255, 1.]
    mediumBlue = [50. / 255., 50. / 255., 204. / 255, 1.]
    mediumForestGreen = [107. / 255., 142. / 255., 35. / 255, 1.]
    mediumGoldenrod = [234. / 255., 234. / 255., 173. / 255, 1.]
    mediumOrchid = [147. / 255., 112. / 255., 219. / 255, 1.]
    mediumSeaGreen = [66. / 255., 111. / 255., 66. / 255, 1.]
    mediumSlateBlue = [127. / 255., 0. / 255., 255. / 255, 1.]
    mediumSpringGreen = [127. / 255., 255. / 255., 0. / 255, 1.]
    mediumTurquoise = [112. / 255., 219. / 255., 219. / 255, 1.]
    mediumVioletRed = [219. / 255., 112. / 255., 147. / 255, 1.]
    midnightBlue = [47. / 255., 47. / 255., 79. / 255, 1.]
    navy = [35. / 255., 35. / 255., 142. / 255, 1.]
    orange = [204. / 255., 50. / 255., 50. / 255, 1.]
    orangeRed = [255. / 255., 0. / 255., 127. / 255, 1.]
    orchid = [219. / 255., 112. / 255., 219. / 255, 1.]
    paleGreen = [143. / 255., 188. / 255., 143. / 255, 1.]
    pink = [188. / 255., 143. / 255., 234. / 255, 1.]
    plum = [234. / 255., 173. / 255., 234. / 255, 1.]
    purple = [176. / 255., 0. / 255., 255. / 255, 1.]
    red = [255. / 255., 0. / 255., 0. / 255, 1.]
    salmon = [111. / 255., 66. / 255., 66. / 255, 1.]
    seaGreen = [35. / 255., 142. / 255., 107. / 255, 1.]
    sienna = [142. / 255., 107. / 255., 35. / 255, 1.]
    skyBlue = [50. / 255., 153. / 255., 204. / 255, 1.]
    slateBlue = [0. / 255., 127. / 255., 255. / 255, 1.]
    springGreen = [0. / 255., 255. / 255., 127. / 255, 1.]
    steelBlue = [35. / 255., 107. / 255., 142. / 255, 1.]
    tan = [219. / 255., 147. / 255., 112. / 255, 1.]
    thistle = [216. / 255., 191. / 255., 216. / 255, 1.]
    turquoise = [173. / 255., 234. / 255., 234. / 255, 1.]
    violet = [79. / 255., 47. / 255., 79. / 255, 1.]
    violetRed = [204. / 255., 50. / 255., 153. / 255, 1.]
    wheat = [216. / 255., 216. / 255., 191. / 255, 1.]
    white = [255. / 255., 255. / 255., 255. / 255, 1.]
    yellow = [255. / 255., 255. / 255., 0. / 255, 1.]
    yellowGreen = [153. / 255., 204. / 255., 50. / 255, 1.0]
    mediumGoldenrod = [234. / 255., 234. / 255., 173. / 255, 1.]
    mediumForestGreen = [107. / 255., 142. / 255., 35. / 255, 1.]
    lightMagenta = [255. / 255., 0. / 255., 255. / 255, 1.]
    mediumGrey = [100. / 255., 100. / 255., 100. / 255, 1.]

    flatBlue1 = [179. / 255., 221. / 255., 245. / 255, 1.]
    flatBlue2 = [154. / 255., 221. / 255., 227. / 255, 1.]
    flatBlue3 = [140. / 255., 288. / 255., 214. / 255, 1.]
    flatBlue4 = [144. / 255., 202. / 255., 249. / 255, 1.]
    flatBlue5 = [66. / 255., 165. / 255., 245. / 255, 1.]
    flatBlue6 = [2. / 255., 119. / 255., 189. / 255, 1.]
    flatBlue7 = [63. / 255., 81. / 255., 181. / 255, 1.]
    flatBlue8 = [40. / 255., 53. / 255., 147. / 255, 1.]

    flatGray1 = [209. / 255., 196. / 255., 233. / 255, 1.]
    flatGray2 = [144. / 255., 164. / 255., 274. / 255, 1.]
    flatGray3 = [96. / 255., 125. / 255., 139. / 255, 1.]
    flatGray4 = [69. / 255., 90. / 255., 100. / 255, 1.]
    flatGray5 = [55. / 255., 71. / 255., 79. / 255, 1.]

    flatYellow1 = [255. / 255., 202. / 255., 40. / 255, 1.]
    flatYellow2 = [255. / 255., 193. / 255., 7. / 255, 1.]
    flatYellow3 = [255. / 255., 160. / 255., 40. / 255, 1.]
    flatYellow4 = [255. / 255., 152. / 255., 0. / 255, 1.]

    flatOrange1 = [255. / 255., 249. / 255., 196. / 255., 1.]
    flatOrange2 = [254. / 255., 124. / 255., 0. / 255., 1.]
    flatOrange3 = [230. / 255., 81. / 255., 0. / 255., 1.]
    flatOrange4 = [191. / 255., 54. / 255., 12. / 255., 1.]
    flatOrange5 = [148. / 255., 42. / 255., 9. / 255., 1.]

    flatBrown1 = [254. / 255., 124. / 255., 0. / 255, 1.]
    flatBrown2 = [230. / 255., 81. / 255., 0. / 255, 1.]
    flatBrown3 = [191. / 255., 54. / 255., 12. / 255, 1.]
    flatBrown4 = [148. / 255., 42. / 255., 12. / 255, 1.]

    flatGreen1 = [139. / 255., 195. / 255., 79. / 255, 1.]
    flatGreen2 = [76. / 255., 175. / 255., 80. / 255, 1.]
    flatGreen3 = [67. / 255., 160. / 255., 71. / 255, 1.]
    flatGreen4 = [0. / 255., 150. / 255., 136. / 255, 1.]

    flatRed1 = [244. / 255., 67. / 255., 54. / 255, 1.]

color = ColorCode()


def RGBA_Color(code):
    # Konverzia kodu farby na objekt.
    return Color(code[0], code[1], code[2], code[3])
