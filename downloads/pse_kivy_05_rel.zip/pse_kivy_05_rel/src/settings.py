# -*- coding: utf-8 -*-

import time

from src.common import *
from src.component import *
from src.net import *
from src.library import *

from kivy.uix.settings import *
from kivy.config import *
from kivy.uix.popup import Popup
from kivy.uix.filechooser import *
from kivy.uix.textinput import *
from kivy.logger import Logger


class CompSettings(SettingsWithSpinner):
    '''!
    Editovanie a nastavenie hodnot parametrov komponentu
    '''
    def __init__(self, comp):
        super().__init__()

        self.comp = comp
        # vytvorenie panelov
        #settings = SettingsWithSidebar()   # NoMenu()   # Spinner()
        interface = self.interface
        self.param = SettingsPanel()
        self.param.title = 'Component parameters'
        self.param.section = 'param'

        self.system = SettingsPanel()
        self.system.title = 'Component settings'
        self.system.settings = self
        self.system.section = 'system'

        self.visib = SettingsPanel()
        self.visib.title = 'Adjust the visibility of the parameter value'
        self.visib.settings = self
        self.visib.section = 'visibility'

        self.nameVis = SettingsPanel()
        self.nameVis.title = 'Adjust the visibility of the parameter name'
        self.nameVis.settings = self
        self.nameVis.section = 'nameVis'

        # event zatvorenia panelu
        self.bind(on_close=self.on_close_settings)

        # zaradenie panalov do menu
        interface.add_panel(panel=self.param, name='Parameter', uid=1)
        interface.add_panel(panel=self.visib, name='Value', uid=2)
        interface.add_panel(panel=self.nameVis, name='Name', uid=3)

        # konfiguracia hodnot parametrov - slovniky default hodnot
        cfg = ConfigParser()

        self.defaultValue = {}                    # slovnik default hodnot parametrov
        self.defaultVisib = {}                    # slovnik default viditelnosti parametrov
        self.defaultNameVis = {}

        for name, par in self.comp.paramDict.items():      # inicializacia default hodnot - z aktualnych parametrov komponentu
            self.defaultVisib[name] = par.isVisible
            self.defaultNameVis[name] = par.isNameVisible

            sign = lambda x: (1, -1)[x < 0]        # bex porovnania 0
            #sign = lambda x: x and (1, -1)[x < 0]   # vrati 0 pre x=0, len int

            if par.type == parType.FLOAT:
                v = float(par.value)                                    # @todo !!! BUG !!! - neda sa editovat hodnota mensia ako 1e-4 v exp. formate
                if (v > 0 and v < 0.0001) or (v < 0 and v > -0.0001):   # treba ju prestavit na min. hodnotu v standardnom formate
                    v = 0.0001 * sign(v)
                self.defaultValue[name] = v     # float(par.value)
            else:
                self.defaultValue[name] = par.value

        cfg.setdefaults('param', self.defaultValue)
        cfg.setdefaults('visib', self.defaultVisib)
        cfg.setdefaults('nameVis', self.defaultNameVis)

        self.param.config = cfg
        self.visib.config = cfg
        self.nameVis.config = cfg

        # parsovanie zoznamu parametrov, vytvorenie poloziek menu
        for name, par in self.comp.paramDict.items():
            # panel vyberu viditelnosti hodnot parametrov
            #-------------------------------------------
            w = SettingBoolean(panel=self.param, key=name, title=name, desc=par.description, section='visib', values=['False', 'True'])
            self.visib.add_widget(w)

            # panel vyberu viditelnosti mien parametrov
            #------------------------------------------
            z = SettingBoolean(panel=self.nameVis, key=name, title=name, desc=par.description, section='nameVis', values=['False', 'True'])
            self.nameVis.add_widget(z)

            # panel editovania hodnot parametrov
            #-------------------------------------------
            if par.type == parType.BOOL:
                q = SettingBoolean(panel=self.param, key=name, title=name, desc=par.description, section='param', values=['False', 'True'])
                self.param.add_widget(q)

            elif par.type == parType.INT or par.type == parType.FLOAT or \
               par.type == parType.INT_MIN_MAX or par.type == parType.FLOAT_MIN_MAX:
                q = SettingNumeric(panel=self.param, key=name, title=name, desc=par.description, section='param')
                self.param.add_widget(q)

            elif par.type == parType.STRING:
                q = SettingString(panel=self.param, key=name, title=name, desc=par.description, section='param')
                self.param.add_widget(q)

            elif par.type == parType.COMPLEX:
                q = SettingString(panel=self.param, key=name, title=name, desc=par.description, section='param')
                self.param.add_widget(q)

            elif par.type == parType.LIST:
                q = SettingOptions(panel=self.param, key=name, title=name, desc=par.description, section='param')
                q.options = par.listValue
                self.param.add_widget(q)

        # otvorenie dialogoveho okna
        time.sleep(0.1)
        self.popup = Popup(title=self.comp.__class__.__name__, content=self)
        self.popup.size_hint = (0.7, 0.7)
        self.popup.open()

    def on_close_settings(self, obj):
        '''!
        Zatvorenie dialogu a aktualizacia hodnot parametrov komponentov.
        '''
        try:
            for name, par in self.comp.paramDict.items():               # update viditelnost parametrov a konverzia,
                value = (self.visib.get_value('visib', name))    # nacitanie hodnot dialogu, par.name je kluc
                if value == u'False':                                  # SettingBoolean vracia textove hodnoty
                    par.isVisible = False
                else:
                    par.isVisible = True

                value = (self.nameVis.get_value('nameVis', name))    # nacitanie hodnot dialogu, par.name je kluc
                if value == u'False':                                  # SettingBoolean vracia textove hodnoty
                    par.isNameVisible = False
                else:
                    par.isNameVisible = True

                value = self.param.get_value('param', name)       # po editovani su hodnoty textove retazce

                if par.type == parType.INT or par.type == parType.INT_MIN_MAX:
                    par.value = int(value)                        # update hodnot parametrov

                elif par.type == parType.FLOAT or par.type == parType.FLOAT_MIN_MAX:
                    par.value = float(value)

                elif par.type == parType.STRING:
                    par.value = str(value)

                elif par.type == parType.LIST:
                    par.value = str(value)

                elif par.type == parType.COMPLEX:
                    par.value = complex(value)
        except:
            Logger.error('CompSettings: Typ parametra je odlisny od definicie v komp. kniznici')
            pass

        self.popup.dismiss()
        self.comp.build()
        self.comp.update()                                    # prekreslenie komponentu, uprava podla parametrov


class NetSettings(SettingsWithSpinner):
    '''!
    Vytvorenie menu pre editovanie parametrov net-u.
    '''
    def __init__(self, net):
        super(NetSettings, self).__init__()

        self.net = net
        interface = self.interface            # vytvorenie panelu
        self.param = SettingsPanel()
        self.param.title = 'Net parameters'
        self.param.section = 'param'

        # zaradenie panalu do menu
        interface.add_panel(panel=self.param, name='Parameters', uid=1)

        # konfiguracia hodnot parametrov - slovniky default hodnot
        cfg = ConfigParser()        # default hodnoty musia byt definovane pred vytvaranim poloziek
        defaultValue = {}           # slovnik default hodnot parametrov

        for name, par in self.net.paramDict.items():
            if par.type == parType.INT or par.type == parType.FLOAT or par.type == parType.STRING:
                defaultValue[name] = par.value

            elif par.type == parType.LIST:
                defaultValue[name] = par.value       # prva polozka zo zoznamu

            elif par.type == parType.BOOL:
                defaultValue[name] = par.value

        cfg.setdefaults('param', defaultValue)
        self.param.config = cfg

        # parsovanie zoznamu parametrov, vytvorenie poloziek menu
        for name, par in self.net.paramDict.items():

            if par.type == parType.INT or par.type == parType.FLOAT:
                q = SettingNumeric(panel=self.param, key=name, title=name, desc=par.description, section='param')
                self.param.add_widget(q)

            elif par.type == parType.BOOL:
                q = SettingBoolean(panel=self.param, key=name, title=name, desc=par.description, section='param', values=['False', 'True'])
                self.param.add_widget(q)

            elif par.type == parType.STRING:
                q = SettingString(panel=self.param, key=name, title=name, desc=par.description, section='param')
                self.param.add_widget(q)

            elif par.type == parType.LIST:
                q = SettingOptions(panel=self.param, key=name, title=name, desc=par.description, section='param')
                q.options = par.listValue
                self.param.add_widget(q)

        # event zatvorenia panelu
        self.bind(on_close=self.on_close_settings)

        self.popup = Popup(title='Net', content=self)
        self.popup.size_hint = (0.7, 0.7)
        self.popup.open()

    def on_close_settings(self, obj):
        '''!
        Zatvorenie dialogu.
        '''
        try:
            for key, par in self.net.paramDict.items():
                value = self.param.get_value('param', key)

                if par.type == parType.INT:
                    par.value = int(value)                        # update hodnot parametrov

                elif par.type == parType.FLOAT:
                    par.value = float(value)

                elif par.type == parType.STRING:
                    par.value = str(value)

                elif par.type == parType.LIST:
                    par.value = str(value)

                elif par.type == parType.BOOL:
                    if value == u'False':                                  # SettingBoolean vracia textove hodnoty
                        par.value = False
                    else:
                        par.value = True
        except:
            Logger.error('CompSettings: Typ parametra je odlisny od definicie v komp. kniznici')
            pass

        self.popup.dismiss()
        self.net.build()
        self.net.update()
