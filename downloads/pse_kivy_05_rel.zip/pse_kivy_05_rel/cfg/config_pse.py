# -*- coding: utf-8 -*-

from src.common import *


#-------------------------------------------------------------
# Konfiguracia prostredia PSE
#-------------------------------------------------------------
class PSEConfig():
                                                              #-----------------------------------------
                                                              # farba prac. plochy a velkosti ikon
                                                              #-----------------------------------------
    backgroundColor = color.black                             # farba pozadia pracovnej plochy
                                                              # velkosti ikon leftBar
                                                              # velkosti ikon topBar

                                                              #-----------------------------------------
                                                              # konfiguracia velkosti pracovnej plochy
                                                              #-----------------------------------------
    diagramWidth = 1400                                       # zakladna sirka
    diagramHeight = 1000                                      # zakladna vyska

                                                              #-----------------------------------------
                                                              # konfiguracia mriezky a okraja diagramu
                                                              #-----------------------------------------
    gridType = gridParam.Dots                                 # typ mriezky
    gridSpacingX = 20                                         # min 20, max. pocet bodov 2^15-2, suvisi s velkostou plochy
    gridSpacingY = 20                                         # min 20
    gridColor = color.mediumSeaGreen                          # farba mriezky
    gridTransparency = 0.5                                    # priesvitnost mriezky
    gridSize = 1                                              # velkost bodu alebo hrubka ciary
    borderColor = color.blue                                  # farba oramovania pracovnej plochy

                                                              #-----------------------------------------
                                                              # konfiguracia oblasti zachytavania
                                                              #-----------------------------------------
    distTerm = 10                                             # maximalna priama vzdialenost od terminalu
    distVertex = 10                                           # maximalna priama vzdialenost od vertexu
    distEdge = 10                                             # maximalna kolma vzdialenost od hrany net-u
                                                              # krok posunu pri snapOnGrid

                                                              #-----------------------------------------
                                                              # konfiguracia komponentov
                                                              #-----------------------------------------
    parColor = color.flatYellow1                              # farba parametrov
    parColorSel = color.flatRed1                              # farba parametra - selektovany

                                                              #-----------------------------------------
                                                              # konfiguracia prepojenia
                                                              #-----------------------------------------
                                                              # farba net-u
                                                              # farba vertexu - oramovania
                                                              # farba vertexu - vypln
                                                              # farba labelu vertexu
                                                              # farba labelu vertexu - selektovany
                                                              # farba prepojenia
                                                              # farba prepojenia selektovana

                                                              #-----------------------------------------
                                                              # konfiguracia predprocesora
                                                              #-----------------------------------------
                                                              # hlbka rekurzie pri hladani sluciek v diagrame
conf = PSEConfig()
