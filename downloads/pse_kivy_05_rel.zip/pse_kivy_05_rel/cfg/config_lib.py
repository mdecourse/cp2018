# -*- coding: utf-8 -*-
from lib.sources.generators import *                          # import kniznic komponentov
from lib.sources.consts import *
from lib.sinks.system import *
from lib.sinks.plot import *
from lib.signal.bus import *
from lib.signal.block import *
from lib.signal.port import *
from lib.math.func import *
from lib.math.linear import *
from lib.math.nonlinear import *
from lib.visual.basic import *
from lib.control.control import *
from lib.discrete.clock import *

#-------------------------------------------------------------
# Konfiguracia kniznice
#-------------------------------------------------------------
#
# tab format: (('class_name', (pos_x, pos_y), 'name'), ...)
#
# 'class_name'   - str, meno triedy komponentu
# (pos_x, pos_y) - poloha komponentu alebo jeho ikony v tab-e
# 'name'         - str, meno alebo popis komponentu, kopiruje sa do parametra 'Name'
lib_source = (
            ('GenSin', (40, 40), 'Sin'), ('GenRamp', (40, 110), 'Ramp'), ('GenNoise', (40, 180), 'Noise'),
            ('GenCos', (120, 40), 'Cos'), ('GenOneShot', (120, 110), 'OneShot'), ('GenPulse', (120, 180), 'Pulse'),
            ('GenRampCont', (220, 40), 'RampCont'), ('GenSinCont', (220, 110), 'SinCont'),
            ('Const', (40, 425), ''), ('GenStep', (40, 455), ''), ('GenTime', (40, 485), ''),
            ('ConstComplex', (50, 515), ''),
    )

lib_sinks = (
            ('Console', (40, 40), 'Cons'),
            ('FileCSV', (40, 110), 'CSV')
    )

lib_signal = (
             ('Compressor', (40, 40), 'Cmp'),
             ('Expander', (40, 110), 'Exp'),

             ('PortIn', (110, 25), ''),
             ('PortOut', (110, 55), ''),
             ('PortBlockIn', (110, 85), ''),
             ('PortBlockOut', (110, 115), ''),
             ('Block', (210, 40), 'Block'),
             #('RT2', (300, 40), ''),
             ('RK2', (300, 40), 'Process'),
             ('RK2T', (300, 110), 'Thread'),
    )

lib_math = (
            ('Math_SIGN', (40, 40), 'Sign'), ('Math_POW3', (40, 110), 'Pow3'),
            ('Math_LOG', (40, 180), 'Log'), ('Math_POW2', (40, 250), 'Pow2'),
            ('Math_SQRT', (40, 320), 'Sqrt'),
            ('Math_EXP', (120, 40), 'Exp'), ('Math_ABS', (120, 110), 'Abs'),
            ('Math_SIN', (120, 180), 'Sin'), ('Math_COS', (120, 250), 'Cos'),
            ('Math_LN', (120, 320), 'Ln'),

            ('Logistic', (200, 40), 'Logistic'), ('Chuafonc', (200, 110), 'Chua'),

            ('SumN', (270, 110), 'Sum'),
            ('MultN', (270, 40), 'Mult'),
            )

lib_visual = (
             ('SliderH', (120, 40), ''),
             ('ProgressH', (120, 90), ''),
             ('SliderV', (50, 230), ''),

             ('DisplayNum', (300, 40), ''),
             ('pseTextInput', (300, 90), ''),

             ('pseButton', (420, 90), ''),
             ('pseButtonSwitch', (420, 40), ''),

             ('pseImage', (650, 480), ''),
             ('pseText', (650, 420), ''),

             ('pseSwitch', (530, 40), ''),
    )

lib_graph = (
             ('Graph_YT', (40, 40), 'Graph YT'),
             ('Graph_XY', (40, 110), 'Graph XY'),
             )

lib_clock = (
             ('Clock', (40, 40), 'Clock'),
             ('ClockSync', (40, 110), 'ClockSync'),
             ('Delay', (40, 180), 'Delay'),
             )

lib_analog = (
             ('Gain', (50, 50), 'Gain'),
             ('Integ', (50, 130), 'Int'),
             )

# konfiguracia kniznic, poradie je priradene ikonam v menu kniznice
libConfig = (
             ('Library Sources', lib_source),
             ('Library Sinks', lib_sinks),
             ('Library Signal', lib_signal),
             ('Library Graph', lib_graph),
             ('Library Math', lib_math),
             ('Library Digital', ()),
             ('Library Analog', lib_analog),
             ('Library Clock', lib_clock),
             ('Library Visual', lib_visual),
    )
