# -*- coding: utf-8 -*-
from src.component import *
from lib.sources.generators import BoxSource

from cfg.config_pse import *


class Const(BoxSource):
    '''!
    Komponent reprezentujúci konštantu.

    Optimalizovana verzia nastavenia hodnoty konstanty a vyvolania rekurzivneho prepocitania
    prepocitania stavu komponentov. Pretoze konstanta sa nemeni, k prepocitaniu stavov pripojenych
    komponentov dojde len v prvom prechode cez stav STEP.

    @ToDo format zobrazenia - format cisel na velkost komponentu
    '''
    def __init__(self):
        super().__init__()
        self.type = compType.SOURCE
        self.border = (dp(-25), dp(-10), dp(50), dp(20))

        self.out = TermJoint(self, 1, 'Out', (40, 0), termType.OUTPUT)

        Parameter(self, 'Value', 'Const value', 1.0, True, (0, 0), False)
        self.getParam('Ref').isVisible = False     # zrusenie viditelnosti 'Ref' parametra
        self.getParam('Value').isLocked = True     # zrusenie volneho posuvania parametra

        self.points = (dp(25), dp(40))
        self.termLine = Line()

    def build(self):
        super().build()
        self.canvas.add(RGBA_Color(color.flatBlue2))
        self.canvas.add(self.termLine)

    def swapHorizontal(self):
        super().swapHorizontal()
        self.points = (-self.points[0], -self.points[1])

    def update(self):
        super().update()
        self.termLine.points = (self.points[0] + self.pos[0], self.pos[1], self.points[1] + self.pos[0], self.pos[1])

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.out.shared.value[0] = self.getParValue('Value')


class ConstComplex(BoxSource):
    '''!
    Komponent reprezentujúci komplexnú konštantu.

    Optimalizovana verzia nastavenia hodnoty konstanty a vyvolania rekurzivneho prepocitania
    prepocitania stavu komponentov. Pretoze konstanta sa nemeni, k prepocitaniu stavov pripojenych
    komponentov dojde len v prvom prechode cez stav STEP.

    @ToDo format zobrazenia - zrusit zatvorky, format cisel na velkost komponentu
    '''
    def __init__(self):
        super().__init__()
        self.type = compType.SOURCE
        self.border = (dp(-35), dp(-10), dp(70), dp(20))
        self.shapeColor = color.flatGray5

        self.out = TermJoint(self, 1, 'Out', (50, 0), termType.OUTPUT)

        Parameter(self, 'Value', 'Const complex value', 1.0 + 1j, True, (0, 0), False)
        self.getParam('Ref').isVisible = False     # zrusenie viditelnosti 'Ref' parametra
        self.getParam('Value').isLocked = True     # zrusenie posuvania parametra

        self.points = (dp(35), dp(50))
        self.termLine = Line()

    def build(self):
        super().build()
        self.canvas.add(RGBA_Color(color.flatBlue2))
        self.canvas.add(self.termLine)

    def swapHorizontal(self):
        super().swapHorizontal()
        self.points = (-self.points[0], -self.points[1])

    def update(self):
        super().update()
        self.termLine.points = (self.points[0] + self.pos[0], self.pos[1], self.points[1] + self.pos[0], self.pos[1])

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.out.shared.value[0] = complex(self.getParValue('Value'))