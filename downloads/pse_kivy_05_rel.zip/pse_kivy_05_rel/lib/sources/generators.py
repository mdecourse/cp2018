# -*- coding: utf-8 -*-
import math
import random

from src.component import *
from cfg.config_pse import *


class BoxSource(BoxComponent):
    '''!
    Supertrieda pre zdroje hodnot s jednym vystupom.
    '''

    def __init__(self):
        super(BoxSource, self).__init__()
        self.type = compType.SOURCE
        self.shapeColor = color.darkBlue
        self.shapeBorderColor = color.flatBlue2
        self.menu.menuItems[5] = None                              # zrusenie polozky vertikalneho preklopenia


class GenSin(BoxSource):

    def __init__(self):
        super(GenSin, self).__init__()

        self.image = './lib/sources/img/gensine.png'

        self.out = TermTriangle(self, 1, 'Out', (35, 0), termType.OUTPUT, termDir.EAST)

        Parameter(self, 'Amplitude', 'Generator amplitude', 1.0, True, (0, -40), True)
        Parameter(self, 'Frequency', 'Generator frequency in [Hz]', 2.0, True, (0, -60), True)
        Parameter(self, 'Phase', 'Generator phase in [deg]', (0.0, -180.0, 180.0))
        Parameter(self, 'Offset', 'Amplitude offset', 0.0)

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.ampl = self.getParValue('Amplitude')
            self.offs = self.getParValue('Offset')
            self.f = self.getParValue('Frequency')
            self.phase = self.getParValue('Phase') / 180.0 * math.pi
            self.out.shared.value[0] = self.ampl * math.sin(self.phase) + self.offs

        elif state == sysState.STEP:
            self.out.shared.value[0] = self.ampl * math.sin(2 * math.pi * self.f * time + self.phase) + self.offs


class GenCos(BoxSource):

    def __init__(self):
        super(GenCos, self).__init__()

        self.image = './lib/sources/img/gencos.png'

        self.out = TermTriangle(self, 1, 'Out', (35, 0), termType.OUTPUT, termDir.EAST)

        Parameter(self, 'Amplitude', 'Generator amplitude', 1.0, True, (0, -40), True)
        Parameter(self, 'Frequency', 'Generator frequency in [Hz]', 2.0, True, (0, -60), True)
        Parameter(self, 'Phase', 'Generator phase in [deg]', (0.0, -180.0, 180.0))
        Parameter(self, 'Offset', 'Amplitude offset', 0.0)

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.ampl = self.getParValue('Amplitude')
            self.offs = self.getParValue('Offset')
            self.f = self.getParValue('Frequency')
            self.phase = self.getParValue('Phase') / 180.0 * math.pi
            self.out.shared.value[0] = self.ampl * math.cos(self.phase) + self.offs

        elif state == sysState.STEP:
            self.out.shared.value[0] = self.ampl * math.cos(2 * math.pi * self.f * time + self.phase) + self.offs


class GenNoise(BoxSource):
    '''!
    Generátor šumu

    Generátor šumu s normálnou (Gaussovou) distribúciou. Pre generátor je možné nastaviť
    strednú hodnotu generovaného šumu a štandardnú odchýlku.
    '''
    def __init__(self):
        super(GenNoise, self).__init__()
        self.image = './lib/sources/img/gennoise.png'

        self.out = TermTriangle(self, 1, 'Out', (35, 0), termType.OUTPUT, termDir.EAST)

        Parameter(self, 'Mean', 'Mean value', 0.0)
        Parameter(self, 'Sigma', 'Standard deviation', 1.0)

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.m = self.getParValue('Mean')
            self.s = self.getParValue('Sigma')
        elif state == sysState.STEP:
            self.out.shared.value[0] = random.gauss(self.m, self.s)


class GenRampCont(BoxSource):

    def __init__(self):
        super().__init__()
        self.image = './lib/sources/img/ramp.png'
        self.border = (dp(-35), dp(-25), dp(70), dp(50))

        self.slp = TermTriangle(self, 1, 'SL', (-45, 10), termType.INPUT, termDir.EAST)
        self.slp.nameShow = True
        self.slp.namePos = (dp(19), 0)

        self.ofs = TermTriangle(self, 2, 'OF', (-45, -10), termType.INPUT, termDir.EAST)
        self.ofs.nameShow = True
        self.ofs.namePos = (dp(19), 0)

        self.out = TermTriangle(self, 3, 'OUT', (45, 0), termType.OUTPUT, termDir.EAST)

        self.imagePos = (dp(-15), dp(-20))

    def eval(self, state, time=0):
        self.out.shared.value[0] = time * self.slp.shared.value + self.ofs.shared.value


class GenSinCont(BoxSource):

    def __init__(self):
        super().__init__()
        self.image = './lib/sources/img/gensine.png'
        self.border = (dp(-35), dp(-25), dp(70), dp(50))

        self.amp = TermTriangle(self, 1, 'AM', (-45, 20), termType.INPUT, termDir.EAST)
        self.amp.nameShow = True
        self.amp.namePos = (dp(19), 0)

        self.frq = TermTriangle(self, 2, 'FR', (-45, 0), termType.INPUT, termDir.EAST)
        self.frq.nameShow = True
        self.frq.namePos = (dp(19), 0)

        self.phs = TermTriangle(self, 3, 'PH', (-45, -20), termType.INPUT, termDir.EAST)
        self.phs.nameShow = True
        self.phs.namePos = (dp(19), 0)

        self.out = TermTriangle(self, 4, 'OUT', (45, 0), termType.OUTPUT, termDir.EAST)

        self.imagePos = (dp(-15), dp(-20))

    def eval(self, state, time=0):
        self.out.shared.value[0] = self.amp.shared.value * math.sin(2 * math.pi * self.frq.shared.value * time
                                                                     + self.phs.shared.value * math.pi / 180.0)


class GenPulse(BoxSource):
    '''!
    Generátor impulzov.
    '''

    def __init__(self):
        super(GenPulse, self).__init__()
        self.image = './lib/sources/img/genpulse.png'

        self.out = TermTriangle(self, 1, 'Out', (35, 0), termType.OUTPUT, termDir.EAST)

        Parameter(self, 'Amplitude', 'Pulse amplitude', 1.0)
        Parameter(self, 'Offset', 'DC level offset', 0.0)
        Parameter(self, 'Frequency', 'Pulse frequency [Hz]', 1.0)
        Parameter(self, 'Width', 'Pulse width 0% - 100%', 50.0)
        Parameter(self, 'Phase', 'Pulse phase [deg]', 0.0)
        Parameter(self, 'Polarity', 'Pulse polarity', True)

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.ampl = self.getParValue('Amplitude')
            self.offs = self.getParValue('Offset')
            self.f = self.getParValue('Frequency')
            self.w = self.getParValue('Width')
            self.ph = self.getParValue('Phase') / 180.0 * math.pi
            self.pol = self.getParValue('Polarity')

            self.out.shared.value = self.offs

        elif state == sysState.STEP:
            q = math.fmod(time + self.ph, 1 / self.f)

            if q * self.f <= self.w * 0.01:
                value = self.ampl
            else:
                value = -self.ampl

            if self.pol is False:
                value = -value

            self.out.shared.value[0] = value + self.offs


class GenStep(BoxSource):
    '''!
    Komponent reprezentujúci aktualny krok simulácie.
    '''
    def __init__(self):
        super().__init__()
        self.type = compType.SOURCE
        self.border = (dp(-25), dp(-10), dp(50), dp(20))

        self.out = TermJoint(self, 1, 'Out', (40, 0), termType.OUTPUT)

        self.getParam('Ref').isVisible = False     # zrusenie viditelnosti 'Ref' parametra

        self.points = (dp(25), dp(40))
        self.termLine = Line()
        self.text = Label(text='Step', size=(0, 0), italic=True)

    def build(self):
        super().build()
        self.canvas.add(RGBA_Color(color.flatBlue2))
        self.canvas.add(self.termLine)
        self.add_widget(self.text)

    def update(self):
        super().update()
        self.termLine.points = (self.points[0] + self.pos[0], self.pos[1], self.points[1] + self.pos[0], self.pos[1])
        self.text.pos = self.pos

    def swapHorizontal(self):
        super().swapHorizontal()
        self.points = (-self.points[0], -self.points[1])

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.count = 0
            self.out.shared.value[0] = 0
        if state == sysState.STEP:
            self.out.shared.value[0] = self.count
            self.count = self.count + 1


class GenTime(BoxSource):
    '''!
    Komponent reprezentujúci aktualny čas simulácie.
    '''
    def __init__(self):
        super(GenTime, self).__init__()
        self.border = (dp(-25), dp(-10), dp(50), dp(20))

        self.out = TermJoint(self, 1, 'Out', (40, 0), termType.OUTPUT)

        self.getParam('Ref').isVisible = False     # zrusenie viditelnosti 'Ref' parametra

        self.points = (dp(25), dp(40))
        self.termLine = Line()
        self.text = Label(text='Time', size=(0, 0), italic=True)

    def build(self):
        super().build()
        self.canvas.add(RGBA_Color(color.flatBlue2))
        self.canvas.add(self.termLine)
        self.add_widget(self.text)

    def update(self):
        super().update()
        self.termLine.points = (self.points[0] + self.pos[0], self.pos[1], self.points[1] + self.pos[0], self.pos[1])
        self.text.pos = self.pos

    def swapHorizontal(self):
        super().swapHorizontal()
        self.points = (-self.points[0], -self.points[1])

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.out.shared.value[0] = 0.0
        if state == sysState.STEP:
            self.out.shared.value[0] = time


class GenRamp(BoxSource):

    def __init__(self):
        super(GenRamp, self).__init__()
        self.image = './lib/sources/img/ramp.png'

        self.out = TermTriangle(self, 1, 'Out', (35, 0), termType.OUTPUT)

        Parameter(self, 'Slope', 'Ramp slope', 1.0)
        Parameter(self, 'Offset', 'Initial value offset', 0.0)

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.slp = self.getParValue('Slope')
            self.ofs = self.getParValue('Offset')
            self.out.shared.value[0] = self.ofs

        if state == sysState.STEP:
            self.out.shared.value[0] = time * self.slp + self.ofs


class GenOneShot(BoxSource):
    '''!
    Generátor impulzu.
    '''

    def __init__(self):
        super().__init__()
        self.image = './lib/sources/img/oneshot.png'

        self.out = TermTriangle(self, 1, 'Out', (35, 0))

        Parameter(self, 'Amplitude', 'Pulse amplitude', 1.0)
        Parameter(self, 'Offset', 'DC level offset', 0.0)
        Parameter(self, 'Start', 'Pulse start [sec]', 1.0)
        Parameter(self, 'Stop', 'Pulse end [sec]', 2.0)
        Parameter(self, 'Polarity', 'Pulse polarity', True)

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.ampl = self.getParValue('Amplitude')
            self.offs = self.getParValue('Offset')
            self.start = self.getParValue('Start')
            self.stop = self.getParValue('Stop')
            self.pol = self.getParValue('Polarity')

        if state == sysState.STEP:
            if time >= self.start and time <= self.stop:
                value = self.ampl
            else:
                value = -self.ampl

            if self.pol is False:
                value = -value

            self.out.shared.value[0] = value + self.offs