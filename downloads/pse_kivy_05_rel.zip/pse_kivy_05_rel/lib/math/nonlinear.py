# -*- coding: utf-8 -*-
from src.common import *
from src.component import *
import math


class Logistic(BoxComponent):

    def __init__(self):
        super().__init__()
        self.type = compType.CONTINUOUS
        self.shapeColor = color.flatGray5
        self.shapeBorderColor = color.flatYellow2
        self.image = './lib/math/img/logistic.png'

        self.in1 = TermTriangle(self, 1, 'In1', (-35, 10), termType.INPUT, termDir.EAST)
        self.in2 = TermTriangle(self, 2, 'In2', (-35, -10), termType.INPUT, termDir.EAST)
        self.out = TermTriangle(self, 3, 'Out', (35, 0), termType.OUTPUT, termDir.EAST)

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.out.shared.value[0] = 0.7

        if state == sysState.STEP:
            self.out.shared.value[0] = 4.0 * self.in1.shared.value[0] * self.in2.shared.value[0] * (1 - self.in2.shared.value[0])


class Chuafonc(BoxComponent):

    def __init__(self):
        super().__init__()
        self.shapeColor = color.flatGray5
        self.shapeBorderColor = color.flatYellow2
        self.image = './lib/math/img/chuafonc.png'

        self.inp = TermTriangle(self, 1, 'In', (-35, 0), termType.INPUT, termDir.EAST)
        self.out = TermTriangle(self, 2, 'Out', (35, 0), termType.OUTPUT, termDir.EAST)

        Parameter(self, 'M0', '', -1.1428571)
        Parameter(self, 'M1', '', -0.7142857)

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.m0 = self.getParValue('M0')
            self.m1 = self.getParValue('M1')

        if state == sysState.STEP:
            self.out.shared.value = (self.m1 * self.inp.shared.value
                                     + 0.5 * (self.m0 - self.m1) * (math.abs(self.inp.shared.value + 1.0)
                                     - math.abs(self.inp.shared.value - 1.0)))
