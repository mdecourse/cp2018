# -*- coding: utf-8 -*-
import numpy as np

from src.common import *
from src.component import *

from kivy.logger import Logger


class MathBox(BoxComponent):
    '''!
    Supertrieda pre komponenty reprezentujuce matematicke funkcie y=func(x).

    Funkcie akceptuju realne aj komplexne hodnoty, implementovane su pomocou knižnice numpy.
    '''

    def __init__(self):
        super().__init__()
        self.type = compType.CONTINUOUS
        self.shapeColor = color.flatGray5
        self.shapeBorderColor = color.flatYellow2

        self.inp = TermTriangle(self, 1, 'In', (-35, 0), termType.INPUT, termDir.EAST)
        self.out = TermTriangle(self, 2, 'Out', (35, 0), termType.OUTPUT, termDir.EAST)


class Math_ABS(MathBox):

    def __init__(self):
        super().__init__()
        self.name = 'ABS'
        self.image = './lib/math/img/func_abs.png'

    def eval(self, state, time=0):
        try:
            self.out.shared.value = np.abs(self.inp.shared.value)
        except:
            Logger.error('Math_ABS: ' + self.getParValue('Ref') + ' Value error ' + str(self.inp.getValue()))
            self.out.setValue(self.inp.getValue())
            self.diagram.stop()


class Math_LN(MathBox):

    def __init__(self):
        super().__init__()
        self.image = './lib/math/img/func_ln.png'

    def eval(self, state, time=0):
        try:
            self.out.shared.value = np.log(self.inp.shared.value)
        except:
            Logger.error('Math_LN: ' + self.getParValue('Ref') + ' Value error ' + str(self.inp.getValue()))
            self.out.setValue(self.inp.getValue())
            self.diagram.stop()


class Math_LOG(MathBox):

    def __init__(self):
        super().__init__()
        self.image = './lib/math/img/func_log.png'

    def eval(self, state, time=0):
        try:
            self.out.shared.value = np.log10(self.inp.shared.value)
        except:
            Logger.error('Math_LOG: ' + self.getParValue('Ref') + ' Value error ' + str(self.inp.getValue()))
            self.out.setValue(self.inp.getValue())
            self.diagram.stop()


class Math_SIN(MathBox):

    def __init__(self):
        super().__init__()
        self.image = './lib/math/img/func_sin.png'

    def eval(self, state, time=0):
        try:
            self.out.shared.value = np.sin(self.inp.shared.value)
        except:
            Logger.error('Math_SIN: ' + self.getParValue('Ref') + ' Value error ' + str(self.inp.getValue()))
            self.out.setValue(self.inp.getValue())
            self.diagram.stop()


class Math_COS(MathBox):

    def __init__(self):
        super().__init__()
        self.image = './lib/math/img/func_cos.png'

    def eval(self, state, time=0):
        try:
            self.out.shared.value = np.cos(self.inp.shared.value)
        except:
            Logger.error('Math_COS: ' + self.getParValue('Ref') + ' Value error ' + str(self.inp.getValue()))
            self.out.setValue(self.inp.getValue())        # posleme povodne data, funkcia pri chybe
            self.diagram.stop()                           # data zmrsi a zastavime simulaciu


class Math_POW2(MathBox):

    def __init__(self):
        super().__init__()
        self.image = './lib/math/img/func_pow2.png'

    def eval(self, state, time=0):
        try:
            self.out.shared.value = np.power(self.inp.shared.value, 2.0)
        except:
            Logger.error('Math_POW2: ' + self.getParValue('Ref') + ' Value error ' + str(self.inp.getValue()))
            self.out.setValue(self.inp.getValue())
            self.diagram.stop()


class Math_POW3(MathBox):

    def __init__(self):
        super().__init__()
        self.image = './lib/math/img/func_pow3.png'

    def eval(self, state, time=0):
        try:
            self.out.shared.value = np.power(self.inp.shared.value, 3.0)
        except:
            Logger.error('Math_POW3: ' + self.getParValue('Ref') + ' Value error ' + str(self.inp.getValue()))
            self.out.setValue(self.inp.getValue())
            self.diagram.stop()


class Math_SQRT(MathBox):

    def __init__(self):
        super().__init__()
        self.image = './lib/math/img/func_sqrt.png'

    def eval(self, state, time=0):
        try:
            self.out.shared.value = np.sqrt(self.inp.shared.value)
        except:
            Logger.error('Math_SQRT: ' + self.getParValue('Ref') + ' Value error ' + str(self.inp.getValue()))
            self.out.setValue(self.inp.getValue())
            self.diagram.stop()


class Math_EXP(MathBox):

    def __init__(self):
        super().__init__()
        self.image = './lib/math/img/func_exp.png'

    def eval(self, state, time=0):
        try:
            self.out.shared.value = np.exp(self.inp.shared.value)
        except:
            Logger.error('Math_EXP: ' + self.getParValue('Ref') + ' Value error ' + str(self.inp.getValue()))
            self.out.setValue(self.inp.getValue())
            self.diagram.stop()


class Math_SIGN(MathBox):

    def __init__(self):
        super().__init__()
        self.image = './lib/math/img/func_sign.png'

    def eval(self, state, time=0):
        try:
            self.out.shared.value = np.sign(self.inp.shared.value)
        except:
            Logger.error('Math_SIGN: ' + self.getParValue('Ref') + ' Value error ' + str(self.inp.getValue()))
            self.out.setValue(self.inp.getValue())
            self.diagram.stop()