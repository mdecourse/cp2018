# -*- coding: utf-8 -*-

import numpy as np
from collections import OrderedDict

from src.common import *
from src.component import *
from kivy.graphics import *
from kivy.logger import Logger


class SumN(BoxComponent):
    '''!
    Sucet / rozdiel vstupov

    Parameter Inputs určuje počet vstupov, default = 2, maximalny počet vstupov je 16.
    '''
    def __init__(self):
        super().__init__()
        self.type = compType.CONTINUOUS
        self.shapeColor = color.flatGray5
        self.shapeBorderColor = color.flatYellow2
        self.border = [dp(-10), dp(-20), dp(20), dp(40)]
        self.inputs = 2
        self.menu.menuItems[5] = None                         # zrusenie vertikalneho zrkadlenia
        self.maxInputs = 16

        TermTriangle(self, 1, 'A', (-20, 10), termType.INPUT, termDir.EAST)
        TermTriangle(self, 2, 'B', (-20, -10), termType.INPUT, termDir.EAST)
        TermTriangle(self, 100, 'Y', (20, 0), termType.OUTPUT, termDir.EAST)

        Parameter(self, 'Inputs', 'Polarity (+/-) and number of inputs', '++')
        self.polarity = [1, 1]

    def build(self):

        self.polarity = []
        for c in self.paramDict['Inputs'].value:              # @ToDo chyba pri zlom zadani vstupov ?
            if c == '+':                                      # koeficienty polarity suctu
                self.polarity.append(1)                       # blbe znaky su ignorovane
            else:
                self.polarity.append(-1)
        inputs = len(self.polarity)

        if inputs != self.inputs:                             # kontrola zapornej alebo nespravnej hodnoty
            if inputs < 2:                                    # chyba, vratit na povodny stav, zrusi zmenu
                self.paramDict['Inputs'].value = '++'        # obnovenie hodnoty parametra
                self.inputs = 2
                return

            if inputs > self.maxInputs:                       # kontrola max. poctu vstupov
                inputs = self.maxInputs                       # korekcia, pocet vstupov > 16
                self.paramDict['Inputs'].value = '+' * self.maxInputs

            #-------------------------------------------------
            # 1. zmazanie povodnych terminalov
            #    a odlozenie zoznamov pripojenych net-ov
            #-------------------------------------------------
            tempConn = OrderedDict()                          # docasny zozname terminalov s pripojenymi net-mi
            for num, t in self.termDict.items():
                if num != 100:                                # vystupny terminal nezaradeny, ostava bez zmeny
                    tempConn[num] = t
            for num, t in tempConn.items():                   # zmazanie referencii na odlozene, @ToDo lepsie cez zoznam klucov
                self.termDict[num].clear_widgets()            # ??? zmazanie, memory leaks
                del self.termDict[num]                        # terminaly v slovniku terminalov komponentu

            #-------------------------------------------------
            # 2. generovanie noveho poctu terminalov
            #-------------------------------------------------
            y = 0
            if (inputs % 2) == 0:                             # kontrola - parne/neparne cislo
                y = (inputs // 2) * 20 - 10                   # vypocet vertikalnej polohy prveho terminalu
            else:
                y = (inputs // 2) * 20

            max_y = y
            min_y = y - inputs * 20

            for q in range(inputs):                            # vytvorenie terminalov, zaradenie do termDict
                TermTriangle(self, q + 1, chr(q + 64), (-20, y), termType.INPUT, termDir.EAST)
                y = y - 20

                                                              # utriedenie poradia terminalov, vystup (100-vka) na koniec
            self.termDict = OrderedDict(sorted(self.termDict.items(), key=lambda t: t[0]))

            #-------------------------------------------------
            # 3. Obnovenie pripojenia terminalov
            #-------------------------------------------------
            if inputs > self.inputs:                          # pocet novych vstupov > ako pocet povodnych,
                                                              # pripojime exist. siete k povodnym terminalom
                # 3.1 pripojenie sieti k novym terminalom a update koncovych bodov sieti
                for num, old in tempConn.items():
                    t = self.termDict[num]                    # terminal z odlozeneho slovnika
                    t.netDict = old.netDict                   # kopia slovniku spojov
                    for nid, n in t.netDict.items():          # uprava koncovych bodov pripojenych sieti
                        if n.startTerm == old:                # na nove terminaly
                            n.startTerm = t
                        else:
                            n.endTerm = t
            else:
                # 3.2 pripojenie sieti k novym terminalom a update koncovych bodov sieti
                #     pocet novych vstupov je mensi ako povodny, prepojenia k neexistujucim
                #     terminalom budu zmazane
                for num, t in self.termDict.items():          # slovnik novych terminalov
                    if num != 100:                            # vynechany vystupny terminal
                        old = tempConn[num]                   # terminal z odlozeneho slovnika
                        t.netDict = old.netDict
                        for nid, n in t.netDict.items():      # uprava koncovych bodov pripojenych sieti
                            if n.startTerm == old:
                                n.startTerm = t
                            else:
                                n.endTerm = t
                        del tempConn[num]

                for num, t in tempConn.items():              # zmazanie prebytocnych sieti, ktore
                    for nid, n in t.netDict.items():         # nie je mozne pripojit, terminaly neexistuju
                        self.diagram.delNet(n)

            # uprava rozmeru bloku a posunutie 'Ref' parametra
            self.border = [dp(-10), dp(-max_y - 10), dp(20), dp(max_y - min_y)]
            self.getParam('Ref').pos = (0, dp(max_y + 20))

            self.inputs = inputs

        super().build()
        self.canvas.add(RGBA_Color(color.flatYellow1))
        self.signArray = []
        for j in range(self.inputs):
            line1 = Line()
            line2 = Line()
            self.signArray.append([self.getTerminal(j + 1), line1, line2])
            self.canvas.add(line1)
            self.canvas.add(line2)

    def update(self):
        super().update()
        sgSize = 5
        for j in range(len(self.signArray)):
            [t, line1, line2] = self.signArray[j]
            line1.points = (dp(-sgSize) + self.pos[0], 0 + self.pos[1] + t.pos[1], dp(sgSize) + self.pos[0], 0 + self.pos[1] + t.pos[1])
            if self.polarity[j] == 1:
                line2.points = (0 + self.pos[0], dp(sgSize) + self.pos[1] + t.pos[1], 0 + self.pos[0], dp(-sgSize) + self.pos[1] + t.pos[1])
            else:
                line2.points = ()

    def eval(self, state, time=0):
        try:
            self.termDict[100].shared.value = np.copy(self.termDict[1].shared.value) * self.polarity[0]

            for num in range(2, self.inputs + 1):
                if self.polarity[num - 1] == 1:
                    self.termDict[100].shared.value += np.array(self.termDict[num].shared.value)
                else:
                    self.termDict[100].shared.value -= np.array(self.termDict[num].shared.value)
        except:
            Logger.error('SumN: ' + self.getParValue('Ref') + ' Value error, terminal ' + str(num) + ', ' + str(self.termDict[num].getValue()))
            self.termDict[100].shared.value = [0.0]
            self.diagram.stop()


class MultN(BoxComponent):
    '''!
    Sucet / rozdiel vstupov

    Parameter Inputs určuje počet vstupov, default = 2, maximalny počet vstupov je 16.
    '''
    def __init__(self):
        super().__init__()
        self.type = compType.CONTINUOUS
        self.shapeColor = color.flatGray5
        self.shapeBorderColor = color.flatYellow2
        self.border = [dp(-10), dp(-20), dp(20), dp(40)]
        self.inputs = 2
        self.menu.menuItems[5] = None                         # zrusenie vertikalneho zrkadlenia
        self.maxInputs = 16

        TermTriangle(self, 1, 'A', (-20, 10), termType.INPUT, termDir.EAST)
        TermTriangle(self, 2, 'B', (-20, -10), termType.INPUT, termDir.EAST)
        TermTriangle(self, 100, 'Y', (20, 0), termType.OUTPUT, termDir.EAST)

        Parameter(self, 'Inputs', 'Mult[*] / Div[/] and number of inputs', '**')

        self.polarity = []
        self.signArray = []

    def build(self):

        self.polarity = []
        for c in self.paramDict['Inputs'].value:              # @ToDo chyba pri zlom zadani vstupov ?
            if c == '*':                                      # koeficienty polarity suctu
                self.polarity.append(1)                       # blbe znaky su ignorovane
            else:
                self.polarity.append(-1)
        inputs = len(self.polarity)

        if inputs != self.inputs:                             # kontrola zapornej alebo nespravnej hodnoty
            if inputs < 2:                                    # chyba, vratit na povodny stav, zrusi zmenu
                self.paramDict['Inputs'].value = '**'        # obnovenie hodnoty parametra
                self.inputs = 2
                return

            if inputs > self.maxInputs:                       # kontrola max. poctu vstupov
                inputs = self.maxInputs                       # korekcia, pocet vstupov > 16
                self.paramDict['Inputs'].value = '*' * self.maxInputs

            #-------------------------------------------------
            # 1. zmazanie povodnych terminalov
            #    a odlozenie zoznamov pripojenych net-ov
            #-------------------------------------------------
            tempConn = OrderedDict()                          # docasny zozname terminalov s pripojenymi net-mi
            for num, t in self.termDict.items():
                if num != 100:                                # vystupny terminal nezaradeny, ostava bez zmeny
                    tempConn[num] = t
            for num, t in tempConn.items():                   # zmazanie referencii na odlozene, @ToDo lepsie cez zoznam klucov
                self.termDict[num].clear_widgets()            # ??? zmazanie, memory leaks
                del self.termDict[num]                        # terminaly v slovniku terminalov komponentu

            #-------------------------------------------------
            # 2. generovanie noveho poctu terminalov
            #-------------------------------------------------
            y = 0
            if (inputs % 2) == 0:                             # kontrola - parne/neparne cislo
                y = (inputs // 2) * 20 - 10                   # vypocet vertikalnej polohy prveho terminalu
            else:
                y = (inputs // 2) * 20

            max_y = y
            min_y = y - inputs * 20

            for q in range(inputs):                            # vytvorenie terminalov, zaradenie do termDict
                TermTriangle(self, q + 1, chr(q + 64), (-20, y), termType.INPUT, termDir.EAST)
                y = y - 20

            #-------------------------------------------------
            # 3. Obnovenie pripojenia terminalov
            #-------------------------------------------------
            if inputs > self.inputs:                          # pocet novych vstupov > ako pocet povodnych,
                                                              # pripojime exist. siete k povodnym terminalom
                # 3.1 pripojenie sieti k novym terminalom a update koncovych bodov sieti
                for num, old in tempConn.items():
                    t = self.termDict[num]                    # terminal z odlozeneho slovnika
                    t.netDict = old.netDict                   # kopia slovniku spojov
                    for nid, n in t.netDict.items():          # uprava koncovych bodov pripojenych sieti
                        if n.startTerm == old:                # na nove terminaly
                            n.startTerm = t
                        else:
                            n.endTerm = t
            else:
                # 3.2 pripojenie sieti k novym terminalom a update koncovych bodov sieti
                #     pocet novych vstupov je mensi ako povodny, prepojenia k neexistujucim
                #     terminalom budu zmazane
                for num, t in self.termDict.items():          # slovnik novych terminalov
                    if num != 100:                            # vynechany vystupny terminal
                        old = tempConn[num]                   # terminal z odlozeneho slovnika
                        t.netDict = old.netDict
                        for nid, n in t.netDict.items():      # uprava koncovych bodov pripojenych sieti
                            if n.startTerm == old:
                                n.startTerm = t
                            else:
                                n.endTerm = t
                        del tempConn[num]

                for num, t in tempConn.items():              # zmazanie prebytocnych sieti, ktore
                    for nid, n in t.netDict.items():         # nie je mozne pripojit, terminaly neexistuju
                        self.diagram.delNet(n)

            # uprava rozmeru bloku a posunutie 'Ref' parametra
            self.border = [dp(-10), dp(-max_y - 10), dp(20), dp(max_y - min_y)]
            self.getParam('Ref').pos = (0, dp(max_y + 20))

            self.inputs = inputs

        super().build()
        self.canvas.add(RGBA_Color(color.flatYellow1))
        self.signArray = []
        for j in range(self.inputs):
            line1 = Line()
            line2 = Line()
            self.signArray.append([self.getTerminal(j + 1), line1, line2])
            self.canvas.add(line1)
            self.canvas.add(line2)

    def update(self):
        super().update()
        sgSize = 5
        for j in range(len(self.signArray)):
            [t, line1, line2] = self.signArray[j]
            line1.points = (dp(-sgSize) + self.pos[0], dp(-sgSize) + self.pos[1] + t.pos[1], dp(sgSize) + self.pos[0], dp(sgSize) + self.pos[1] + t.pos[1])
            if self.polarity[j] == 1:
                line2.points = (dp(-sgSize) + self.pos[0], dp(sgSize) + self.pos[1] + t.pos[1], dp(sgSize) + self.pos[0], dp(-sgSize) + self.pos[1] + t.pos[1])
            else:
                line2.points = ()

    def eval(self, state, time=0):
        self.termDict[100].shared.value = np.copy(self.termDict[1].shared.value)           # @ToDo - kontrola va ValueError exception - nerovnake dlzky vektorov

        try:
            for num in range(2, self.inputs + 1):
                if self.polarity[num - 1] == 1:
                    self.termDict[100].shared.value *= (self.termDict[num].shared.value)
                else:
                    self.termDict[100].shared.value /= (self.termDict[num].shared.value)
        except:
            Logger.error('MultN: ' + self.getParValue('Ref') + ' Value error, terminal ' + str(num) + ', ' + str(self.termDict[num].getValue()))
            self.termDict[100].shared.value = [1.0]
            self.diagram.stop()


class Gain(AnalogComp):
    '''!
    Štandardný zosilňovač Out = Gain * In
    '''
    def __init__(self):
        super().__init__()
        self.type = compType.CONTINUOUS
        self.shapeColor = color.flatGray5
        self.boxColor = color.flatYellow1

        Parameter(self, 'Gain', 'Amplifier gain', 1.0, True, (0, -40))
        Parameter(self, 'Offset', 'Amplifier offset', 0.0, False, (0, -60))

        self.label = Label(text='K', size=(dp(-15), 0), font_size=dp(20), color=color.flatYellow1, italic=True)

    def build(self):
        super().build()
        self.add_widget(self.label)

    def update(self):
        super().update()
        if self.swapHoriz is True:
            self.label.pos = (self.pos[0] + dp(15), self.pos[1])
        else:
            self.label.pos = self.pos

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.gain = self.getParValue('Gain')
            self.offs = self.getParValue('Offset')
            self.out.shared.value[0] = self.offs

        elif state == sysState.STEP:
            #if np.isscalar(self.inp.shared.value) is True:
            self.out.shared.value[0] = self.inp.shared.value[0] * self.gain + self.offs
            #else:
            #    self.out.shared.value = np.array(self.inp.shared.value) * self.gain + self.offs


class Integ(AnalogComp):
    '''!
    Štandardný integrator Out = Int(Gain * In) dt + InitValue
    '''
    def __init__(self):
        super().__init__()
        self.type = compType.INTEGRAL
        self.shapeColor = color.flatGray5
        self.boxColor = color.flatYellow1

        self.image = './lib/math/img/integ.png'
        Parameter(self, 'Gain', 'Integrator gain', 1.0, False, (0, 40))
        Parameter(self, 'Init', 'Integrator init value', 0.0, False, (0, -40))

    def eval(self, state, time=0, value=0):
        if state == sysState.INIT:
            self.gain = self.getParValue('Gain')
            self.init = self.getParValue('Init')
            self.out.shared.value[0] = self.init
            return self.init / self.gain

            #elif state == sysState.DERIVE:
            #return self.inp.shared.value[0]

            #elif state == sysState.STEP:
            #self.out.shared.value[0] = value * self.gain
