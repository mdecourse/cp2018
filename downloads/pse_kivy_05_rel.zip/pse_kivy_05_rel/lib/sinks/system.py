# -*- coding: utf-8 -*-
from src.common import *
from src.component import *

import numpy as np


class Console(BoxComponent):
    '''!
    Výstup hodnôt terminalu na systémovú konzolu.
    '''

    def __init__(self):
        super().__init__()
        self.type = compType.SINKS
        self.image = './lib/sinks/img/console.png'
        self.shapeColor = color.darkBlue
        self.shapeBorderColor = color.white

        self.inp = TermTriangle(self, 1, 'In', (-35, 0), termType.INPUT, termDir.EAST)

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.ref = self.getParValue('Ref')

        if state == sysState.STEP:
            self.string = self.ref + '   {:6.3f}   '.format(time)
            self.printValue(self.inp.shared.value)
            print(self.string)

    def printValue(self, data):
        # Rekurzívna tlac zdielaných hodnôt.
        if np.isscalar(data) is False:
            self.string = self.string + '['
            for q in data:                            # iteracia po zozname
                if np.isscalar(data) is False:
                    self.printValue(q)
            self.string = self.string + ']'
        else:
            self.string = self.string + '{: 6.3f},  '.format(data)


class FileCSV(BoxComponent):

    def __init__(self):
        super().__init__()
        self.type = compType.SINKS
        self.image = './lib/sinks/img/file_write_csv.png'
        self.shapeColor = color.darkBlue
        self.shapeBorderColor = color.white

        self.inp = TermTriangle(self, 1, 'In', (-35, 0), termType.INPUT, termDir.EAST)
        Parameter(self, 'File', 'Output file name', 'output.txt', True, (0, -40))
        Parameter(self, 'Delimiter', 'Field delimiter', ['Comma', 'Tab', 'Space'])

    '''
    def sim(self, flag, time, step, value=0):
        if flag == cstate.INIT:
            fileName = self.getParamValue('File')
            self.file = open(fileName, 'w')

        elif flag == cstate.UPDATE:
            s = ''
            q = str(time) + ',' + self.parseValue(self.inp.shared.value, s) + '\n'
            self.file.write(q)

        elif flag == cstate.FINISH:
            self.file.close()

    def parseValue(self, data, s):

        #Rekurzívny parser zdielaných hodnôt.

        if isinstance(data, np.ndarray):
            for q in data:
                if isinstance(data, np.ndarray):
                    s = s + self.parseValue(q, s)

                elif isinstance(data, SharedValue):
                    s = str(q.value) + ','
                else:
                    s = str(q) + ','
            return s

        elif isinstance(data, SharedValue):
            return self.parseValue(data.value, s)
        else:
            return (str(data) + ',')
    '''