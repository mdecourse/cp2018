# -*- coding: utf-8 -*-
import numpy as np
from kivy.properties import *

from src.common import *
from src.component import *


class Graph(BoxComponent):
    '''!
    @todo kontrola na dlzku poli - max 65536
    '''

    def __init__(self):
        super().__init__()
        self.type = compType.SINKS_VISUAL

        self.shapeColor = color.darkBlue
        self.boxColor = color.flatBlue2

        self.hasIcon = True

        self.getParam('Ref').pos = (0, dp(100))    # poloha parametra Ref - nad komponentom
        self.getParam('Name').pos = (0, dp(-100))
        self.getParam('Name').visible = True


class Graph_YT(Graph):

    def __init__(self):
        super().__init__()
        self.image = './lib/sinks/img/graph_yt.png'

        self.inp = TermTriangle(self, 1, 'In', (-130, 0), termType.INPUT, termDir.EAST)

        Parameter(self, 'Y-Min', 'Minimum Y-axis value', -10.0)
        Parameter(self, 'Y-Max', 'Maximum Y-axis value', 10.0)
        Parameter(self, 'T-Min', 'Beginning of the time axis [s]', 0.0)
        Parameter(self, 'T-Max', 'End of the time axis [s]', 10.0)
        Parameter(self, 'Update', 'Update for every nth sample (N=>1)', 1)
        Parameter(self, 'Terminal', 'Terminal position', ['West', 'North', 'East', 'South'])

        self.data_t = np.array([])
        self.data_y = np.array([])

    def build(self):
        if self.hasIcon is True:                              # zobrazenie v kniznici ako ikona
            super().build()                                   # struktura komponentu je ignorovana
            return

        self.border = [dp(-120), dp(-90), dp(240), dp(180)]
        self.image = None                                     # plne zobrazenie na diagrame
        super().build()

        self.line_x = []                                      # vyroba mriezky - staticka verzia
        for q in range(11):
            self.line_x.append(Line())

        self.line_y = []
        for q in range(11):
            self.line_y.append(Line())

        self.canvas.add(RGBA_Color(color.darkSlateGrey))      # zobrazenie mriezky
        for qx in self.line_x:
            self.canvas.add(qx)

        for qy in self.line_y:
            self.canvas.add(qy)

        self.plot_data = [Line(), Line(), Line(), Line()]

        self.canvas.add(RGBA_Color(color.flatGreen3))
        self.canvas.add(self.plot_data[3])
        self.canvas.add(RGBA_Color(color.flatRed1))
        self.canvas.add(self.plot_data[2])
        self.canvas.add(RGBA_Color(color.flatBlue1))
        self.canvas.add(self.plot_data[1])
        self.canvas.add(RGBA_Color(color.flatYellow1))
        self.canvas.add(self.plot_data[0])

        val = self.getParValue('Terminal')
        if val == 'North':
            self.inp.pos = (0, dp(100))
            self.inp.orient = termDir.NORTH
        elif val == 'West':
            self.inp.pos = (dp(-130), 0)
            self.inp.orient = termDir.EAST
        elif val == 'East':
            self.inp.pos = (dp(130), 0)
            self.inp.orient = termDir.WEST
        if val == 'South':
            self.inp.pos = (0, dp(-100))
            self.inp.orient = termDir.SOUTH

    def update(self):
        super().update()

        if self.hasIcon is True:
            return

        #-----------------------------------------------------
        # 1. Vypocet skalovacich konstant
        #-----------------------------------------------------
        if self.data_t.size > 0:                              # uprava hranic a kontrola chybnych zadani
            tmax = np.around(self.data_t[-1], 4)

            xmax = self.getParValue('T-Max')                  # kontrola parametrov
            if xmax >= tmax:
                xmax = tmax
                self.setParValue('T-Max', tmax)

            xmin = self.getParValue('T-Min')
            if xmin >= xmax:
                xmin = 0.0
                self.setParValue('T-Min', xmin)

            ymax = self.getParValue('Y-Max')
            ymin = self.getParValue('Y-Min')
            if ymin >= ymax:
                ymin = -ymax
                self.setParValue('Y-Min', ymin)
        else:
            tmax = 1.0        # default hodnoty bez zobrazenia dat
            xmax = 1.0
            xmin = 0.0
            ymax = 1.0
            ymin = -1.0

        self.n1 = int(xmin / tmax * len(self.data_t))         # dlzka zobrazovaneho zaznamu
        self.n2 = int(xmax / tmax * len(self.data_t))
        if self.n2 >= self.data_t.size:
            self.n2 = self.data_t.size
            self.n1 = 0

        if (self.n2 - self.n1) > 16000:                       # obmedzenie na max. pocet
            self.n2 = self.n1 + 16000                         # zobrazenych dat

        self.kx = (self.border[2] - 10) / (xmax - xmin)
        self.ky = (self.border[3] - 10) / (ymax - ymin)

        #-----------------------------------------------------
        # 2. Aktualizacia vykreslenia mriezky
        #-----------------------------------------------------
        # vypocet polohy pociatocnych a koncovych bodov mriezky
        self.px0 = self.pos[0] + self.border[0] + 5
        self.px1 = self.pos[0] + self.border[0] + self.border[2] - 5

        self.py0 = self.pos[1] + self.border[1] + 5
        self.py1 = self.pos[1] + self.border[1] + self.border[3] - 5

        self.dy = (self.border[3] - 10) / 10.
        for q in range(11):
            self.line_x[q].points = (self.px0, self.py0 + self.dy * q, self.px1, self.py0 + self.dy * q)

        self.dx = (self.border[2] - 10) / 10.
        for q in range(11):
            self.line_y[q].points = (self.px0 + self.dx * q, self.py0, self.px0 + self.dx * q, self.py1)

        #-----------------------------------------------------
        # 3. Aktualizacia grafov
        #-----------------------------------------------------

        if self.data_t.size == 0:                             # graf neobsahuje data
            return

        tt = ((self.data_t[self.n1:self.n2] - xmin) * self.kx + self.px0)

        for k in range(len(self.data_y)):
            points = []
            yd = (np.clip(self.data_y[k][self.n1:self.n2], ymin, ymax) - ymin) * self.ky + self.py0
            for j in range(np.clip(tt.size, 0, 16000)):
                points.append(tt[j])
                points.append(yd[j])
            self.plot_data[k].points = points

    def setValue(self, value):
        # presun hodnot zo shadow diagramu do GUI, doplnenie a skalovanie dat
        self.data_t = np.array(value[0])
        self.data_y = np.array(value[1])
        self.data_y = self.data_y.T
        self.update()

    def getValue(self):
        if self.finish is False:
            return compState.UNTOUCH, []
        else:
            return compState.CHANGED, (self.td, self.yd)      # preposlanie dat

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.td = []                                      # pomocne polia pre zber dat
            self.yd = []
            self.finish = False
            self.updt = self.getParValue('Update')
            self.count = 0

        elif state == sysState.STEP:
            if self.count % self.updt == 0:
                self.td.append(time)
                if len(self.inp.shared.value) == 1:
                    self.yd.append(list(self.inp.shared.value))
                else:
                    self.yd.append([q[0] for q in self.inp.shared.value])

            self.count += 1

        elif state == sysState.STOP:                          # zaverecny presun dat
            self.finish = True


class Graph_XY(Graph):

    def __init__(self):
        super().__init__()
        self.type = compType.SINKS_VISUAL
        self.image = './lib/sinks/img/graph_xy.png'

        self.inp_y = TermTriangle(self, 2, 'Y', (-130, 10), termType.INPUT, termDir.EAST)
        self.inp_x = TermTriangle(self, 1, 'X', (-130, -10), termType.INPUT, termDir.EAST)

        Parameter(self, 'Y-Max', 'Minimum of Y axe', 2.)
        Parameter(self, 'Y-Min', 'Minimum of Y axe', -2.)
        Parameter(self, 'X-Max', 'Minimum of Y axe', 2.)
        Parameter(self, 'X-Min', 'Minimum of Y axe', -2.)
        Parameter(self, 'T-Min', 'Beginning of the time [s]', 0.0)
        Parameter(self, 'T-Max', 'End of the time', 10.0)
        Parameter(self, 'Plot', 'Plot type', ['Line', 'Dots'])
        Parameter(self, 'Update', 'Update for every nth sample (N=>1)', 1)
        Parameter(self, 'Terminal', 'Terminal position', ['West', 'North', 'East', 'South'])

        self.data_x = np.array([])
        self.data_y = np.array([])

    def build(self):

        if self.hasIcon is True:
            super().build()
            return

        self.border = [dp(-120), dp(-90), dp(240), dp(180)]
        self.image = None                                     # plne zobrazenie na diagrame
        super().build()

        self.line_x = []                                      # vyroba mriezky - staticka verzia
        for q in range(11):
            self.line_x.append(Line())

        self.line_y = []
        for q in range(11):
            self.line_y.append(Line())

        self.canvas.add(RGBA_Color(color.darkSlateGrey))      # zobrazenie mriezky
        for qx in self.line_x:
            self.canvas.add(qx)

        for qy in self.line_y:
            self.canvas.add(qy)

        self.plot_data = [Line(), Line(), Line(), Line()]
        self.plotType = self.getParValue('Plot')
        self.canvas.add(RGBA_Color(color.flatGreen1))
        if self.plotType == 'Dots':
            self.plot_data = [Point(pointsize=0.3), Point(pointsize=0.3),
                              Point(pointsize=0.3), Point(pointsize=0.3)]

        self.canvas.add(RGBA_Color(color.flatGreen3))
        self.canvas.add(self.plot_data[3])
        self.canvas.add(RGBA_Color(color.flatRed1))
        self.canvas.add(self.plot_data[2])
        self.canvas.add(RGBA_Color(color.flatBlue1))
        self.canvas.add(self.plot_data[1])
        self.canvas.add(RGBA_Color(color.flatYellow1))
        self.canvas.add(self.plot_data[0])

        val = self.getParValue('Terminal')
        if val == 'North':
            self.inp_x.pos = (dp(-10), dp(100))
            self.inp_x.orient = termDir.NORTH
            self.inp_y.pos = (dp(10), dp(100))
            self.inp_y.orient = termDir.NORTH
        elif val == 'West':
            self.inp_x.pos = (dp(-130), dp(-10))
            self.inp_x.orient = termDir.EAST
            self.inp_y.pos = (dp(-130), dp(10))
            self.inp_y.orient = termDir.EAST
        elif val == 'East':
            self.inp_x.pos = (dp(130), dp(-10))
            self.inp_x.orient = termDir.WEST
            self.inp_y.pos = (dp(130), dp(10))
            self.inp_y.orient = termDir.WEST
        if val == 'South':
            self.inp_x.pos = (dp(-10), dp(-100))
            self.inp_x.orient = termDir.SOUTH
            self.inp_y.pos = (dp(10), dp(-100))
            self.inp_y.orient = termDir.SOUTH

    def update(self):
        super().update()

        if self.hasIcon is True:
            return

        #-----------------------------------------------------
        # 1. Vypocet skalovacich konstant
        #-----------------------------------------------------
        xmax = self.getParValue('X-Max')
        xmin = self.getParValue('X-Min')
        if xmin >= xmax:
            xmin = -xmax

        ymax = self.getParValue('Y-Max')
        ymin = self.getParValue('Y-Min')
        if ymin >= ymax:
            ymin = -ymax

        self.kx = (self.border[2] - 10) / (xmax - xmin)
        self.ky = (self.border[3] - 10) / (ymax - ymin)

        #-----------------------------------------------------
        # 2. Aktualizacia vykreslenia mriezky
        #-----------------------------------------------------
        # vypocet polohy pociatocnych a koncovych bodov mriezky
        self.px0 = self.pos[0] + self.border[0] + 5
        self.px1 = self.pos[0] + self.border[0] + self.border[2] - 5

        self.py0 = self.pos[1] + self.border[1] + 5
        self.py1 = self.pos[1] + self.border[1] + self.border[3] - 5

        self.dy = (self.border[3] - 10) / 10.
        for q in range(11):
            self.line_x[q].points = (self.px0, self.py0 + self.dy * q, self.px1, self.py0 + self.dy * q)

        self.dx = (self.border[2] - 10) / 10.
        for q in range(11):
            self.line_y[q].points = (self.px0 + self.dx * q, self.py0, self.px0 + self.dx * q, self.py1)

        #-----------------------------------------------------
        # 3. Aktualizacia grafov
        #-----------------------------------------------------
        if self.data_x.size == 0:                             # graf neobsahuje data
            return

        for k in range(len(self.data_y)):
            points = []
            yd = (np.clip(self.data_y[k], ymin, ymax) - ymin) * self.ky + self.py0
            xd = (np.clip(self.data_x[k], xmin, xmax) - xmin) * self.kx + self.px0
            for j in range(len(xd)):
                points.append(xd[j])
                points.append(yd[j])
            self.plot_data[k].points = points

    def setValue(self, value):
        # presun hodnot zo shadow diagramu do GUI, doplnenie a skalovanie dat
        self.data_x = np.array(value[0])
        self.data_y = np.array(value[1])
        self.data_x = self.data_x.T
        self.data_y = self.data_y.T
        self.update()

    def getValue(self):
        if self.finish is False:
            return compState.UNTOUCH, []
        else:
            return compState.CHANGED, (self.xd, self.yd)

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.xd = []                                      # pomocne polia pre zber dat
            self.yd = []
            self.finish = False
            self.updt = self.getParValue('Update')
            self.count = 0

        elif state == sysState.STEP:
            if self.count % self.updt == 0:
                if len(self.inp_y.shared.value) == 1:
                    self.yd.append(list(self.inp_y.shared.value))
                else:
                    self.yd.append([q[0] for q in self.inp_y.shared.value])

                if len(self.inp_x.shared.value) == 1:
                    self.xd.append(list(self.inp_x.shared.value))
                else:
                    self.xd.append([q[0] for q in self.inp_x.shared.value])

            self.count += 1

        elif state == sysState.STOP:                          # zaverecny presun dat
            self.finish = True


'''
class Scope_XY(Graph):

    #Osiloskopické zobrazenie XY priebehu.

    #Na grafe sa zobrazuje stopa o stanovenej dĺžke záznamu. Po skončení simulácie zostávajú zobrazené
    #posledné dáta.


    def __init__(self):
        super(Scope_XY, self).__init__()

        self.xmin = -2.0
        self.xmax = 2.0
        self.ymin = -2.0
        self.ymax = 2.0

        self.plotType = 'Line'

        self.shapeImage = './lib/sinks/img/scope_xy.png'

        self.inp_y = TermTriangle(self, 2, 'Y', (-130, 10), ttype.Input, tdir.West)
        self.inp_x = TermTriangle(self, 1, 'X', (-130, -10), ttype.Input, tdir.West)

        CompParameter(self, 'Type', 'Plot type', ['Line', 'Dot'])
        CompParameter(self, 'Base', 'Time range', 1.)
        CompParameter(self, 'Size', 'Dot size / Line width', 1.0)
        CompParameter(self, 'Y-Max', 'Minimum of Y axe', 2.)
        CompParameter(self, 'Y-Min', 'Minimum of Y axe', -2.)
        CompParameter(self, 'X-Max', 'Minimum of Y axe', 2.)
        CompParameter(self, 'X-Min', 'Minimum of Y axe', -2.)
        CompParameter(self, 'Terminal', 'Terminal position', ['West', 'North', 'East', 'South'])

        self.line_x = []
        self.line_y = []

        self.points = []

        # data pre mriezky - staticka verzia
        for q in range(9):
            self.line_x.append(Line())

        for q in range(11):
            self.line_y.append(Line())

        self.line_data = Line(cap='round', joint='round')
        self.point_data = Point(pointsize=1.0)

    def update(self):

        super(Scope_XY, self).update()

        if self.isLibIcon is True:
            return

        # rozmer x-rozsahu
        self.px0 = self.pos[0] + self.border[0] + 5
        self.px1 = self.pos[0] + self.border[0] + self.border[2] - 5

        # rozmer y-rozsahu
        self.py0 = self.pos[1] + self.border[1] + 5
        self.py1 = self.pos[1] + self.border[1] + self.border[3] - 5

        self.kx = (self.px1 - self.px0) / (self.xmax - self.xmin)
        self.ky = (self.py1 - self.py0) / (self.ymax - self.ymin)

        # mriezka
        self.dy = (self.py1 - self.py0) / 8.
        for q in range(9):
            self.line_x[q].points = (self.px0, self.py0 + self.dy * q, self.px1, self.py0 + self.dy * q)

        self.dx = (self.px1 - self.px0) / 10.
        for q in range(11):
            self.line_y[q].points = (self.px0 + self.dx * q, self.py0, self.px0 + self.dx * q, self.py1)

        self.point_width = self.getParamValue('Size')
        self.points = []        # pri presune sa zmaze zobrazovany priebeh
        if self.plotType == 'Line':
            self.line_data.points = self.points
            self.line_data.width = self.point_width
        else:
            self.point_data.points = self.points
            self.point_data.pointsize = self.point_width

    def build(self):
        if self.isLibIcon is False:
            self.shapeImage = None
            super(Scope_XY, self).build()

        if self.isLibIcon is True:
            super(Scope_XY, self).build()
            return

        self.canvas.add(RGBA_Color(rgba.darkSlateGrey))
        for qx in self.line_x:
            self.canvas.add(qx)

        for qy in self.line_y:
            self.canvas.add(qy)

        self.plotType = self.getParamValue('Type')
        self.canvas.add(RGBA_Color(rgba.yellow))
        if self.plotType == 'Line':
            self.canvas.add(self.line_data)
        else:
            self.canvas.add(self.point_data)

        val = self.getParamValue('Terminal')
        if val == 'North':
            self.inp_x.pos = (dp(-10), dp(100))
            self.inp_x.orient = tdir.North
            self.inp_y.pos = (dp(10), dp(100))
            self.inp_y.orient = tdir.North
        elif val == 'West':
            self.inp_x.pos = (dp(-130), dp(-10))
            self.inp_x.orient = tdir.West
            self.inp_y.pos = (dp(-130), dp(10))
            self.inp_y.orient = tdir.West
        elif val == 'East':
            self.inp_x.pos = (dp(130), dp(-10))
            self.inp_x.orient = tdir.East
            self.inp_y.pos = (dp(130), dp(10))
            self.inp_y.orient = tdir.East
        if val == 'South':
            self.inp_x.pos = (dp(-10), dp(-100))
            self.inp_x.orient = tdir.South
            self.inp_y.pos = (dp(10), dp(-100))
            self.inp_y.orient = tdir.South

        self.update()

    def sim(self, flag, stime, step, value=0):
        if flag == cstate.INIT:
            self.data_x = []
            self.data_y = []

            self.tbase = self.getParamValue('Base')
            self.ymin = self.getParamValue('Y-Min')
            self.ymax = self.getParamValue('Y-Max')
            self.xmin = self.getParamValue('X-Min')
            self.xmax = self.getParamValue('X-Max')

            self.update()

        elif flag == cstate.UPDATE:

            x = self.inp_x.shared.value
            y = self.inp_y.shared.value

            if x >= self.xmax:            # kontrola prekrocenia rozsahu
                x = self.xmax
            if x <= self.xmin:
                x = self.xmin

            if y >= self.ymax:
                y = self.ymax
            if y <= self.ymin:
                y = self.ymin

            self.points.append((x - (self.xmax + self.xmin) / 2.) * self.kx + (self.px1 + self.px0) / 2.)
            self.points.append((y - (self.ymax + self.ymin) / 2.) * self.ky + (self.py1 + self.py0) / 2.)

            if stime >= self.tbase:         # skratenie pola
                self.points = self.points[2:]

        elif flag == cstate.REFRESH:
            if self.plotType == 'Line':
                self.line_data.points = self.points
            else:
                self.point_data.points = self.points


class Scope_YT(Graph):

    #Osciloskopické zobrazenie priebehu pre RT Simulácie.


    def __init__(self):
        super(Scope_YT, self).__init__()

        self.xbase = 10.0
        self.ymin = -2.0
        self.ymax = 2.0

        self.data_x = []
        self.data_y = []

        self.shapeImage = './lib/sinks/img/graph_yt.png'

        self.inp = TermTriangle(self, 1, 'In', (-130, 0), ttype.Input, tdir.West)

        CompParameter(self, 'Y-Max', 'Minimum of Y axe', 10.)
        CompParameter(self, 'Y-Min', 'Minimum of Y axe', -10.)
        CompParameter(self, 'X-Base', 'Time range of X axe', 10.)
        CompParameter(self, 'Terminal', 'Terminal position', ['West', 'North', 'East', 'South'])

        self.line_x = []
        self.line_y = []
        self.points = []
        self.numPlots = 1

        # data pre mriezky - staticka verzia
        for q in range(9):
            self.line_x.append(Line())

        for q in range(11):
            self.line_y.append(Line())

        self.line_data = [Line(), Line(), Line(), Line()]

    def update(self):
        super(Scope_YT, self).update()

        if self.isLibIcon is True:
            return

        # rozmer x-rozsahu
        self.px0 = self.pos[0] + self.border[0] + 5
        self.px1 = self.pos[0] + self.border[0] + self.border[2] - 5

        # rozmer y-rozsahu
        self.py0 = self.pos[1] + self.border[1] + 5
        self.py1 = self.pos[1] + self.border[1] + self.border[3] - 5

        self.kx = (self.px1 - self.px0) / self.xbase
        self.ky = (self.py1 - self.py0) / (self.ymax - self.ymin)
        self.dy = (self.py1 + self.py0) / 2.

        self.dy = (self.py1 - self.py0) / 8.
        for q in range(9):
            self.line_x[q].points = (self.px0, self.py0 + self.dy * q, self.px1, self.py0 + self.dy * q)

        self.dx = (self.px1 - self.px0) / 10.
        for q in range(11):
            self.line_y[q].points = (self.px0 + self.dx * q, self.py0, self.px0 + self.dx * q, self.py1)

        for i in range(self.numPlots):
            self.points = []
            for j in range(len(self.data_x)):
                self.points.append(self.data_x[j] * self.kx + self.px0)
                self.points.append((self.data_y[i][j] - (self.ymax + self.ymin) / 2.) * self.ky + (self.py1 + self.py0) / 2.)
            self.line_data[i].points = self.points

    def build(self):
        if self.isLibIcon is False:
            self.shapeImage = None
            super(Scope_YT, self).build()

        if self.isLibIcon is True:
            super(Scope_YT, self).build()
            return

        self.canvas.add(RGBA_Color(rgba.darkSlateGrey))
        for qx in self.line_x:
            self.canvas.add(qx)

        for qy in self.line_y:
            self.canvas.add(qy)

        self.canvas.add(RGBA_Color(rgba.flatGreen3))
        self.canvas.add(self.line_data[3])
        self.canvas.add(RGBA_Color(rgba.flatRed1))
        self.canvas.add(self.line_data[2])
        self.canvas.add(RGBA_Color(rgba.flatBlue1))
        self.canvas.add(self.line_data[1])
        self.canvas.add(RGBA_Color(rgba.flatYellow1))
        self.canvas.add(self.line_data[0])

        val = self.getParamValue('Terminal')
        if val == 'North':
            self.inp.pos = (0, dp(100))
            self.inp.orient = tdir.North
        elif val == 'West':
            self.inp.pos = (dp(-130), 0)
            self.inp.orient = tdir.West
        elif val == 'East':
            self.inp.pos = (dp(130), 0)
            self.inp.orient = tdir.East
        if val == 'South':
            self.inp.pos = (0, dp(-100))
            self.inp.orient = tdir.South

        self.update()

    def sim(self, flag, stime, step, value=0):
        if flag == cstate.INIT:

            self.numPlots = 4    # pocet vykreslenych priebehov
            self.data_x = []     # x-ova os dat
            self.data_y = [[], [], [], []]
            self.update()

            if isinstance(self.inp.shared.value, np.ndarray) or isinstance(self.inp.shared.value, list):
                self.numPlots = len(self.inp.shared.value)
                if self.numPlots > 4:
                    self.numPlots = 4
            else:
                self.numPlots = 1

            self.xbase = self.getParamValue('X-Base')
            self.ymin = self.getParamValue('Y-Min')
            self.ymax = self.getParamValue('Y-Max')

            self.MAX_POINTS = 240                            # redukcia poctu bodov na grafe, max. pocet
            self.pointsCounter = 0                           # pocitadlo bodov rozsah 0 ... 240
            self.deltaBase = self.xbase / self.MAX_POINTS    # casovy interval medzi bodmi

        elif flag == cstate.UPDATE:

            if stime > self.deltaBase * self.pointsCounter:   # kontrola prekrocenia intervalu
                self.pointsCounter = self.pointsCounter + 1   # presun na novy interval

                if stime < self.xbase:
                    self.data_x.append(stime)

                if self.numPlots == 1:
                    y = self.inp.shared.value
                    if y >= self.ymax:
                        y = self.ymax
                    if y <= self.ymin:
                        y = self.ymin

                    if stime < self.xbase:
                        self.data_y[0].append(y)
                    else:
                        self.data_y[0].append(y)
                        self.data_y[0] = self.data_y[0][1:]

                else:
                    for i in range(self.numPlots):
                        q = self.inp.shared.value[i]
                        if isinstance(q, SharedValue):
                            y = q.value
                        else:
                            y = q

                        if y >= self.ymax:
                            y = self.ymax
                        if y <= self.ymin:
                            y = self.ymin

                        if stime < self.xbase:
                            self.data_y[i].append(y)
                        else:
                            self.data_y[i].append(y)
                            self.data_y[i] = self.data_y[i][1:]

        elif flag == cstate.REFRESH:     # obnovenie zobrazenia pocas RT simulacie
            self.update()
'''