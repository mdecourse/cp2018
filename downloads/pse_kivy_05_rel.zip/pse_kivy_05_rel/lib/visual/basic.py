# -*- coding: utf-8 -*-
from src.common import *
from src.component import *

from kivy.uix.progressbar import ProgressBar
from kivy.uix.slider import Slider
from kivy.uix.button import Button
from kivy.uix.switch import Switch
from kivy.uix.textinput import TextInput


class SliderH(BoxComponent):
    '''!
    Horizontálny slider.
    '''
    def __init__(self):
        super().__init__()

        self.shapeBorderColor = color.grey
        self.shapeColor = color.black
        self.type = compType.SOURCE_VISUAL

        Parameter(self, 'Min', 'Minimal value', 0)
        Parameter(self, 'Max', 'Maximal value', 100)
        Parameter(self, 'Step', 'Slider step', 1.0)
        Parameter(self, 'Terminal', 'Terminal position', ['East', 'South', 'West', 'North'])

        self.getParam('Ref').pos = (0, dp(30))
        self.getParam('Name').pos = (0, dp(-30))

        self.out = TermTriangle(self, 1, 'Out', (100, 0), termType.OUTPUT, termDir.EAST)

        self.border = [dp(-90), dp(-20), dp(180), dp(40)]
        self.slider = Slider(min=-100, max=100, value=25)
        self.slider.size = (self.border[2], self.border[3])

        self.state = compState.UNTOUCH
        self.slider.bind(value=self.onSliderChange)                # obsluha zmeny hodnoty slider-u

    def onSliderChange(self, obj, value):
        self.state = compState.CHANGED
        self.out.setValue(self.slider.value)

    def build(self):
        super().build()
        val = self.getParValue('Terminal')
        if val == 'North':
            self.out.pos = (0, dp(30))
            self.out.orient = termDir.NORTH
        elif val == 'West':
            self.out.pos = (dp(-100), 0)
            self.out.orient = termDir.WEST
        elif val == 'East':
            self.out.pos = (dp(100), 0)
            self.out.orient = termDir.EAST
        if val == 'South':
            self.out.pos = (0, dp(-30))
            self.out.orient = termDir.SOUTH

        self.add_widget(self.slider)

    def update(self):
        super().update()
        self.slider.pos = (self.pos[0] - dp(90), self.pos[1] - dp(20))

    def getValue(self):
        '''!
        Nacitanie hodnoty a stavu z grafickeho rozhrania.
        '''
        state = self.state
        self.state = compState.UNTOUCH
        return state, self.out.getValue()

    def setValue(self, value):
        '''!
        Nastavenie hodnoty v shadow - prostredi
        '''
        self.out.shared.value[0] = value

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.slider.min = self.getParValue('Min')
            self.slider.max = self.getParValue('Max')


class SliderV(BoxComponent):
    '''!
    Vertikálny slider.
    '''
    def __init__(self):
        super().__init__()
        self.shapeBorderColor = color.grey
        self.shapeColor = color.black
        self.type = compType.SOURCE_VISUAL

        Parameter(self, 'Min', 'Minimal value', 0.0)
        Parameter(self, 'Max', 'Maximal value', 100.0)
        Parameter(self, 'Step', 'Slider step', 1.0)
        Parameter(self, 'Terminal', 'Terminal position', ['South', 'West', 'North', 'East'])
        self.getParam('Ref').pos = (0, dp(100))
        self.getParam('Name').pos = (0, dp(-100))

        self.out = TermTriangle(self, 1, 'Out', (0, -100), termType.OUTPUT, termDir.SOUTH)

        self.border = [dp(-20), dp(-90), dp(40), dp(180)]
        self.slider = Slider(min=-100, max=100, value=25, orientation='vertical')
        self.slider.size = (self.border[2], self.border[3])

        self.state = compState.UNTOUCH
        self.slider.bind(value=self.onSliderChange)                # obsluha zmeny hodnoty slider-u

    def onSliderChange(self, obj, value):
        self.state = compState.CHANGED
        self.out.setValue(self.slider.value)

    def update(self):
        super().update()
        # nastavenie horizontalnej polohy - namiesto hodnoty 20 pre Android je potrebne pouzit 27.5
        # korekcia chyby
        #if platform == 'android':
        #    self.slider.pos = (self.pos[0] - dp(27.5), self.pos[1] - dp(90))
        #else:
        self.slider.pos = (self.pos[0] - dp(20.), self.pos[1] - dp(90.))

    def build(self):
        super().build()

        val = self.getParValue('Terminal')
        if val == 'North':
            self.out.pos = (0, dp(100))
            self.out.orient = termDir.NORTH
        elif val == 'West':
            self.out.pos = (dp(-30), 0)
            self.out.orient = termDir.WEST
        elif val == 'East':
            self.out.pos = (dp(30), 0)
            self.out.orient = termDir.EAST
        if val == 'South':
            self.out.pos = (0, dp(-100))
            self.out.orient = termDir.SOUTH

        self.add_widget(self.slider)

    def getValue(self):
        '''!
        Nacitanie hodnoty a stavu z grafickeho rozhrania.
        '''
        state = self.state
        self.state = compState.UNTOUCH
        return state, self.out.getValue()

    def setValue(self, value):
        '''!
        Nastavenie hodnoty v shadow - prostredi
        '''
        self.out.setValue(value)

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.slider.min = self.getParValue('Min')
            self.slider.max = self.getParValue('Max')


class ProgressH(BoxComponent):
    '''!
    '''
    def __init__(self):
        super().__init__()

        self.shapeBorderColor = color.grey
        self.shapeColor = color.black
        self.type = compType.SINKS_VISUAL

        Parameter(self, 'Max', 'Maximal value', 100.0)
        Parameter(self, 'Terminal', 'Terminal position', ['West', 'East', 'South', 'North'])
        self.getParam('Ref').pos = (0, dp(30))
        self.getParam('Name').pos = (0, dp(-30))

        self.inp = TermTriangle(self, 1, 'In', (-100, 0), termType.INPUT, termDir.WEST)

        self.border = [dp(-90), dp(-20), dp(180), dp(40)]
        self.bar = ProgressBar()
        self.bar.size = (self.border[2], self.border[3])
        self.state = compState.UNTOUCH
        self.value = 0.0

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.bar.max = self.getParValue('Max')

    def build(self):
        super().build()
        val = self.getParValue('Terminal')
        if val == 'North':
            self.inp.pos = (0, dp(30))
            self.inp.orient = termDir.NORTH
        elif val == 'West':
            self.inp.pos = (dp(-100), 0)
            self.inp.orient = termDir.EAST
        elif val == 'East':
            self.inp.pos = (dp(100), 0)
            self.inp.orient = termDir.WEST
        if val == 'South':
            self.inp.pos = (0, dp(-30))
            self.inp.orient = termDir.SOUTH

        self.add_widget(self.bar)

    def update(self):
        super().update()
        self.bar.pos = (self.pos[0] - dp(90), self.pos[1] - dp(20))

    def setValue(self, value):
        self.bar.value = value

    def getValue(self):
        value = self.inp.getValue()
        if self.value == value:
            return compState.UNTOUCH, self.value
        else:
            self.value = value
            return compState.CHANGED, self.value


class pseText(Component):
    '''!
    Editovateľný text na ploche.
    '''
    def __init__(self):
        super().__init__()

        self.type = compType.DECORATION
        self.border = (dp(-30), dp(-20), dp(60), dp(40))

        Parameter(self, 'Text', 'HTML Text', 'Text', False, (0, 40))
        Parameter(self, 'Size', 'Font size', 20, False, (0, 40))
        self.getParam('Ref').isVisible = False

        self.label = Label(text='Label', markup=True)
        self.label.color = color.yellow
        self.label.italic = True
        self.label.size = (0, 0)

        self.labelBox = Line()

        self.menu.itemValue[3] = 0            # uprava / zusenie poloziek on-screen menu
        self.menu.menuItems[3] = None
        self.menu.itemValue[5] = 0
        self.menu.menuItems[5] = None

    def update(self):
        super().update()
        self.label.pos = self.pos
        self.label.text = self.getParValue('Text')
        self.label.font_size = dp(self.getParValue('Size'))

        self.label.texture_update()
        (dx, dy) = self.label.texture_size
        self.border = (- dx / 2., - dy / 2., dx, dy)

        if self.isSelected is True:
            self.labelBox.rectangle = (self.pos[0] - dx / 2., self.pos[1] - dy / 2., dx, dy)

    def build(self):
        super().build()
        self.add_widget(self.label)
        if self.isSelected is True:
            self.canvas.add(RGBA_Color(color.red))
            self.canvas.add(self.labelBox)


class pseButton(BoxComponent):
    '''!
    Tlacitko.
    '''
    def __init__(self):
        super().__init__()

        self.shapeBorderColor = (0, 0, 0, 0)
        self.shapeColor = (0, 0, 0, 0)
        self.type = compType.SOURCE_VISUAL

        self.border = (dp(-30), dp(-20), dp(60), dp(40))
        #self.value = 0

        self.menu.itemValue[3] = 0            # uprava / zusenie poloziek on-screen menu
        self.menu.menuItems[3] = None
        self.menu.itemValue[5] = 0
        self.menu.menuItems[5] = None

        Parameter(self, 'Label', 'Button label ', 'Button')
        Parameter(self, 'Terminal', 'Terminal position', ['East', 'South', 'West', 'North'])
        self.getParam('Ref').pos = (0, dp(30))
        self.getParam('Name').pos = (0, dp(-30))

        self.out = TermTriangle(self, 1, 'Out', (40, 0), termType.OUTPUT, termDir.EAST)

        self.button = Button(text='Button', font_size='14dp', pos=(self.pos[0] - dp(30), self.pos[1] - dp(20)), size=(self.border[2], self.border[3]))
        self.button.bind(on_press=self.button_pressed)
        self.button.bind(on_release=self.button_released)
        self.state = compState.UNTOUCH

        self.buttonBox = Line()

    def button_pressed(self, obj):
        self.out.setValue(1)
        self.state = compState.CHANGED

    def button_released(self, obj):
        self.out.setValue(0)
        self.state = compState.CHANGED

    def getValue(self):
        '''!
        Nacitanie hodnoty a stavu z grafickeho rozhrania.
        '''
        state = self.state
        self.state = compState.UNTOUCH
        return state, self.out.getValue()

    def setValue(self, value):
        '''!
        Nastavenie hodnoty v shadow - prostredi
        '''
        self.out.setValue(value)

    def update(self):
        super().update()
        self.button.pos = (self.pos[0] - dp(30), self.pos[1] - dp(20))
        self.buttonBox.rectangle = (self.button.pos[0], self.button.pos[1], self.button.size[0], self.button.size[1])

    def build(self):
        super().build()

        self.button.text = self.getParValue('Label')

        val = self.getParValue('Terminal')
        if val == 'North':
            self.out.pos = (0, dp(30))
            self.out.orient = termDir.NORTH
        elif val == 'West':
            self.out.pos = (dp(-40), 0)
            self.out.orient = termDir.WEST
        elif val == 'East':
            self.out.pos = (dp(40), 0)
            self.out.orient = termDir.EAST
        if val == 'South':
            self.out.pos = (0, dp(-30))
            self.out.orient = termDir.SOUTH

        self.add_widget(self.button)


class pseButtonSwitch(BoxComponent):
    '''!
    Tlacitko.
    '''
    def __init__(self):
        super().__init__()

        self.shapeBorderColor = (0, 0, 0, 0)
        self.shapeColor = (0, 0, 0, 0)
        self.type = compType.SOURCE_VISUAL

        self.border = (dp(-30), dp(-20), dp(60), dp(40))

        self.value = 0
        self.btnState = False    # false - released. true - pressed

        self.menu.itemValue[3] = 0            # uprava / zusenie poloziek on-screen menu
        self.menu.menuItems[3] = None
        self.menu.itemValue[5] = 0
        self.menu.menuItems[5] = None
        self.state = compState.UNTOUCH

        Parameter(self, 'Pressed', 'Button label pressed', 'True')
        Parameter(self, 'Released', 'Button label released', 'False')
        Parameter(self, 'Terminal', 'Terminal position', ['East', 'South', 'West', 'North'])

        self.getParam('Ref').pos = (0, dp(30))
        self.getParam('Name').pos = (0, dp(-30))

        self.out = TermTriangle(self, 1, 'Out', (40, 0), termType.OUTPUT, termDir.EAST)

        self.button = Button(text='False', pos=(self.pos[0] - dp(30), self.pos[1] - dp(20)), size=(self.border[2], self.border[3]))
        self.button.bind(on_press=self.button_pressed)
        self.buttonBox = Line()

    def button_pressed(self, obj):
        self.state = compState.CHANGED
        if self.btnState is True:
            self.btnState = False
            self.button.text = self.getParValue('Released')
            self.out.setValue(0)
        else:
            self.btnState = True
            self.button.text = self.getParValue('Pressed')
            self.out.setValue(1)

    def getValue(self):
        '''!
        Nacitanie hodnoty a stavu z grafickeho rozhrania.
        '''
        state = self.state
        self.state = compState.UNTOUCH
        return state, self.out.getValue()

    def setValue(self, value):
        '''!
        Nastavenie hodnoty v shadow - prostredi
        '''
        self.out.setValue(value)

    def update(self):
        super().update()
        self.button.pos = (self.pos[0] - dp(30), self.pos[1] - dp(20))
        self.buttonBox.rectangle = (self.button.pos[0], self.button.pos[1], self.button.size[0], self.button.size[1])

    def build(self):
        super().build()
        if self.state is True:
            self.button.text = self.getParValue('Pressed')
        else:
            self.button.text = self.getParValue('Released')

        val = self.getParValue('Terminal')
        if val == 'North':
            self.out.pos = (0, dp(30))
            self.out.orient = termDir.NORTH
        elif val == 'West':
            self.out.pos = (dp(-40), 0)
            self.out.orient = termDir.WEST
        elif val == 'East':
            self.out.pos = (dp(40), 0)
            self.out.orient = termDir.EAST
        if val == 'South':
            self.out.pos = (0, dp(-30))
            self.out.orient = termDir.SOUTH

        self.add_widget(self.button)


class pseImage(BoxComponent):
    '''!
    PNG obrazok na ploche.
    '''
    def __init__(self):
        super().__init__()

        self.type = compType.DECORATION
        self.border = (dp(-48), dp(-48), dp(96), dp(96))
        self.shapeBorderColor = (0, 0, 0, 0)
        self.shapeColor = (0, 0, 0, 0)

        self.menu.itemValue[3] = 0            # uprava / zusenie poloziek on-screen menu
        self.menu.menuItems[3] = None
        self.menu.itemValue[5] = 0
        self.menu.menuItems[5] = None

        Parameter(self, 'Image', 'Image file name', './lib/visual/img/logo_1.png')
        Parameter(self, 'Width', 'Image width', 96)
        Parameter(self, 'Height', 'Image height', 96)

        self.getParam('Ref').isVisible = False
        self.imageComp = Rectangle(size=(dp(96), dp(96)))

    def update(self):
        super().update()
        self.imageComp.source = self.getParValue('Image')
        w = dp(self.getParValue('Width'))
        h = dp(self.getParValue('Height'))
        self.imageComp.size = (w, h)
        self.imageComp.pos = (self.pos[0] + self.border[0], self.pos[1] + self.border[1])

    def build(self):
        super().build()
        self.canvas.add(RGBA_Color(color.white))
        self.canvas.add(self.imageComp)


class DisplayNum(BoxComponent):
    '''!
    Zobrazenie numerickej hodnoty

    @todo Kontrola formatu, hlasenie o chybe
    '''
    def __init__(self):
        super().__init__()

        self.shapeColor = color.black
        self.type = compType.SINKS_VISUAL

        Parameter(self, 'Format', 'Output number format', '{:.2f}')
        Parameter(self, 'Terminal', 'Terminal position', ['West', 'East', 'South', 'North'])
        self.getParam('Ref').pos = (0, dp(30))
        self.getParam('Name').pos = (0, dp(-30))

        self.inp = TermTriangle(self, 1, 'In', (-60, 0), termType.INPUT, termDir.EAST)

        self.border = [dp(-50), dp(-20), dp(100), dp(40)]
        self.label = Label(text='0.00', markup=True)
        self.label.color = color.lightSteelBlue
        #self.label.italic = True
        self.label.size = (0, 0)
        self.label.font_size = dp(25)
        self.format = '{:.2f}'

        self.state = compState.UNTOUCH
        self.value = 0.0

    def update(self):
        super().update()
        self.label.pos = (self.pos[0], self.pos[1])

    def build(self):
        super().build()
        val = self.getParValue('Terminal')
        if val == 'North':
            self.inp.pos = (0, dp(30))
            self.inp.orient = termDir.NORTH
        elif val == 'West':
            self.inp.pos = (dp(-60), 0)
            self.inp.orient = termDir.EAST
        elif val == 'East':
            self.inp.pos = (dp(60), 0)
            self.inp.orient = termDir.WEST
        if val == 'South':
            self.inp.pos = (0, dp(-30))
            self.inp.orient = termDir.SOUTH

        self.add_widget(self.label)

    def setValue(self, value):
        self.label.text = self.format.format(float(value))

    def getValue(self):
        value = self.inp.shared.value[0]
        if self.value == value:
            return compState.UNTOUCH, self.value
        else:
            self.value = value
            return compState.CHANGED, self.value


class pseSwitch(BoxComponent):
    '''!
    Prepinac.
    '''
    def __init__(self):
        super().__init__()

        self.shapeBorderColor = color.grey
        self.shapeColor = color.black
        self.type = compType.SOURCE_VISUAL
        self.shapeBorderColor = (0, 0, 0, 0)
        self.shapeColor = (0, 0, 0, 0)
        #self.border = [dp(-45), dp(-15), dp(90), dp(30)]
        self.menu.itemValue[3] = 0            # uprava / zusenie poloziek on-screen menu
        self.menu.menuItems[3] = None
        self.menu.itemValue[5] = 0
        self.menu.menuItems[5] = None

        Parameter(self, 'Terminal', 'Terminal position', ['East', 'South', 'West', 'North'])
        self.getParam('Ref').pos = (0, dp(25))
        self.getParam('Name').pos = (0, dp(-25))

        self.out = TermTriangle(self, 1, 'Out', (55, 0), termType.OUTPUT, termDir.EAST)
        self.state = compState.UNTOUCH

        self.switch = Switch()
        self.switch.bind(active=self.onSwitchChange)
        self.border = [dp(-45), dp(-15), dp(90), dp(30)]
        self.switch.size = (self.border[2], self.border[3])

    def onSwitchChange(self, obj, value):
        self.state = compState.CHANGED
        if value is True:
            self.out.setValue(1)
        else:
            self.out.setValue(0)

    def build(self):
        super().build()
        val = self.getParValue('Terminal')
        if val == 'North':
            self.out.pos = (0, dp(25))
            self.out.orient = termDir.NORTH
        elif val == 'West':
            self.out.pos = (dp(-55), 0)
            self.out.orient = termDir.WEST
        elif val == 'East':
            self.out.pos = (dp(55), 0)
            self.out.orient = termDir.EAST
        if val == 'South':
            self.out.pos = (0, dp(-25))
            self.out.orient = termDir.SOUTH

        self.add_widget(self.switch)

    def update(self):
        super().update()
        self.switch.pos = (self.pos[0] - 45, self.pos[1] - 15)

    def getValue(self):
        state = self.state                                    # Nacitanie hodnoty a stavu z grafickeho rozhrania.
        self.state = compState.UNTOUCH
        return state, self.out.getValue()

    def setValue(self, value):
        self.out.setValue(value)                              # Nastavenie hodnoty v shadow - prostredi


class pseTextInput(BoxComponent):
    '''!
    '''
    def __init__(self):
        super().__init__()

        self.shapeBorderColor = color.grey
        self.shapeColor = color.black
        self.type = compType.SOURCE_VISUAL

        Parameter(self, 'Value', 'Default value', 1.0)
        Parameter(self, 'Terminal', 'Terminal position', ['East', 'South', 'West', 'North'])

        self.getParam('Ref').pos = (0, dp(30))
        self.getParam('Name').pos = (0, dp(-30))

        self.out = TermTriangle(self, 1, 'Out', (60, 0), termType.OUTPUT, termDir.EAST)

        self.border = [dp(-50), dp(-20), dp(100), dp(40)]
        self.textInp = TextInput(text='', multiline=False)
        self.textInp.size = (self.border[2] - 20, self.border[3] - 2)
        self.textInp.font_size = 25
        self.textInp.padding = [0, 4, 0, 0]
        self.textInp.background_color = color.black
        self.textInp.foreground_color = color.flatYellow1

        self.state = compState.UNTOUCH
        self.textInp.bind(on_text_validate=self.on_enter)

    def on_enter(self, obj):
        self.state = compState.CHANGED

        try:
            self.setParValue('Value', float(self.textInp.text))
            self.out.shared.value[0] = self.getParValue('Value')  # self.value
        except:                                               # chybne zadanie textu, value errror
            self.setParValue('Value', 0.0)
        self.update()

    def build(self):
        super().build()
        val = self.getParValue('Terminal')
        if val == 'North':
            self.out.pos = (0, dp(30))
            self.out.orient = termDir.NORTH
        elif val == 'West':
            self.out.pos = (dp(-60), 0)
            self.out.orient = termDir.WEST
        elif val == 'East':
            self.out.pos = (dp(60), 0)
            self.out.orient = termDir.EAST
        if val == 'South':
            self.out.pos = (0, dp(-30))
            self.out.orient = termDir.SOUTH

        self.add_widget(self.textInp)

    def update(self):
        super().update()
        self.textInp.text = str(self.getParValue('Value'))
        self.textInp.pos = (self.pos[0] - dp(50) + 10, self.pos[1] - dp(20) + 1)

    def getValue(self):
        '''!
        Nacitanie hodnoty a stavu z grafickeho rozhrania.
        '''
        state = self.state
        self.state = compState.UNTOUCH
        return state, self.out.shared.value[0]

    def setValue(self, value):
        '''!
        Nastavenie hodnoty v shadow - prostredi
        '''
        self.out.shared.value[0] = value

    def eval(self, state, time=0):
        if state == sysState.INIT:
            self.out.shared.value[0] = self.getParValue('Value')
