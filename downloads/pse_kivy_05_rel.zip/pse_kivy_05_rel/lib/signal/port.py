# -*- coding: utf-8 -*-

from src.common import *
from src.component import *


class Port(BoxComponent):
    '''!
    Supertrieda pre prepojovacie komponenty net-ov.
    '''

    def __init__(self):
        super(Port, self).__init__()
        self.type = compType.PORT
        self.shapeColor = color.darkGreen
        self.shapeBorderColor = color.flatGreen1
        self.border = [dp(-25), dp(-10), dp(50), dp(20)]

        self.menu.menuItems[5] = None                         # zrusenie vertikalneho zrkadlenia

        Parameter(self, 'Port', 'Port name', 'A', visible=True, pos=(0, 0), visibleName=False)
        self.getParam('Ref').isVisible = False                # zrusenie viditelnosti 'Ref' parametra
        self.getParam('Port').isLocked = True                 # zrusenie posuvania parametra


class PortIn(Port):
    '''!
    '''
    def __init__(self):
        super().__init__()
        TermJoint(self, 1, 'Conn', (40, 0), termType.CONN)
        self.line = Line()

    def build(self):
        super().build()
        self.canvas.add(RGBA_Color(self.shapeBorderColor))
        self.canvas.add(self.line)

    def update(self):
        super().update()
        self.line.points = (dp(25) + self.pos[0], self.pos[1], dp(40) + self.pos[0], self.pos[1])


class PortOut(Port):
    '''!
    '''
    def __init__(self):
        super().__init__()
        TermJoint(self, 1, 'Conn', (-40, 0), termType.CONN)
        self.line = Line()

    def build(self):
        super().build()
        self.canvas.add(RGBA_Color(self.shapeBorderColor))
        self.canvas.add(self.line)

    def update(self):
        super().update()
        self.line.points = (dp(-25) + self.pos[0], self.pos[1], dp(-40) + self.pos[0], self.pos[1])


class PortBlockIn(PortIn):
    '''!
    Farebne odlisenie portov bloku.
    '''
    def __init__(self):
        super().__init__()
        self.shapeColor = color.firebrick
        self.shapeBorderColor = color.flatYellow4


class PortBlockOut(PortOut):

    def __init__(self):
        super().__init__()
        self.shapeColor = color.firebrick
        self.shapeBorderColor = color.flatYellow4
