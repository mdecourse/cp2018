# -*- coding: utf-8 -*-
from collections import OrderedDict
#import numpy as np

from src.common import *
from src.component import *
from kivy.graphics import *
from kivy.logger import Logger

'''!
Zbernica reprezentuje prepojenie pre presun dat medzi komponentami. Data na zbernici môžu byť
skalárne alebo vektorové, vektorové dáta sú reprezentované dátovým typom np.array.
'''


class Compressor(BoxComponent):
    '''!
    Kompresor zbernice.

    Parameter Inputs určuje počet vstupov, default = 2, maximalny počet vstupov je 16.
    '''
    def __init__(self):
        super().__init__()
        self.type = compType.CONTINUOUS | compType.BUS
        self.shapeColor = color.darkGreen
        self.shapeBorderColor = color.flatGreen1
        self.border = [dp(-5), dp(-20), dp(10), dp(40)]
        self.inputs = 2
        self.menu.menuItems[5] = None                         # zrusenie vertikalneho zrkadlenia
        self.maxInputs = 16

        TermTriangle(self, 1, 'A', (-15, 10), termType.INPUT, termDir.EAST)
        TermTriangle(self, 2, 'B', (-15, -10), termType.INPUT, termDir.EAST)

        self.out = TermTriangle(self, 100, 'Y', (15, 0), termType.OUTPUT, termDir.EAST)

        Parameter(self, 'Inputs', 'Number of inputs', 2)

        self.outputVector = []

    def build(self):
        inputs = self.getParValue('Inputs')

        if inputs != self.inputs:                             # kontrola zapornej alebo nespravnej hodnoty
            if inputs < 2:                                    # chyba, vratit na povodny stav, zrusi zmenu
                self.getParam('Inputs').value = self.inputs   # obnovenie hodnoty parametra
                return

            if inputs > self.maxInputs:                       # kontrola max. poctu vstupov
                inputs = self.maxInputs                       # korekcia, pocet vstupov > 16
                self.getParam('Inputs').value = inputs

            #-------------------------------------------------
            # 1. zmazanie povodnych terminalov
            #    a odlozenie zoznamov pripojenych net-ov
            #-------------------------------------------------
            tempConn = OrderedDict()                          # docasny zozname terminalov s pripojenymi net-mi
            for num, t in self.termDict.items():
                if num != 100:                                # vystupny terminal nezaradeny, ostava bez zmeny
                    tempConn[num] = t
            for num, t in tempConn.items():                   # zmazanie referencii na odlozene, @ToDo lepsie cez zoznam klucov
                self.termDict[num].clear_widgets()            # ??? zmazanie, memory leaks
                del self.termDict[num]                        # terminaly v slovniku terminalov komponentu

            #-------------------------------------------------
            # 2. generovanie noveho poctu terminalov
            #-------------------------------------------------
            y = 0
            if (inputs % 2) == 0:                             # kontrola - parne/neparne cislo
                y = (inputs // 2) * 20 - 10                   # vypocet vertikalnej polohy prveho terminalu
            else:
                y = (inputs // 2) * 20

            max_y = y
            min_y = y - inputs * 20

            for q in range(inputs):                            # vytvorenie terminalov, zaradenie do termDict
                TermTriangle(self, q + 1, chr(q + 64), (-15, y), termType.INPUT, termDir.EAST)
                y = y - 20

            #-------------------------------------------------
            # 3. Obnovenie pripojenia terminalov
            #-------------------------------------------------
            if inputs > self.inputs:                          # pocet novych vstupov > ako pocet povodnych,
                                                              # pripojime exist. siete k povodnym terminalom
                # 3.1 pripojenie sieti k novym terminalom a update koncovych bodov sieti
                for num, old in tempConn.items():
                    t = self.termDict[num]                    # terminal z odlozeneho slovnika
                    t.netDict = old.netDict                   # kopia slovniku spojov
                    for nid, n in t.netDict.items():          # uprava koncovych bodov pripojenych sieti
                        if n.startTerm == old:                # na nove terminaly
                            n.startTerm = t
                        else:
                            n.endTerm = t
            else:
                # 3.2 pripojenie sieti k novym terminalom a update koncovych bodov sieti
                #     pocet novych vstupov je mensi ako povodny, prepojenia k neexistujucim
                #     terminalom budu zmazane
                for num, t in self.termDict.items():          # slovnik novych terminalov
                    if num != 100:                            # vynechany vystupny terminal
                        old = tempConn[num]                   # terminal z odlozeneho slovnika
                        t.netDict = old.netDict
                        for nid, n in t.netDict.items():      # uprava koncovych bodov pripojenych sieti
                            if n.startTerm == old:
                                n.startTerm = t
                            else:
                                n.endTerm = t
                        del tempConn[num]

                for num, t in tempConn.items():               # zmazanie prebytocnych sieti, ktore
                    for nid, n in t.netDict.items():          # nie je mozne pripojit, terminaly neexistuju
                        self.diagram.delNet(n)

            # uprava rozmeru bloku a posunutie 'Ref' parametra
            self.border = [dp(-5), dp(-max_y - 10), dp(10), dp(max_y - min_y)]
            self.getParam('Ref').pos = (0, dp(max_y + 20))

            self.inputs = inputs

        super().build()
        self.dot = Ellipse(size=(dp(6), dp(6)))
        self.canvas.add(RGBA_Color(color.yellow))
        self.canvas.add(self.dot)

    def update(self):
        super().update()
        self.dot.pos = (self.pos[0] - dp(3), self.pos[1] + self.border[1] + self.border[3] - dp(10 + 3))
        # kontrola a nastavenie sirky zbernice:
        # funkcia self.setBus(self)  spusta sa v shadow procese, pretoze vo
        # vizualnom procese nevieme zistit realnu sirku zbernice v expanderi

    def eval(self, state, time=0):

        if state == sysState.INIT:                            # vytvorenie prazdneho zoznamu
            self.out.shared.value = [0] * self.inputs         # zdielane hodnoty
        for i in range(self.inputs):                          # update poloziek vektora - v kazdom kroku
                                                              # funkcie pri vypocte vytvaraju nove polia
            self.out.shared.value[i] = self.termDict[i + 1].shared.value

    def setBus(self, c, net=None):
        # Pre vystupny terminaly nastavi spoje ako zbernice a rekurzivne skontroluje
        # dalsie komponenty (kazdy vystupny spoj z Compressoru je bus).
        # Funkciu vola shadow proces az po inicializacii komponentov v spravnom
        # vypoctovom poradi - spravne priradenie shared value-s (Output->[Inputs]).
        # Zarazky rekurzie:
        #    - komponent bez vystupnych terminalov (SOURCE)
        #    - shared value [] = 1
        #    - najblizsi BUS komponent (Compressor, Expander)
        #
        # @ToDo - optimalizovat funkciu, duplicitna cast kodu
        for tnum, t in c.termDict.items():
            if t.type == termType.OUTPUT:
                for nid, n in t.netDict.items():
                    if n.startTerm != t:
                        for qid, q in n.startTerm.netDict.items():
                            q.isBus = True
                            if (n.startTerm.comp.type & compType.BUS) != compType.BUS:
                                #return
                                #else:
                                self.setBus(n.startTerm.comp, n)
                    elif n.endTerm != t:
                        for qid, q in n.endTerm.netDict.items():
                            q.isBus = True
                            if (n.endTerm.comp.type & compType.BUS) != compType.BUS:
                                #return               # zarazka - najblizsi BUS komponent
                                #else:
                                self.setBus(n.endTerm.comp, n)
            elif t.type == termType.CONN:            # specialny pripad prepojovaci terminal
                for nid, n in t.netDict.items():     # zabranenie vlastnemu volaniu rekurzie
                    if n != net:
                        if n.startTerm != t:
                            for qid, q in n.startTerm.netDict.items():
                                q.isBus = True
                                if (n.startTerm.comp.type & compType.BUS) != compType.BUS:
                                    #return
                                    #else:
                                    self.setBus(n.startTerm.comp, n)
                        elif n.endTerm != t:
                            for qid, q in n.endTerm.netDict.items():
                                q.isBus = True
                                if (n.endTerm.comp.type & compType.BUS) != compType.BUS:
                                    #return
                                    #else:
                                    self.setBus(n.endTerm.comp, n)


class Expander(BoxComponent):
    '''!
    Expander zbernice.

    Parameter Inputs určuje počet vstupov, default = 2.
    '''
    def __init__(self):
        super().__init__()
        self.type = compType.CONTINUOUS | compType.BUS
        self.shapeColor = color.darkGreen
        self.shapeBorderColor = color.flatGreen1
        self.border = [dp(-5), dp(-20), dp(10), dp(40)]
        self.menu.menuItems[5] = None                         # zrusenie vertikalneho zrkadlenia
        self.outputs = 2
        self.maxOutputs = 16

        self.inp = TermTriangle(self, 100, 'X', (-15, 0), termType.INPUT, termDir.EAST)

        TermTriangle(self, 1, 'A', (15, 10), termType.OUTPUT, termDir.EAST)
        TermTriangle(self, 2, 'B', (15, -10), termType.OUTPUT, termDir.EAST)

        Parameter(self, 'Outputs', 'Number of Outputs', 2)
        self.inputVector = []

    def build(self):
        outputs = self.getParValue('Outputs')

        if outputs != self.outputs:                           # kontrola zapornej alebo amlej hodnoty
            if outputs < 2:                                   # chyba, vratit na povodny stav, zrusi zmenu
                self.getParam('Outputs').value = self.outputs
                return

            if outputs > self.maxOutputs:                     # kontrola max. poctu vstupov
                outputs = self.maxOutputs                     # korekcia, pocet vstupov > self.maxOutputs
                self.getParam('Outputs').value = outputs

            #-------------------------------------------------
            # 1. zmazanie povodnych terminalov
            #    a odlozenie zoznamov pripojenych net-ov
            #-------------------------------------------------
            tempConn = OrderedDict()                          # docasny zozname terminalov s pripojenymi net-mi
            for num, t in self.termDict.items():
                if num != 100:                                # vystupny terminal nezaradeny, ostava bez zmeny
                    tempConn[num] = t
            for num, t in tempConn.items():                   # zmazanie referencii na odlozene, @ToDo lepsie cez zoznam klucov
                self.termDict[num].clear_widgets()            # ??? zmazanie, memory leaks
                del self.termDict[num]                        # terminaly v slovniku terminalov komponentu

            # 2. generovanie noveho poctu terminalov
            y = 0
            if (outputs % 2) == 0:  # kontrola - parne/neparne cislo
                y = (outputs // 2) * 20 - 10
            else:
                y = (outputs // 2) * 20

            max_y = y
            min_y = y - outputs * 20

            for q in range(outputs):
                TermTriangle(self, q + 1, chr(q + 64), (15, y), termType.OUTPUT, termDir.EAST)
                y = y - 20

            #-------------------------------------------------
            # 3. Obnovenie pripojenia terminalov
            #-------------------------------------------------
            if outputs > self.outputs:                     # pocet novych vystupov > ako pocet povodnych,
                                                              # pripojime exist. siete k povodnym terminalom
                # 3.1 pripojenie sieti k novym terminalom a update koncovych bodov sieti
                for num, old in tempConn.items():
                    t = self.termDict[num]                    # terminal z odlozeneho slovnika
                    t.netDict = old.netDict                   # kopia slovniku spojov
                    for nid, n in t.netDict.items():          # uprava koncovych bodov pripojenych sieti
                        if n.startTerm == old:                # na nove terminaly
                            n.startTerm = t
                        else:
                            n.endTerm = t
            else:
                # 3.2 pripojenie sieti k novym terminalom a update koncovych bodov sieti
                #     pocet novych vstupov je mensi ako povodny, prepojenia k neexistujucim
                #     terminalom budu zmazane
                for num, t in self.termDict.items():          # slovnik novych terminalov
                    if num != 100:                            # vynechany vystupny terminal
                        old = tempConn[num]                   # terminal z odlozeneho slovnika
                        t.netDict = old.netDict
                        for nid, n in t.netDict.items():      # uprava koncovych bodov pripojenych sieti
                            if n.startTerm == old:
                                n.startTerm = t
                            else:
                                n.endTerm = t
                        del tempConn[num]

                for num, t in tempConn.items():              # zmazanie prebytocnych sieti, ktore
                    for nid, n in t.netDict.items():         # nie je mozne pripojit, terminaly neexistuju
                        self.diagram.delNet(n)

            # uprava rozmeru bloku a posunutie 'Ref' parametra
            self.border = [dp(-5), dp(-max_y - 10), dp(10), dp(max_y - min_y)]
            self.getParam('Ref').pos = (0, dp(max_y + 20))

            self.outputs = outputs

        super().build()
        self.dot = Ellipse(size=(dp(6), dp(6)))
        self.canvas.add(RGBA_Color(color.yellow))
        self.canvas.add(self.dot)

    def update(self):
        super().update()
        self.dot.pos = (self.pos[0] - dp(3), self.pos[1] + self.border[1] + self.border[3] - dp(10 + 3))

    def eval(self, state, time=0):

        try:
            for i in range(self.outputs):
                self.termDict[i + 1].shared.value = self.inp.shared.value[i]
        except:
            Logger.error('Expander: ' + self.getParValue('Ref') + ' Vstupny vektor != pocet vystupov')
            self.diagram.stop()

    def setBus(self, c, net=None):
        # Pre vystupne terminaly skontroluje sirku shared premennej,
        # ake je > 1, nastavi spoj ako zbernicu a rekurzivne skontroluje
        # dalsi komponent.
        # Funkciu vola shadow proces az po inicializacii komponentov v spravnom
        # vypoctovom poradi - spravne priradenie shared value-s (Output->[Inputs]).
        # Zarazky rekurzie:
        #    - komponent bez vystupnych terminalov (SOURCE)
        #    - shared value [] = 1
        #    - najblizsi BUS komponent (Compressor, Expander)
        #
        # @ToDo - optimalizovat funkciu, duplicitna cast kodu
        for tnum, t in c.termDict.items():
            if t.type == termType.OUTPUT:
                try:
                    if len(t.shared.value) > 1:
                        for nid, n in t.netDict.items():
                            if n.startTerm != t:
                                for qid, q in n.startTerm.netDict.items():
                                    q.isBus = True
                                    if (n.startTerm.comp.type & compType.BUS) != compType.BUS:
                                        #return
                                        #else:
                                        self.setBus(n.startTerm.comp, n)
                            elif n.endTerm != t:
                                for qid, q in n.endTerm.netDict.items():
                                    q.isBus = True
                                    if (n.endTerm.comp.type & compType.BUS) != compType.BUS:
                                        #return           # zarazka - najblizsi je BUS komponent
                                        #else:
                                        self.setBus(n.endTerm.comp, n)
                except:
                    pass
                    # Logger.error('Expander: ' + self.getParValue('Ref') + ' setBus - vstupny vektor obsahuje skalarnu hodnotu')
                #else:
                #    return                           # zarazka, shared ma len jednu polozku
            elif t.type == termType.CONN:     # specialny pripad prepojovaci terminal
                for nid, n in t.netDict.items():     # zabranenie vlastnemu volaniu rekurzie
                    if n != net:
                        if n.startTerm != t:
                            for qid, q in n.startTerm.netDict.items():
                                q.isBus = True
                                if (n.startTerm.comp.type & compType.BUS) != compType.BUS:
                                    #return
                                    #else:
                                    self.setBus(n.startTerm.comp, n)
                        elif n.endTerm != t:
                            for qid, q in n.endTerm.netDict.items():
                                q.isBus = True
                                if (n.endTerm.comp.type & compType.BUS) != compType.BUS:
                                    #return
                                    #else:
                                    self.setBus(n.endTerm.comp, n)
