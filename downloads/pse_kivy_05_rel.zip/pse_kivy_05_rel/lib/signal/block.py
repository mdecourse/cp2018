# -*- coding: utf-8 -*-
import json
#import os

from collections import OrderedDict

from lib.sources.generators import *                          # import kniznic komponentov
from lib.sources.consts import *
from lib.sinks.system import *
from lib.signal.bus import *
from lib.signal.block import *
from lib.signal.port import *
from lib.math.func import *
from lib.visual.basic import *

from cfg.config_pse import *
from cfg.config_lib import *
from src.library import *
from src.common import *
from src.net import *
from src.component import *
from src.diagram import *

from kivy.graphics import *
from kivy.logger import Logger


class Block(BoxComponent):
    """!
    Block - Externý diagram

    Komponent agregujúci externý diagram, mená terminálov musia korešpondovať s vnútornými portami
    externého diagramu. Diagram je expandovaný v simulácii ako makro.

    Postup pri vytváraní bloku:

    1. Diagram sa načíta zo štandardného súboru *.pse, diagram musí obsahovať prepojovacie
       porty, ktorých mená budú korešpondovať s menami terminálov bloku.
       Komponenty a nety diagramu sa zaraďujú do vnútorných zoznamov bloku, nepridávajú sa do grafického
       sub-systému, grafická časť komponentov sa neupdatuje.

    2. Referencie komponentov sú upravené na tvar <ref bloku>_<ref komp>
       id komponentov su upravene na tvar <uid bloku> * 10000 + <uid komp>,
       mena net-ov su upravené na tvar <ref bloku>_<meno net>

    3. Vytvorenie prepojení medzi terminálmi komponentu a portami diagramu,
       prepojenia maju meno <ref bloku>_<cislo terminalu> <meno portu>

    @todo - vymazanie virtualnych prepojeni pred nahratím bloku, zoatanú v diagrame po skončení simulácie
            úprave bloku a jeho následnom uložení.
            Dočasná úprava - ignorovanie virtuálnych spojov pri nahratí bloku

    @todo automaticke vygenerovanie zoznamu vstupnycha vystupnych terminalov bloku pri zadani mena bloku
          podla komponentov TYPE_NET_TERM

    @todo kontrola integrity bloku, zhoda medzi menami terminalov a vnutornymi portami bloku,
          nepripojene terminaly ...

    @endif
    """

    def __init__(self):
        super().__init__()
        self.type = compType.BLOCK

        self.compDict = OrderedDict()                         # lokalny zoznam komponentov bloku
        self.netDict = OrderedDict()                          # lokalny zoznam prepojeni bloku
        self.shapeColor = color.darkBlue
        self.shapeBorderColor = color.flatYellow1
        self.image = './lib/signal/img/map.png'
        self.inpStr = 'A, B'                                  # init hodnoty parametrov Inputs, Outputs
        self.outStr = 'Y'                                     # kontrola pri zmene hodnoty parametra (isChanged)

        Parameter(self, 'Inputs', 'Block inputs', self.inpStr)
        Parameter(self, 'Outputs', 'Block outputs', self.outStr)
        Parameter(self, 'Diagram', 'File name', 'file.pse')
        Parameter(self, 'Icon', 'Block icon', './lib/signal/img/map.png')

        t1 = TermTriangle(self, 1, 'A', (-45, -10), (termType.INPUT | termType.CONN), termDir.EAST)
        t1.nameShow = True
        t1.namePos = (dp(15), 0)

        t2 = TermTriangle(self, 2, 'B', (-45, 10), (termType.INPUT | termType.CONN), termDir.EAST)
        t2.nameShow = True
        t2.namePos = (dp(15), 0)

        t3 = TermTriangle(self, 100, 'Y', (45, 0), (termType.OUTPUT | termType.CONN), termDir.EAST)
        t3.nameShow = True
        t3.namePos = (dp(-15), 0)

        y = 30
        self.border = [dp(-35), dp(-y / 2 - 10), dp(70), dp(y + 20)]
        self.getParam('Ref').pos = (0, dp(y / 2 + 20))

        # premenne pouzivane pri kontrole zmeny konfiguracie bloku
        self.numInp = 0                                        # pocet vstupnych terminalov
        self.numOut = 0                                        # pocet vystupnych terminalov
        self.netNum = 1                                        # pocitadlo pre pridavane doplnkove prepojenia
                                                               # (term -> vnut. port)

    def build(self):
        '''
        @ToDo - kontrola parametra na nezadane terminaly rep. zle zadane terminaly
        '''
        if self.diagram is None:                               # vytvorenie bloku v kniznici bez referencie na diagram
            super().build()
            return

        if (self.diagram.mode == mode.MOVE) or (self.diagram.mode == mode.MOVE_COMP):
            #print('mode ... ', self.diagram.mode)
            super().build()                                    # pri presune komponentu sa nekontroluje pripojenie bloku
            return

        # 1. Kontrola odpojenych terminalov
        #   zmena struktury bloku je mozna len pri odpojenych terminaloch bloku
        for num, t in self.termDict.items():
            if len(t.netDict.items()) > 0:
                self.paramDict['Inputs'].value = self.inpStr  # reinicializacia hodnot parametrov
                self.paramDict['Outputs'].value = self.outStr
                super().build()
                Logger.warning('Block: Blok ' + self.paramDict['Ref'].value + ' ma pripojene terminaly, nie je mozna zmena konfiguracie')
                return

        # 2. Kontrola zmeny hodnot parametrov
        tempInp = self.inpStr                                 # odlozene stare hodnoty
        tempOut = self.outStr
        self.inpStr = self.getParValue('Inputs')              # nacitanie novych hodnot
        self.outStr = self.getParValue('Outputs')

        if (self.inpStr == tempInp) and (self.outStr == tempOut):
            super().build()                                   # hodnoty parametrov neboli zmenen

        else:
            # 3. Zmenene parametre, prebudovanie bloku
            keys = list(self.termDict.keys())                 # vymazanie starych terminalov
            for k in keys:                                    # ??? asi nie je treba - memory leaks
                self.termDict[k].clear_widgets()
                del self.termDict[k]
            self.termDict = OrderedDict()

            # 3.1 Generovanie vstupnych terminalov, definovanie vlastnosti a popisu
            #    terminalu su typu (CONN or INPUT) - prepajaju blok s jeho vnutornou strukturou
            inp = self.inpStr.replace(' ', '')                # nacitanie zoznamu vstupnych terminalov
            inp = inp.split(',')[::-1]
            self.numInp = len(inp)

            y1 = 0                                            # vypocet polohy vstupnych terminalov
            if (self.numInp % 2) == 0:                        # kontrola parne/neparne cislo
                y1 = -(self.numInp // 2) * 20 + 10            # vypocet pociatocnej polohy
            else:
                y1 = -(self.numInp // 2) * 20

            for i in range(self.numInp):
                t = TermTriangle(self, i + 1, inp[i], (-45, y1), (termType.INPUT | termType.CONN), termDir.EAST)
                t.nameShow = True
                t.namePos = (dp(15), 0)
                y1 = y1 + 20

            # 3.2 Generovanie vystupnych terminalov, definovanie vlastnosti a popisu
            out = self.outStr.replace(' ', '')                # nacitanie zoznamu vystupnych terminalov
            out = out.split(',')[::-1]
            self.numOut = len(out)

            y2 = 0                                            # vypocet polohy vystupnych terminalov
            if (self.numOut % 2) == 0:                        # kontrola parne/neparne cislo
                y2 = -(self.numOut // 2) * 20 + 10            # vypocet pociatocnej polohy
            else:
                y2 = -(self.numOut // 2) * 20

            for i in range(self.numOut):
                t = TermTriangle(self, i + 100, out[i], (45, y2), (termType.OUTPUT | termType.CONN), termDir.EAST)
                t.nameShow = True
                t.namePos = (dp(-15), 0)
                y2 = y2 + 20

            # 3.3 Uprava rozmeru bloku a posunutie 'Ref' parametra
            y = max(y1, y2)                                    # max. vysky - poloha vstupnych resp. vystupnych terminalov
            super().build()
            self.border = [dp(-35), dp(-y / 2 - 10), dp(70), dp(y + 20)]
            self.getParam('Ref').pos = (0, dp(y / 2 + 20))

    #def update(self):
    #    super().update()

    def loadBlock(self, offset):
        '''
        Nacitanie diagramu bloku bez inicializacie grafickych casti.
        '''

        fileName = self.paramDict['Diagram'].value          # meno suboru s diagramom bloku
        self.compDict = OrderedDict()                         # inicializacia vnutornych struktur
        self.netDict = OrderedDict()

        with open(fileName, 'r') as input_file:
            s = input_file.readlines()

        #-----------------------------------------------------
        # 1. nacitanie struktury diagramu
        #-----------------------------------------------------
        readData = json.loads(s[0], object_hook=self.diagram.__jsonImport__)
        cList = readData[1]                                   # zoznam komponentov
        nList = readData[2]                                   # zoznam prepojeni
        #-----------------------------------------------------
        # 2. spracovanie zoznamu komponentov
        #-----------------------------------------------------
        for num, c in cList.items():                          # parser zoznamu komponentov
            [cid, name, pos, paramList, p1, p2] = c           # nacitanie zaznamu pre komponent
            comp = globals()[str(name)]()                     # vytvorenie noveho komponentu
            comp.cid = cid + offset                           # nastavenie parametrov podla zaznamu

            for k, q in paramList.items():                    # vytvorenie slovnika Parametrov
                [name, pos, typ, value, listValue, desc, [isLocked, isVisible, isNameVisible]] = q
                p = comp.paramDict[name]
                p.value = value
            comp.paramDict['Ref'].value = self.paramDict['Ref'].value + ':' + comp.paramDict['Ref'].value
            self.compDict[comp.cid] = comp                    # zaradenie komponentu do slovnika bloku

            # update BUS komponentov, zmeny poctu terminalov pri variabilnych komponentoch
            comp.build()
        #-----------------------------------------------------
        # 3. spracovanie zoznamu spojov
        #-----------------------------------------------------
        for n in nList.items():                               # parser zoznamu spojov
            [nid, paramList, vertexList, startTerm, endTerm, [isLocked, isVisible]] = n[1]

            net = Net()
            net.nid = nid + offset
            net.vertexList = []                               # prazdny zoznam vertexov, addNet vytvara nulty vertex

            [stCompId, stTermNum] = startTerm                 # prepojenie net-u, komponent id a cislo terminalu
            cst = self.compDict[stCompId + offset]                     # referencia na komponent - zo slovnika
            stt = cst.getTerminal(stTermNum)                  # referencia na terminal
            stt.netDict[net.nid] = net                        # pridanie net-u do zoznamu prepojeni terminalu
            net.startTerm = stt                               # priradenie pociatocneho terminalu net-u

            [edCompId, edTermNum] = endTerm                   # prepojenie net-u, koncovy terminal
            ced = self.compDict[edCompId + offset]
            edt = ced.getTerminal(edTermNum)
            edt.netDict[net.nid] = net
            net.endTerm = edt

            for k, q in paramList.items():                    # vytvorenie slovnika Parametrov
                [name, pos, typ, value, listValue, desc, [isLocked, isVisible, isNameVisible]] = q
                p = net.paramDict[name]                       # update hodnoty parametra spoja
                p.type = typ
                p.value = value
            net.paramDict['Name'].value = self.paramDict['Ref'].value + ':' + net.paramDict['Name'].value
            self.netDict[net.nid] = net                       # zaradenie net-u do lokalneho zoznamu

            self.netNum = max(self.netNum, nid)

        self.netNum = -self.netNum - 1 - offset
        # 4. Vytvorenie prepojeni medzi terminalmi bloku a vnutornymi portami bloku
        #    iteracia cez zoznam terminalov bloku, vyhladanie vnutornych sietovych terminalov
        #    so zhodnym menom,
        for num, t in self.termDict.items():                  # prechadzanie slovnika terminalov bloku
                                                              # pre kazdy terminal hladame zhodu v komponentoch PORT
                                                              # @ToDo optimalizovat, porty ulozit do samost. slovnika
                                                              # s klucom mena a priamo vyberat bez opakovaneho prehladavania

            for cid, c in self.compDict.items():              # prechadzanie zoznamu komponentov
                if c.type == compType.PORT:                   # vyber len komponentov typu PORT

                    if t.name == c.paramDict['Port'].value:   # zhoda medzi menom portu a terminalom

                        c.type = compType.PORT_CONN           # zmena typu komponentu pre zabranenie vytvarania virtualych
                                                              # prepojeni medzi komponentami typu PORT
                                                              # k terminalu bloku existuje vnutorny port so zhodnym menom
                        vnet = VirtualNet()                   # vytvorenie virtualneho spoja
                        vnet.nid = self.netNum                # priradenie nid spoja

                        t.netDict[vnet.nid] = vnet                 # spojenie terminalu a portu
                        vnet.startTerm = t

                        c.termDict[1].netDict[vnet.nid] = vnet     # pripojenie spoja k zoznamu spojov komponentu PORT
                        vnet.endTerm = c.termDict[1]

                        self.netDict[vnet.nid] = vnet         # zaradenie spoja do lokalneho slovnika
                        self.netNum = self.netNum - 1

        # 6. premenovanie mien portov pre zabranenie kolizie so zhodnymi menami portov v inych blokoch
        for cid, comp in self.compDict.items():
            if comp.type == compType.PORT:
                portName = comp.paramDict['Port'].value
                comp.paramDict['Port'].value = self.paramDict['Ref'].value + ':' + portName

        # @ToDo rekurzivny load vnorenych blokov
        #
        #
        return self.compDict, self.netDict