# -*- coding: utf-8 -*-
from src.common import *
from src.component import *

from decimal import getcontext, Decimal


class Clock(BoxComponent):
    '''!
    Generator hodinových impulzov.

    @todo - zmena polohy terminalu
    '''
    def __init__(self):
        super().__init__()

        self.type = compType.DISCRETE
        self.shapeColor = color.midnightBlue
        self.shapeBorderColor = color.flatBlue1
        self.image = './lib/discrete/img/clock2.png'

        self.out = TermTriangle(self, 1, 'Clk', (0, -35), termType.OUTPUT, termDir.SOUTH)
        self.out.termColor = color.yellow

        Parameter(self, 'Period', 'Clock period [sec]', 0.1)
        Parameter(self, 'Offset', 'Clock time offset', 0.0)

    def eval(self, state, time=0, step=0):
        if state == sysState.INIT:
            self.tp = Decimal(self.getParValue('Period'))
            self.ofs = Decimal(self.getParValue('Offset'))
            self.step = Decimal(step)
            self.out.shared.value = 0
            getcontext().prec = 6

        if state == sysState.STEP:
            self.time = Decimal(time)
            if self.time > 0.0:                               # pri nule negeneruje impulz
                q = (self.time + self.ofs) / self.step
                w = self.tp / self.step

                if (q % w) == 0:
                    self.out.shared.value = 1
                else:
                    self.out.shared.value = 0


class Delay(BoxComponent):
    '''!
    Jednotkove oneskorenie.
    '''
    def __init__(self):
        super().__init__()
        self.type = compType.DISCRETE
        self.shapeColor = color.midnightBlue
        self.shapeBorderColor = color.flatBlue1
        self.image = './lib/discrete/img/delay3.png'

        self.inp = TermTriangle(self, 1, 'In', (-35, 0), termType.INPUT, termDir.EAST)
        self.out = TermTriangle(self, 2, 'Out', (35, 0), termType.OUTPUT, termDir.EAST)

        Parameter(self, 'Init', 'Init value at T=0', 0.0)

    def eval(self, state, time=0, step=0):
        if state == sysState.INIT:
            #self.value = self.out.shared.value[0] = self.getParValue('Init')
            self.value = [self.getParValue('Init')] * len(self.inp.shared.value)

        if state == sysState.STEP:
            #self.out.shared.value[0] = self.value
            #self.value = self.inp.shared.value[0]
            self.out.shared.value = self.value
            self.value = self.inp.shared.value


class ClockSync(BoxComponent):
    '''!
    Generator hodinových impulzov synchronizovaný na definovaný počet krokov simulácie.

    Parameter Steps určuje periódu impulzov na výstupe.
    @todo Zmena polohy vystupneho terminalu
    '''
    def __init__(self):
        super().__init__()

        self.type = compType.DISCRETE
        self.shapeColor = color.midnightBlue
        self.shapeBorderColor = color.flatBlue1
        self.image = './lib/discrete/img/clock2.png'

        self.out = TermTriangle(self, 1, 'Clk', (0, -35), termType.OUTPUT, termDir.SOUTH)
        self.out.termColor = color.yellow
        self.count = 0

        Parameter(self, 'Steps', 'Number of clock steps', 10)

    def eval(self, state, time=0, step=0):
        if state == sysState.INIT:
            self.st = self.getParValue('Steps')
            self.count = 0
            self.out.shared.value = 0

        if state == sysState.STEP:
            if (self.count % self.st) == 0:
                self.out.shared.value = 1
            else:
                self.out.shared.value = 0
            self.count = self.count + 1