# -*- coding: utf-8 -*-
from src.common import *
from src.component import *


class RK2(BoxComponent):
    '''!
    Riadiaci komponent simulacie, Runge Kutt 2, samostatny OS proces
    '''

    def __init__(self):
        super().__init__()
        self.type = compType.CONTROL
        self.shapeColor = color.flatBlue5
        self.shapeBorderColor = color.flatBlue1
        self.solver = 'RK2'

        Parameter(self, 'Step', 'Time step', 0.01, True, (0, -40), True)
        Parameter(self, 'Stop', 'Stop time', 10.0, True, (0, -60), True)

        self.label = Label(text='RK2', pos=self.pos, size=(0, 0), font_size=dp(20), color=color.black, italic=True)

    def update(self):
        super().update()
        self.label.pos = self.pos

    def build(self):
        super().build()
        self.add_widget(self.label)

    def setValue(self, value):
        if value[0] == sysState.STOP:
            self.diagram.editor.stop()

        if value[0] == sysState.UPDATE:
            busList = value[1]                     # prekreslenie zbernic
            for q in busList:
                if q in self.diagram.netDict:
                    n = self.diagram.netDict[q]    # vylucenie virtualnych sieti, nid < 0, spojov v blokoch
                    n.isBus = True
                    n.rebuild()


class RT2(BoxComponent):
    '''!
    Riadiaci komponent simulacie - real time Runge Kutt 2
    '''

    def __init__(self):
        super().__init__()
        self.type = compType.CONTROL
        self.shapeColor = color.flatBlue5
        self.shapeBorderColor = color.flatBlue1
        self.solver = 'RT2'

        Parameter(self, 'Step', 'Time step', 0.01, True, (0, -40), True)
        Parameter(self, 'Stop', 'Stop time', 10.0, True, (0, -60), True)

        self.label = Label(text='RT2', size=(0, 0), font_size=dp(20), color=color.black, italic=True)

    def update(self):
        super().update()
        self.label.pos = self.pos

    def build(self):
        super().build()
        self.add_widget(self.label)

    def setValue(self, value):
        if value == sysState.STOP:
            self.diagram.editor.stop()


class RK2T(BoxComponent):
    '''!
    Riadiaci komponent simulacie, Runge Kutt 2, samostatny OS thread
    '''

    def __init__(self):
        super().__init__()
        self.type = compType.CONTROL
        self.shapeColor = color.flatBlue5
        self.shapeBorderColor = color.flatBlue1
        self.solver = 'RK2T'

        Parameter(self, 'Step', 'Time step', 0.01, True, (0, -40), True)
        Parameter(self, 'Stop', 'Stop time', 10.0, True, (0, -60), True)

        self.label = Label(text='RK2T', pos=self.pos, size=(0, 0), font_size=dp(20), color=color.black, italic=True)

    def update(self):
        super().update()
        self.label.pos = self.pos

    def build(self):
        super().build()
        self.add_widget(self.label)

    def setValue(self, value):
        if value[0] == sysState.STOP:
            self.diagram.editor.stop()

        if value[0] == sysState.UPDATE:
            busList = value[1]                     # prekreslenie zbernic
            for q in busList:
                if q in self.diagram.netDict:
                    n = self.diagram.netDict[q]    # vylucenie virtualnych sieti, nid < 0, spojov v blokoch
                    n.isBus = True
                    n.rebuild()