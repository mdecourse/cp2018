# Computational algorithms 

           2nd course, 4th semester

           Bauman Moscow State Technical University


| List of Labs  |     Stage     |      Task     |
| ------------- |:-------------:|:-------------:|
| Lab 1| ✅ |<a href="https://github.com/Panda-Lewandowski/Computational-algorithms/wiki/Lab-1">wiki</a>|
| Lab 2| ✅ |<a href="https://github.com/Panda-Lewandowski/Computational-algorithms/wiki/Lab-2">wiki</a>|
| Lab 3| ✅ |<a href="https://github.com/Panda-Lewandowski/Computational-algorithms/wiki/Lab-3">wiki</a>|
| Lab 4| ✅ |<a href="https://github.com/Panda-Lewandowski/Computational-algorithms/wiki/Lab-4">wiki</a>|
| Lab 5| ✅ |<a href="https://github.com/Panda-Lewandowski/Computational-algorithms/wiki/Lab-5">wiki</a>|
| Lab 6| ✅ ||
<ul>
<li>Python 3.6
<li><b>Using libs:</b> PyQt5 (5.8), numpy (1.12), matplotlib(2.0.0), math (std) , prettytable (0.7.2)</ul>

#### Run `pip3 install -r requirements.txt` to install all dependencies at once.

#### <i>Legend:</i><ul>
<ul>
<li>✅ - ОК
<li>⚠️ - problem
<li>🆘 - need help
<li>🌀 - in process
</ul>
</ul>
